package com.srpost.cm.bo.base.plan;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.cm.bo.base.code.CodeUtil;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.salmon.constant.Message;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;

import static com.srpost.salmon.constant.StringPool.ONE;

/**
 * 내부단 일정 관리 컨트롤러
 *
 * @author  finkle
 * @date    2016-04-15
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/plan")
public class PlanController extends BaseController {

    @Resource
    IPlanService service;

    /**
     * 일정 관리 메인
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index(ModelMap model) {
        
        model.addAttribute("codeList", CodeUtil.getCodeList("PLAN_TYPE"));
    }
    
    /**
     * 일정 관리 목록
     */
    @RequestMapping(value="j_list.do", method=RequestMethod.GET)
    public ModelAndView list(PlanBean bean, ModelMap model) {
        
        return responseJson(model, PlanUtil.convertList(service.list(bean)));
    }

    /**
     * 일정 관리 상세정보
     */
    @RequestMapping(value="p_view.do", method=RequestMethod.GET)
    public void view(PlanBean bean, HttpServletRequest request, ModelMap model) {

    	// model.addAttribute("hasAuth", MgrUtil.hasManageAuthCd(request));
        model.addAttribute("dataBean", service.view(bean));
    }
    
    /**
     * 일정 관리 등록/수정 폼
     */
    @RequestMapping(value="p_form.do", method=RequestMethod.GET)
    public void form(PlanBean bean, ModelMap model) {

        if (StringUtil.isEmpty(bean.getSeq())) {
            model.addAttribute("dataBean", bean);
        }
        else {
            PlanBean dataBean = service.view(bean);            
            model.addAttribute("dataBean", dataBean == null ? bean : dataBean);
        }
    }
    
    /**
     * 일정 관리 등록 액션
     */
    @RequestMapping(value="t_insertAction.do", method=RequestMethod.POST)
    public ModelAndView insertAction(PlanBean bean, HttpServletRequest request, ModelMap model) {

        bean.setMgrId(MgrUtil.getSession(request).getMgrId());

        int affected = service.insertAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_INSERT_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }

    /**
     * 일정 관리 수정 액션
     */
    @RequestMapping(value="t_updateAction.do", method=RequestMethod.POST)
    public ModelAndView updateAction(PlanBean bean, ModelMap model) {

        int affected = service.updateAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_UPDATE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }

    /**
     * 일정 관리 삭제 액션
     */
    @RequestMapping(value="t_deleteAction.do", method=RequestMethod.POST)
    public ModelAndView deleteAction(PlanBean bean, ModelMap model) {

        int affected = service.deleteAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_DELETE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
}
