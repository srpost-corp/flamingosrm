package com.srpost.cm.bo.base.explorer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.base.auth.AuthBean;
import com.srpost.cm.bo.base.bbs.core.BbsBean;
import com.srpost.cm.bo.base.faq.core.FaqBean;
import com.srpost.cm.bo.base.file.FileDao;
import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.salmon.bean.BaseListBean;

import static com.srpost.salmon.constant.StringPool.ZERO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;

/**
 * 익스플로러 DAO
 *
 * @author  finkle
 * @date    2014-12-18
 * @since   3.0
 */
@Repository
public class ExplorerDao extends EgovAbstractMapper {
    
    @Resource
    FileDao fileDao;
    
    
    public Map<String, Integer> totWork(LoginBean loginBean) {
        
        return selectMap("_explorer.totWorkMap", loginBean.getMgrId(), "KEYZ");
    }

    public Map<String, Integer> myWork(LoginBean loginBean) {
        
        Map<String, Integer> dataMap = new HashMap<String, Integer>();
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("mgrId", loginBean.getMgrId());
        parameterMap.put("active", VocConstant.ACT_ACTIVE);
        
        List<AuthBean> authList = loginBean.getAuthList();
        for (AuthBean item : authList) {

            int authCd = item.getAuthCd();
            
            if (authCd == AUTH_RECEIVER || authCd == AUTH_DIVIDER || 
                    authCd == AUTH_DEALER || authCd == AUTH_SANCER) 
            {                
                parameterMap.put("authCd", authCd);  
                
                dataMap.put(String.valueOf(item.getAuthCd()), 
                        (Integer)selectOne("_explorer.myWorkCount", parameterMap));
            }
        }
        
        return dataMap;
    }

    public List<Map<String, VocBean>> statusList(String type) {
        
        return selectList("_explorer.statusList", type);
    }

    public List<Map<String, Object>> planList(Map<String, Object> parameterMap) {
        
        return selectList("_explorer.planList", parameterMap);
    }
    
    public Map<String, Object> calendar(String planDay) {
        
        return selectOne("_explorer.calendar", planDay);
    }

    public List<Map<String, Object>> vocCtgList(BaseListBean bean) {
        Map<String, Object> parameterMap = bean.createPagerMap();
        
        return selectList("_explorer.vocCtgList", parameterMap);
    }

    public List<Map<String, Object>> vocTagList(BaseListBean bean) {
        Map<String, Object> parameterMap = bean.createPagerMap();
        
        return selectList("_explorer.vocTagList", parameterMap);
    }
    
    public List<BbsBean> listForDashboard(BbsBean bean) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("bbsCd", bean.getBbsCd());
        parameterMap.put("rowPerPage", bean.getRowPerPage());
        
        List<BbsBean> bbsList =  selectList("_explorer.bbsList", parameterMap);
        
        for (BbsBean bbsBean : bbsList) {
            if (bbsBean.getFileCnt() > ZERO)
                bbsBean.setFileList( fileDao.list(bbsBean.getFileSeq()) );
        }
        return bbsList;
    }
    
    public List<FaqBean> listForDashboard(FaqBean bean) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("rowPerPage", bean.getRowPerPage());

        return selectList("_explorer.faqList", parameterMap);
    }
    
    public List<Map<String, Object>> statusForChart() {
        
        return selectList("_explorer.statusForChart");
    }
    
    public List<Map<String, Object>> monthRegForChart() {
        
        return selectList("_explorer.monthRegForChart");
    }
    
    public List<Map<String, Object>> endCntForChart() {
        
        return selectList("_explorer.endCntForChart");
    }
    
    public List<Map<String, Object>> scoreCntForChart(String score) {
        
        return selectList("_explorer.scoreCntForChart", score);
    }

}
