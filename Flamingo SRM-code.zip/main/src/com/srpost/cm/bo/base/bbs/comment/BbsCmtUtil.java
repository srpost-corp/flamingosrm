package com.srpost.cm.bo.base.bbs.comment;

import javax.servlet.http.HttpServletRequest;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 게시판 의견글 Util
 *
 * @author  finkle
 * @date    2015-01-23
 * @since   3.0
 */
public final class BbsCmtUtil {

    public static void setNotNullValue(BbsCmtBean bean) {
    }
    
    public static void setWriterlValue(BbsCmtBean bean, HttpServletRequest request) {

        LoginBean loginBean = MgrUtil.getSession(request);
        bean.setMgrId(loginBean.getMgrId());
        bean.setMgrNm(loginBean.getMgrNm());
    }
    
    /* 본인 작성 글 여부 확인 */
    public static boolean isOwner(BbsCmtBean bean, HttpServletRequest request) {
        
        LoginBean loginBean = MgrUtil.getSession(request);
        if (loginBean == null) return false;
        return StringUtil.equals(loginBean.getMgrId(), bean.getMgrId());
    }
}
