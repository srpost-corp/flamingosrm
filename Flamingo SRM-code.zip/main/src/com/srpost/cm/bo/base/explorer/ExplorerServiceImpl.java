package com.srpost.cm.bo.base.explorer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.base.bbs.core.BbsBean;
import com.srpost.cm.bo.base.faq.core.FaqBean;
import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.salmon.bean.BaseListBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 익스플로러 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-18
 * @since   3.0
 */
@Service
public class ExplorerServiceImpl extends EgovAbstractServiceImpl implements IExplorerService{

    @Resource
    ExplorerDao dao;
    
    @Override
    public Map<String, Integer> totWork(LoginBean loginBean) {
        
        return dao.totWork(loginBean);
    }
    
    @Override
    public Map<String, Integer> myWork(LoginBean loginBean) {
        
        return dao.myWork(loginBean);
    }

    @Override
    public List<Map<String, VocBean>> statusList(String type) {
        
        return dao.statusList(type);
    }

    @Override
    public List<Map<String, Object>> planList(Map<String, Object> parameterMap) {
        
        return dao.planList(parameterMap);
    }
    
    @Override
    public Map<String, Object> calendar(String planDay) {
        
        return dao.calendar(planDay);
    }

    @Override
    public List<Map<String, Object>> vocCtgList(BaseListBean bean) {
        
        return dao.vocCtgList(bean);
    }

    @Override
    public List<Map<String, Object>> vocTagList(BaseListBean bean) {
        
        return dao.vocTagList(bean);
    }
    
    @Override
    public List<BbsBean> listForDashboard(BbsBean bean) {
        
        return dao.listForDashboard(bean);
    }
    
    @Override
    public List<FaqBean> listForDashboard(FaqBean bean) {
        
        return dao.listForDashboard(bean);
    }

    @Override
    public List<Map<String, Object>> statusForChart() {
        
        return dao.statusForChart();
    }

    @Override
    public List<Map<String, Object>> monthRegForChart() {
        
        return dao.monthRegForChart();
    }

    @Override
    public List<Map<String, Object>> endCntForChart() {
        
        return dao.endCntForChart();
    }

    @Override
    public Map<String, List<Map<String,Object>>> scoreCntForChart() {
        
        String[] VOC_SCORE_ENG_NM = { "GREAT", "GOOD", "NORMAL", "BAD", "WORSE" };
        
        Map<String, List<Map<String,Object>>> scoreCntList = new HashMap<String, List<Map<String,Object>>>();
        
        for (String score : VOC_SCORE_ENG_NM) {
            scoreCntList.put(score, dao.scoreCntForChart(score));
        }
        
        return scoreCntList;
    }

}
