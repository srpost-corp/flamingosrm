package com.srpost.cm.bo.base.plan;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 일정 관리 서비스 구현체
 *
 * @author  finkle
 * @date    2016-04-15
 * @since   2.0
 */
@Service
public class PlanServiceImpl extends EgovAbstractServiceImpl implements IPlanService {

    @Resource
    PlanDao dao;

    @Override
    public List<PlanBean> list(PlanBean bean) {
        
        return dao.list(bean);
    }

    @Override
    public PlanBean view(PlanBean bean) {
        
        return dao.view(bean);
    }

    @Override
    public int insertAction(PlanBean bean) {
        
        return dao.insertAction(bean);
    }

    @Override
    public int updateAction(PlanBean bean) {
        
        return dao.updateAction(bean);
    }

    @Override
    public int deleteAction(PlanBean bean) {
        
        return dao.deleteAction(bean);
    }
}
