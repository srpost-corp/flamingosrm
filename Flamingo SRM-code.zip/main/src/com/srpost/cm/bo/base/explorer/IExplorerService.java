package com.srpost.cm.bo.base.explorer;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.bbs.core.BbsBean;
import com.srpost.cm.bo.base.faq.core.FaqBean;
import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.salmon.bean.BaseListBean;

/**
 * 익스플로러 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-12-18
 * @since   3.0
 */
public interface IExplorerService {

    /** 전체 업무현황 */
    Map<String, Integer> totWork(LoginBean loginBean);
    
    /** 내 업무현황 */
    Map<String, Integer> myWork(LoginBean loginBean);
    
    /** 처리상태별 SR 목록 */
    List<Map<String, VocBean>> statusList(String type);
    
    /** 이달의 일정 */
    List<Map<String, Object>> planList(Map<String, Object> parameterMap);
    
    /** 이달의 일정 - 현재날짜 기준 +- 1일 */
    Map<String, Object> calendar(String planDay);
    
    /** 주요 이슈 카테고리 */
    List<Map<String, Object>> vocCtgList(BaseListBean bean);
    
    /** 주요 이슈 태그 */
    List<Map<String, Object>> vocTagList(BaseListBean bean);

    
    List<BbsBean> listForDashboard(BbsBean bean);
    List<FaqBean> listForDashboard(FaqBean bean);
    
    /** 전사미결처리현황 */
    public List<Map<String, Object>> statusForChart();
    
    /** 최근 1달간 신청현황 그래프 */
    public List<Map<String, Object>> monthRegForChart();
    
    /** 월 평균 처리기간 (최근5개월) */
    public List<Map<String, Object>> endCntForChart();
    
    /** 월 평균 만족도 (최근5개월) */
    public Map<String, List<Map<String,Object>>> scoreCntForChart();
    
}
