package com.srpost.cm.bo.base.plan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 일정 관리 Util
 *
 * @author  finkle
 * @date    2016-04-15
 * @since   2.0
 */
public class PlanUtil {
    
    public static Map<String, Object> getParameterMap(PlanBean bean) {
        
        if ( StringUtil.isNotEmpty(bean.getStartDd()) )
            bean.setStartDd( DateTimeUtil.removeDash(bean.getStartDd()) );
        if ( StringUtil.isNotEmpty(bean.getEndDd()) )
            bean.setEndDd( DateTimeUtil.removeDash(bean.getEndDd()) );
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("startDd", bean.getStartDd());
        parameterMap.put("endDd", bean.getEndDd());
        
        return parameterMap;
    }
    
    public static void setNotNullValue(PlanBean bean) {

        if ( StringUtil.isNotEmpty(bean.getStartDd()) )
            bean.setStartDd( DateTimeUtil.removeDash(bean.getStartDd()) );
        if ( StringUtil.isNotEmpty(bean.getEndDd()) )
            bean.setEndDd( DateTimeUtil.removeDash(bean.getEndDd()) );
        
        /*
        if ( StringUtil.isEmpty(bean.getPrjMoney()) ) bean.setPrjMoney(ZERO);
        if ( StringUtil.isEmpty(bean.getVatYn()) ) bean.setVatYn(N);
        */
    }
    
    
    public static List<Map<String, Object>> convertList(List<PlanBean> dataList) {

        List<Map<String, Object>> jsonList = new ArrayList<Map<String, Object>>();

        for (PlanBean bean : dataList) {

            Map<String, Object> dataMap = new HashMap<String, Object>();
            
            dataMap.put("id", bean.getSeq());
            dataMap.put("title", bean.getTitle());
            /* dataMap.put("startTm", bean.getStartTm());
            dataMap.put("endTm", bean.getEndTm());
            dataMap.put("meetArea", bean.getMeetArea());
            dataMap.put("info", "[" + bean.getTypeNm() + "] " + bean.getTitle() + "&#13;" + 
                    bean.getStartDd() + " " + bean.getStartTm() + " ~ " + 
                    bean.getEndDd() + " " + bean.getEndTm() + "&#13;" + 
                    bean.getMeetArea()); */
            dataMap.put("typeCd", bean.getTypeCd());
            dataMap.put("typeNm", bean.getTypeNm());
            dataMap.put("mgrNm", bean.getMgrNm());
            dataMap.put("start", bean.getStartDd());
            dataMap.put("end", bean.getEndDd());
            dataMap.put("editable", false);
            dataMap.put("allDay", true);
            dataMap.put("color", getColor(bean.getTypeCd()));
            
            /*
             * url, className, color(background and border color), backgroundColor, borderColor, textColor
             */
            
            jsonList.add(dataMap);
        }
        
        return jsonList;
    }
    
    private static String getColor(String typeCd) {
        
        if ( StringUtil.equals(typeCd, "1") ) {
            return COLOR1;
        }
        else if ( StringUtil.equals(typeCd, "2") ) {
            return COLOR2;
        }
        else if ( StringUtil.equals(typeCd, "3") ) {
            return COLOR3;
        }
        else if ( StringUtil.equals(typeCd, "4") ) {
            return COLOR4;
        }
        
        return COLOR5;
    }
    
    public static final String COLOR1 = "#FFD8D8";
    public static final String COLOR2 = "#FFFFA2";
    public static final String COLOR3 = "#D4F4FA";
    public static final String COLOR4 = "#A8E29C";
    public static final String COLOR5 = "#EAEAEA";
}
