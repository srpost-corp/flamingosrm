package com.srpost.cm.bo.base.plan;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.spi.egov.ISalmonSeqGenerator;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 일정 관리 DAO
 *
 * @author  finkle
 * @date    2016-04-15
 * @since   2.0
 */
@Repository
public class PlanDao extends EgovAbstractMapper {

    @Resource(name = "planSeqGenerator")
    ISalmonSeqGenerator seqGenerator;
    
    public List<PlanBean> list(PlanBean bean) {

        Map<String, Object> parameterMap = PlanUtil.getParameterMap(bean);

        return selectList("_plan.list", parameterMap);
    }
    
    public PlanBean view(PlanBean bean) {
        
        return selectOne("_plan.view", bean);
    }

    public int insertAction(PlanBean bean) {

        PlanUtil.setNotNullValue(bean);
        bean.setSeq(seqGenerator.getNextInteger());
        
        return insert("_plan.insert", bean);
    }

    public int updateAction(PlanBean bean) {

        PlanUtil.setNotNullValue(bean);
        
        return update("_plan.update", bean);
    }

    public int deleteAction(PlanBean bean) {
        
        return delete("_plan.delete", bean);
    }
}
