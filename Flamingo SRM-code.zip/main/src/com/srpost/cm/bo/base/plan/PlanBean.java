package com.srpost.cm.bo.base.plan;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseListBean;


/**
 * 일정관리 정보 Bean
 *
 * @author  finkle
 * @date    2016-04-15
 * @since   3.0
 */
@Alias("planBean")
@SuppressWarnings("serial")
public class PlanBean extends BaseListBean {

    /** 일련번호 */
    private Integer seq;
    /** 유형_코드 */
    private String typeCd;
    /** 유형_명 */
    private String typeNm;
    /** 제목 */
    private String title;
    /** 내용 */
    private String planContents;
    /** 시작일시 */
    private String startDd;
    /** 종료일시 */
    private String endDd;
    /** 담당자_ID */
    private String mgrId;
    /** 담당자_명 */
    private String mgrNm;
    /** 등록일시 */
    private String regDt;
    /** 수정일시 */
    private String modiDt;
    
    
    public Integer getSeq() {
        return seq;
    }
    public void setSeq(Integer seq) {
        this.seq = seq;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getStartDd() {
        return startDd;
    }
    public void setStartDd(String startDd) {
        this.startDd = startDd;
    }
    public String getEndDd() {
        return endDd;
    }
    public void setEndDd(String endDd) {
        this.endDd = endDd;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
    public String getModiDt() {
        return modiDt;
    }
    public void setModiDt(String modiDt) {
        this.modiDt = modiDt;
    }
    public String getMgrNm() {
        return mgrNm;
    }
    public void setMgrNm(String mgrNm) {
        this.mgrNm = mgrNm;
    }
    public String getTypeCd() {
        return typeCd;
    }
    public void setTypeCd(String typeCd) {
        this.typeCd = typeCd;
    }
    public String getTypeNm() {
        return typeNm;
    }
    public void setTypeNm(String typeNm) {
        this.typeNm = typeNm;
    }
    public String getPlanContents() {
        return planContents;
    }
    public void setPlanContents(String planContents) {
        this.planContents = planContents;
    }
}
