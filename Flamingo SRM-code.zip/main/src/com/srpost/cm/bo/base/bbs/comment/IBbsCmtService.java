package com.srpost.cm.bo.base.bbs.comment;

import java.util.List;

/**
 * 내부단 게시판 의견글 서비스 인터페이스
 *
 * @author  finkle
 * @date    2015-01-23
 * @since   2.0
 */
public interface IBbsCmtService {

    List<BbsCmtBean> list(BbsCmtBean bean);
    
    BbsCmtBean view(BbsCmtBean bean);

    int insertAction(BbsCmtBean bean);

    int updateAction(BbsCmtBean bean);

    int replyAction(BbsCmtBean bean);

    int deleteAction(BbsCmtBean bean);
}
