package com.srpost.cm.bo.base.explorer;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.cm.bo.base.bbs.core.BbsBean;
import com.srpost.cm.bo.base.faq.core.FaqBean;
import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.core.IVocService;
import com.srpost.salmon.bean.BaseListBean;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 내부단 익스플로러 컨트롤러
 *
 * @author  finkle
 * @date    2014-10-22
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/explorer")
public class ExplorerController extends BaseController {
    
    @Resource
    IExplorerService service;
    @Resource
    IVocService vocService;
    
	/**
     * 익스플로러
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index(ModelMap model) {
        
        // SR 이슈 태그
        BaseListBean bean = new BaseListBean();
        model.addAttribute("vocTagList", service.vocTagList(bean));

        // 주요 이슈 카테고리
        bean = new BaseListBean();
        bean.setRowPerPage(5);
        model.addAttribute("vocCtgList", service.vocCtgList(bean));
        
        // 자료실
        BbsBean bbsBean = new BbsBean();
        bbsBean.setRowPerPage(5);
        bbsBean.setBbsCd(2);
        model.addAttribute("bbsList", service.listForDashboard(bbsBean));
        
        // 공지사항
        bbsBean = new BbsBean();
        bbsBean.setRowPerPage(5);
        bbsBean.setBbsCd(1);
        model.addAttribute("ntcList", service.listForDashboard(bbsBean));
    }
    
    /**
     * 익스플로러 : 전체 업무현황
     */
    @RequestMapping(value="j_totWork.do", method=RequestMethod.GET)
    public ModelAndView totWork(HttpServletRequest request, ModelMap model) {
        
        LoginBean loginBean = MgrUtil.getSession(request);
        
        return responseJson(model, service.totWork(loginBean));
    }
    
    /**
     * 익스플로러 : 내 업무현황
     */
    @RequestMapping(value="j_myWork.do", method=RequestMethod.GET)
    public ModelAndView myWork(HttpServletRequest request, ModelMap model) {
        
        LoginBean loginBean = MgrUtil.getSession(request);
        
        return responseJson(model, service.myWork(loginBean));
    }
    
    /**
     * 익스플로러 : 처리상태별 SR 목록
     */
    @RequestMapping(value="a_statusList.do", method=RequestMethod.GET)
    public void statusList(HttpServletRequest request, ModelMap model, 
            @RequestParam(value="type", required=false, defaultValue="") String type) {
        
        model.addAttribute("vocStatusList", service.statusList(type));
    }
    
    /**
     * 익스플로러 : 이달의 일정
     */
    @RequestMapping(value="a_planList.do", method=RequestMethod.GET)
    public void planList(HttpServletRequest request, ModelMap model, 
            @RequestParam(value="planDay", required=false, defaultValue="") String planDay) {
        
        if (StringUtil.isEmpty(planDay)) {
            planDay = DateTimeUtil.getTodayShort();
        }
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("pagingStartNum", 1);
        parameterMap.put("pagingEndNum", 5);
        parameterMap.put("planDay", planDay);
        
        model.addAttribute("planList", service.planList(parameterMap));
        model.addAttribute("calendar", service.calendar(planDay));
    }
    
    /**
     * 익스플로러 : 최근 FAQ 목록
     */
    @RequestMapping(value="a_faqList.do", method=RequestMethod.GET)
    public void faqList(ModelMap model) {
        
        FaqBean faqBean = new FaqBean();
        faqBean.setRowPerPage(5);
        
        model.addAttribute("faqList", service.listForDashboard(faqBean));
    }
    
    /**
     * 익스플로러 : 차트
     */
    @RequestMapping(value="a_chart.do", method=RequestMethod.GET)
    public void chart(HttpServletRequest request, ModelMap model, 
            @RequestParam(value="type", required=false, defaultValue="") String type) {
        
        if (StringUtil.isEmpty(type)) {
            return;
        }
        
        if (StringUtil.equals(type, "stat")) {
            model.addAttribute("dataList", service.statusForChart());
        }
        else if (StringUtil.equals(type, "month")) {
            model.addAttribute("dataList", service.monthRegForChart());
        }
        else if (StringUtil.equals(type, "end")) {
            model.addAttribute("dataList", service.endCntForChart());
        }
        else if (StringUtil.equals(type, "score")) {
            model.addAttribute("dataList", service.scoreCntForChart());
        }
        else {
            return;
        }
    }
}
