package com.srpost.cm.bo.base.plan;

import java.util.List;

/**
 * 내부단 일정 관리 서비스 인터페이스
 *
 * @author  finkle
 * @date    2016-04-15
 * @since   2.0
 */
public interface IPlanService {
    
    List<PlanBean> list(PlanBean bean);
    
    PlanBean view(PlanBean bean);
    
    int insertAction(PlanBean bean);
    
    int updateAction(PlanBean bean);
    
    int deleteAction(PlanBean bean);
}
