package com.srpost.cm.bo.sr.svc.ctr.ctrModal;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 계약 모달 정보 Bean
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Alias("ctrModalBean")
@SuppressWarnings("serial")
public class CtrModalBean extends BaseBean {

}
