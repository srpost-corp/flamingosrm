package com.srpost.cm.bo.sr.stat.d3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 VOC 통계(D3) Util
 *
 * @author  finkle
 * @date    2016-07-20
 * @since   3.0
 */
public final class D3StatUtil {

    public static Map<String, Object> getParameterMap(StatTypeSearchBean bean) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();

        parameterMap.put("endMsCd", VocConstant.MS_END);
        if ( StringUtil.isNotEmpty(bean.getVocCd()) ) {
            parameterMap.put("vocCd", bean.getVocCd());
        }

        if ( StringUtil.isNotEmpty(bean.getStartDd()) )
            parameterMap.put("startDd", DateTimeUtil.removeDash(bean.getStartDd()));
        if ( StringUtil.isNotEmpty(bean.getEndDd()) )
            parameterMap.put("endDd", DateTimeUtil.removeDash(bean.getEndDd()));
        
        return parameterMap;
    }
    
    
    public static Map<String, Object> getPagerMap(D3StatParameterBean bean) {

        Map<String, Object> parameterMap = bean.createPagerMap();
        parameterMap.put("endMsCd", VocConstant.MS_END);
        if ( StringUtil.isNotEmpty(bean.getVocCd()) ) {
            parameterMap.put("vocCd", bean.getVocCd());
        }
        
        if ( StringUtil.isNotEmpty(bean.getStartDt()) )
            parameterMap.put("startDt", DateTimeUtil.removeDash(bean.getStartDt()));
        if ( StringUtil.isNotEmpty(bean.getEndDt()) )
            parameterMap.put("endDt", DateTimeUtil.removeDash(bean.getEndDt()));
        
        if ( StringUtil.isNotEmpty(bean.getHour()) ) {
            String[] hourz = StringUtil.split(bean.getHour(), ",");
            List<String> hours = new ArrayList<String>();
            for (int i=0 ; i < hourz.length ; i++) {
                int _hour = Integer.parseInt(StringUtils.substringBefore(hourz[i], "."));
                if ( _hour == 7 ) {
                    hours.add("00"); hours.add("01"); hours.add("02"); hours.add("03"); 
                    hours.add("04"); hours.add("05"); hours.add("06"); hours.add("07");
                }
                else if ( _hour == 21 ) {
                    hours.add("21"); hours.add("22"); hours.add("23"); hours.add("24");
                }
                else {
                    hours.add(String.valueOf(_hour < 10 ? "0" + _hour : _hour));
                }
            }
            parameterMap.put("hours", hours.toArray(new String[hours.size()]) );
        }
        if ( StringUtil.isNotEmpty(bean.getDow()) ) {
            String[] dowz = StringUtil.split(bean.getDow(), ",");
            String[] dows = new String[dowz.length];
            for (int i=0 ; i < dowz.length ; i++) {
                dows[i] = StringUtils.substringBefore(dowz[i], ".");
            }
            parameterMap.put("dows", dows );
        }
        if ( StringUtil.isNotEmpty(bean.getQuarter()) ) {
            String[] quarterz = StringUtil.split(bean.getQuarter(), ",");
            List<String> quarters = new ArrayList<String>();
            for (int i=0 ; i < quarterz.length ; i++) {
                String _qt = StringUtil.substring(quarterz[i], 0, 1);
                if ( StringUtil.equals("1", _qt) ) {
                    quarters.add("01"); quarters.add("02"); quarters.add("03");
                }
                else if ( StringUtil.equals("2", _qt) ) {
                    quarters.add("04"); quarters.add("05"); quarters.add("06");
                }
                else if ( StringUtil.equals("3", _qt) ) {
                    quarters.add("07"); quarters.add("08"); quarters.add("09");
                }
                else if ( StringUtil.equals("4", _qt) ) {
                    quarters.add("10"); quarters.add("11"); quarters.add("12");
                }
            }
            parameterMap.put("quarters", quarters.toArray(new String[quarters.size()]) );
        }
        
        if ( StringUtil.isNotEmpty(bean.getFromCd()) ) {
            parameterMap.put("fromNms", StringUtil.split(bean.getFromCd(), ",") );
        }
        if ( StringUtil.isNotEmpty(bean.getTypeCd()) ) {
            parameterMap.put("typeNms", StringUtil.split(bean.getTypeCd(), ",") );
        }
        if ( StringUtil.isNotEmpty(bean.getKindCd()) ) {
            parameterMap.put("kindNms", StringUtil.split(bean.getKindCd(), ",") );
        }
        if ( StringUtil.isNotEmpty(bean.getEndCd()) ) {
            parameterMap.put("endNms", StringUtil.split(bean.getEndCd(), ",") );
        }
        
        return parameterMap;
    }
}
