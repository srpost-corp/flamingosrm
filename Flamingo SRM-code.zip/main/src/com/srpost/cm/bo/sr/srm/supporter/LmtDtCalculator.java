package com.srpost.cm.bo.sr.srm.supporter;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import com.srpost.cm.bo.base.hday.HdayBean;
import com.srpost.cm.bo.base.hday.HdayCache;
import com.srpost.cm.bo.base.hday.HdayUtil;
import com.srpost.cm.bo.base.hday.Lunar;
import com.srpost.cm.bo.sr.srm.conf.VocConfBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.salmon.cache.Cache;
import com.srpost.salmon.constant.Config;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

import static com.srpost.salmon.constant.StringPool.*;

/**
 * VOC 처리기한 계산기
 *
 * @author  finkle
 * @date    2014-12-01
 * @since   3.0
 */
@SuppressWarnings("unchecked")
public class LmtDtCalculator {

    /** 토요 휴일 산입여부 */
    protected static final boolean IS_CALC_SATURDAY = Config.getBoolean("voc.holiday.calcSaturday", true);
    /** 퇴근시간 산입여부 */
    protected static final boolean IS_CALC_LEAVE_TIME = Config.getBoolean("voc.holiday.calcLeaveTime", true);
    /** 퇴근시간, hours */
    protected static final int LEAVE_TIME = Config.getInt("voc.holiday.leaveTime", 18);
    /** 처리소요시간 계산 시 공휴일 제외 여부 */
    protected static final boolean IS_HOLIDAY_FOR_END_CNT = Config.getBoolean("voc.holiday.holidayForEndCnt", true);
    
    /* 퇴근시간 산입되었는지 여부 */
    private boolean calculateLeaveTime = false;
    /* 처리기한 */
    private String lmtDt;
    /* VOC 설정 정보 */
    private VocConfBean confBean;
    /* 휴일 목록 */
    protected List<HdayBean> hdayList;
    /* 처리기산 산정 로그 */
    private StringBuilder lmtDtLog = new StringBuilder();

    public LmtDtCalculator() {
        this.hdayList = (List<HdayBean>)Cache.get(HdayCache.LIST_KEY);
    }
    public LmtDtCalculator(VocBean bean) {
        this(bean, null);
    }
    public LmtDtCalculator(VocBean bean, String startDd) {
        
        this.hdayList = (List<HdayBean>)Cache.get(HdayCache.LIST_KEY);
        
        if (StringUtil.isNotEmpty(bean.getLmtDt())) {
            this.lmtDt = DateTimeUtil.removeDash(bean.getLmtDt());
        }
       
        this.confBean = VocUtil.getConfBean(bean.getVocCd());
        
        calculateLmtDt(startDd);
    }
    
    /**
     * 계산된 처리기한 획득
     */
    public String getLmtDt() {

        if ( StringUtil.isEmpty(lmtDt) ) return EMPTY;

        /* 퇴근시간이 산입되었다면 HHmmss값에 235959 설정 */
        if ( calculateLeaveTime ) {
            if (lmtDt.length() == 8) lmtDt = lmtDt + "235959";
            else lmtDt = lmtDt.substring(0, 8) + "235959";
        }
        /* 시간포함 = 'Y'일 경우 HHmmss값에 현재 HHmmss값 설정 */
        else if ( StringUtil.equals(confBean.getTimeYn(), Y) ) {
            
            if (lmtDt.length() == 8) {
                String today = DateTimeUtil.getToday();
                
                lmtDt = lmtDt + today.substring(8);
            }
        }
        /* 퇴근시간 미산입 및 시간포함 = 'N' 일 경우 강제로 235959 설정 */
        else {
            if (lmtDt.length() == 8) lmtDt = lmtDt + "235959";
            else lmtDt = lmtDt.substring(0, 8) + "235959";
        }
        
        return lmtDt;
    }
    
    /**
     * 계산된 처리기한 산정 로그 얻기
     */
    public String getLmtDtLog() {        
        return lmtDtLog.toString();
    }
    
    /*
     * VOC 처리기한 계산
     */
    private void calculateLmtDt(String startDd) {

        if ( StringUtil.isNotEmpty(lmtDt) ) return;
        
        int dealDayCnt = confBean.getDealDayCnt(); 
                
        if ( dealDayCnt < ONE ) return;
        
        Calendar now = 
                StringUtil.isEmpty(startDd) ? 
                        Calendar.getInstance() : DateTimeUtil.toCalendar(startDd);
                
        Calendar target = (Calendar)now.clone();
        
        // 퇴근시간 계산
        if (IS_CALC_LEAVE_TIME) {
            if ( !isHoliday(now, false) ) {
                int currentHour = now.get(Calendar.HOUR_OF_DAY);
                if ( LEAVE_TIME <= currentHour ) {
                    lmtDtLog.append( parseLogData(target, "평일 퇴근시간 산입") );
                    target.add(Calendar.DATE, 1);
                    now.add(Calendar.DATE, 1);
                    
                    calculateLeaveTime = true;
                }
            }
        }

        int loopCnt = dealDayCnt;

        int j = 1;

        // 휴일 계산
        for (int i=1 ; i <= loopCnt ; i++) {

            if ( isHoliday(now) ) {
                target.add(Calendar.DATE, 1);
                loopCnt++;
            }
            else {
                lmtDtLog.append( parseLogData(now, (j++) + "일") );
            }
            
            if (j > dealDayCnt) {
                target.add(Calendar.DATE, -1);
                break;	
            }
            now.add(Calendar.DATE, 1);
        }

        target.add(Calendar.DATE, j - 1);

        lmtDt = DateTimeUtil.toDateFullISO(recursiveCalculateLmtDt(target));
    }

    private Calendar recursiveCalculateLmtDt(Calendar target) {
        
        if ( isHoliday(target) ) {
            target.add(Calendar.DATE, 1);
            return ( recursiveCalculateLmtDt(target) );
        }
        return target;
    }
    
    /*
     * 지정한 날짜가 휴일인지 판단
     */
    protected boolean isHoliday(Calendar target) {
        return isHoliday(target, true);
    }
    protected boolean isHoliday(Calendar target, boolean logging) {
        
        if (StringUtil.isNotEmpty(hdayList)) {
            
            for (HdayBean item : hdayList) {
                
                if (item.getCycle() == HdayUtil.EVERY_WEEK) {
                    if (
                        (item.getWeek() == ZERO || /* 매주 */
                                target.get(Calendar.WEEK_OF_MONTH) == item.getWeek()) && 
                            target.get(Calendar.DAY_OF_WEEK) == item.getDow()) 
                    {
                        if (logging) lmtDtLog.append( parseLogData(target, item.getHdayNm()) );
                        return true;
                    }
                }
                else {
                    Calendar start = DateTimeUtil.toCalendar(item.getStartDd());
                    Calendar end = DateTimeUtil.toCalendar(item.getEndDd());
                    
                    if (item.getCycle() == HdayUtil.NO_CYCLE) {
                        if ( isContains(target, start, end) ) {
                            if (logging) lmtDtLog.append( parseLogData(target, item.getHdayNm()) );
                            return true; /* 대상일자가 공휴일 시작, 종료일자 구간에 포함됨 */
                        }
                    }
                    else if (item.getCycle() == HdayUtil.EVERY_MONTH) {
                        
                        int targetDay = target.get(Calendar.DAY_OF_MONTH);
                        int startDay = start.get(Calendar.DAY_OF_MONTH);
                        int endDay = end.get(Calendar.DAY_OF_MONTH);
                        
                        if (startDay <= targetDay && endDay >= targetDay) {
                            if (logging) lmtDtLog.append( parseLogData(target, item.getHdayNm()) );
                            return true; /* 대상일자가 대상월(月) 시작, 종료일자 구간에 포함됨 */
                        }
                    }
                    else if (item.getCycle() == HdayUtil.EVERY_YEAR) {
    
                        if (StringUtil.equals(item.getLunarYn(), Y)) {
                            
                            boolean isBigHoliday = isBigHoliday(start);
                            
                            start = toSolar(start);
                            end = toSolar(end);
                            
                            // 구정, 추석은 당일의 전, 후일 모두 휴일처리 (연휴 3일로 계산)
                            if ( isBigHoliday ) {
                                start.add(Calendar.DAY_OF_MONTH, -1);
                                end.add(Calendar.DAY_OF_MONTH, 1);
                            }
                        }
    
                        if( isContainsForRemoveYear(target, start, end) ) {
                            if (logging) lmtDtLog.append( parseLogData(target, item.getHdayNm()) );
                            return true; /* 대상일자가 대상월(月), 일(日) 시작, 종료일자 구간에 포함됨 */
                        }
                    }
                }
            }
        }
        
        // 토요일 계산
        if (target.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
            if (IS_CALC_SATURDAY) {
                if (logging) lmtDtLog.append( parseLogData(target, "토요일") );
                return true;
            }
        }
        // 일요일 계산
        else if (target.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            if (logging) lmtDtLog.append( parseLogData(target, "일요일") );
            return true;
        }
        
        return false;
    }
    
    /*
     * 지정한 날짜가 지정한 시작 ~ 종료일 구간에 포함되는지 확인
     */
    private boolean isContains(Calendar target, Calendar start, Calendar end) {
        
        int iTarget = Integer.parseInt(DateTimeUtil.totDateShortISO(target));
        int iStart = Integer.parseInt(DateTimeUtil.totDateShortISO(start));
        int iEnd = Integer.parseInt(DateTimeUtil.totDateShortISO(end));
        
        return iTarget >= iStart && iTarget <= iEnd;
    }
    private boolean isContainsForRemoveYear(Calendar target, Calendar start, Calendar end) {
        
        SimpleDateFormat sdFormat = new SimpleDateFormat("MMdd");
        
        int iTarget = Integer.parseInt(sdFormat.format(target.getTime()));
        int iStart = Integer.parseInt(sdFormat.format(start.getTime()));
        int iEnd = Integer.parseInt(sdFormat.format(end.getTime()));
        
        return iTarget >= iStart && iTarget <= iEnd;
    }
    
    /*
     * 지정한 날짜가 구정, 추석인지 확인
     */
    private boolean isBigHoliday(Calendar target) {
        
        int month = target.get(Calendar.MONTH) + 1;
        int day = target.get(Calendar.DAY_OF_MONTH);
        
        // 구정
        if (month == 1 && day == 1) return true;
        // 추석
        else if (month == 8 && day == 15) return true;

        return false;
    }
    
    /*
     * 지정한 날짜를 음력날짜로 변환
     */
    private Calendar toSolar(Calendar target) {
        
        Calendar now = Calendar.getInstance();
        Calendar lunar = (Calendar)target.clone();
        
        lunar.set(Calendar.YEAR, now.get(Calendar.YEAR));

        return DateTimeUtil.toCalendar( 
                Lunar.toSolar(DateTimeUtil.totDateShortISO(lunar), false) );
    }

    private String parseLogData(Calendar target, String day) {
        return DateTimeUtil.totDateShort(target.getTime()) + " : " + day + "\n";
    }
}
