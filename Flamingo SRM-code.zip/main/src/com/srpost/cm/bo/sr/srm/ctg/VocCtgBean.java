package com.srpost.cm.bo.sr.srm.ctg;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseTreeBean;
import com.srpost.salmon.constant.Constant;

/**
 * 내부단 VOC분류 정보 Bean
 *
 * @author  finkle
 * @date    2014-11-20
 * @since   2.0
 */
@Alias("vocCtgBean")
@SuppressWarnings("serial")
public class VocCtgBean extends BaseTreeBean {
    
    /** 디폴트 최상위 분류코드 */
    private String topCtgCd = Constant.TOP_CTG_CD;
    
    /** 카테고리_코드 */
    private String vocCtgCd;
    /** 카테고리_명 */
    private String ctgNm;
    /** 상위_카테고리_코드 */
    private String highVocCtgCd;
    /** 상위_카테고리_명 */
    private String highCtgNm;
    /** 정렬_순서 */
    private Integer orderNo;
    /** 사용_여부 */
    private String useYn;
    /** 등록_일시 */
    private String regDt;
    /** 수정_일시 */
    private String modiDt;
    
    
    public String getTopCtgCd() {
        return topCtgCd;
    }
    public void setTopCtgCd(String topCtgCd) {
        this.topCtgCd = topCtgCd;
    }
    public String getCtgNm() {
        return ctgNm;
    }
    public void setCtgNm(String ctgNm) {
        this.ctgNm = ctgNm;
    }
    public String getHighCtgNm() {
        return highCtgNm;
    }
    public void setHighCtgNm(String highCtgNm) {
        this.highCtgNm = highCtgNm;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public String getUseYn() {
        return useYn;
    }
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
    public String getModiDt() {
        return modiDt;
    }
    public void setModiDt(String modiDt) {
        this.modiDt = modiDt;
    }
    public String getVocCtgCd() {
        return vocCtgCd;
    }
    public void setVocCtgCd(String vocCtgCd) {
        this.vocCtgCd = vocCtgCd;
    }
    public String getHighVocCtgCd() {
        return highVocCtgCd;
    }
    public void setHighVocCtgCd(String highVocCtgCd) {
        this.highVocCtgCd = highVocCtgCd;
    }
}
