package com.srpost.cm.bo.sr.srm.core.debug;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 디버그용 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-04
 * @since   3.0
 */
@Service
public class VocDebugServiceImpl extends EgovAbstractServiceImpl implements IVocDebugService {

    @Resource
    VocDebugDao dao;

    @Override
    public List<VocDivBean> listDiv(Integer vocSeq) {
        
        return dao.listDiv(vocSeq);
    }
    
    @Override
    public List<VocSancBean> listSanc(Integer vocSeq) {
        
        return dao.listSanc(vocSeq);
    }
    
    @Override
    public List<Map<String, Object>> listEntry(Integer vocSeq) {
        
        return dao.listEntry(vocSeq);
    }
}
