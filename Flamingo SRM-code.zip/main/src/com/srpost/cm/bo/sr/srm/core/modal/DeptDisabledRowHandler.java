package com.srpost.cm.bo.sr.srm.core.modal;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.ArrayList;
import java.util.List;

import jodd.util.ArraysUtil;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

import com.srpost.cm.bo.base.dept.DeptBean;
import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 부서 TREE Disabled 목록 row handler
 *
 * @author  finkle
 * @date    2014-12-08
 * @since   3.0
 */
public class DeptDisabledRowHandler implements ResultHandler {

	private List<DeptBean> list;
	private String[] deptCds;

    public DeptDisabledRowHandler(String deptCds) {
    	
    	list = new ArrayList<DeptBean>();
    	this.deptCds = StringUtil.split(deptCds, COMMA);
    }
    
    @Override
    public void handleResult(ResultContext context) {
        
        DeptBean dataBean = (DeptBean)context.getResultObject();
        
        if ( StringUtil.isNotEmpty(deptCds) && ArraysUtil.contains(deptCds, dataBean.getId()) ) {
            dataBean.setDisabled(TRUE);
        }

        list.add(dataBean);
    }
    
    public List<DeptBean> getList() {
        
        return list;
    }
}