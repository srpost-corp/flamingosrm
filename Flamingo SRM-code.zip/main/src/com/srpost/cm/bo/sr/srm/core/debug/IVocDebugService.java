package com.srpost.cm.bo.sr.srm.core.debug;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;

/**
 * 내부단 VOC 디버그용 인터페이스
 *
 * @author  finkle
 * @date    2014-12-04
 * @since   3.0
 */
public interface IVocDebugService {

    List<VocDivBean> listDiv(Integer vocSeq);
    
    List<VocSancBean> listSanc(Integer vocSeq);

    List<Map<String, Object>> listEntry(Integer vocSeq);
}
