package com.srpost.cm.bo.sr.search;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 검색 DAO
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   2.0
 */
@Repository
public class SearchDao extends EgovAbstractMapper {

    public List<String> keywordList(String keyword) {

        return selectList("_search.keywordList", keyword);
    }

    public List<String> favoliteList() {

        return selectList("_search.favoliteList");
    }

    public int insertAction(String keyword) {

        return insert("_search.insert", keyword);
    }
}
