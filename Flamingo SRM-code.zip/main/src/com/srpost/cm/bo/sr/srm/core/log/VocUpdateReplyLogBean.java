package com.srpost.cm.bo.sr.srm.core.log;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 내부단 VOC 답변내용 수정 로그 정보 Bean
 *
 * @author  finkle
 * @date    2015-01-06
 * @since   3.0
 */
@Alias("vocUpdateReplyLogBean")
@SuppressWarnings("serial")
public class VocUpdateReplyLogBean extends BaseBean {

    /** VOC_일련번호 */
    private Integer vocSeq;
    /** 정렬_순서 */
    private Integer orderNo;
    /** 답변 수정 내용 */
    private String reply;
    
    
    public Integer getVocSeq() {
        return vocSeq;
    }
    public void setVocSeq(Integer vocSeq) {
        this.vocSeq = vocSeq;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public String getReply() {
        return reply;
    }
    public void setReply(String reply) {
        this.reply = reply;
    }
}
