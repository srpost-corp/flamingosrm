package com.srpost.cm.bo.sr.srm.core.tags;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.cm.bo.sr.srm.core.IVocService;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 내부단 VOC TAG 컨트롤러
 *
 * @author  finkle
 * @date    2014-12-19
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/srm/core/tags")
public class VocTagsController extends BaseController {

    @Resource
    IVocTagsService service;
    @Resource
    IVocService vocService;
    
    
    /**
     * 
     */
    @RequestMapping(value="j_list.do", method=RequestMethod.GET)
    public ModelAndView list(@RequestParam(required=true) String tag, ModelMap model) {

        List<String> searchList = service.listSearch(tag);
        if (StringUtil.isEmpty(searchList))
            searchList = new ArrayList<String>();
        
        List<Map<String, String>> tagList = new ArrayList<Map<String, String>>();
        for (String item : searchList) {
            Map<String, String> itemMap = new HashMap<String, String>();
            itemMap.put("tag", item);            
            tagList.add(itemMap);
        }
        
        Map<String, List<Map<String, String>>> jsonMap = new HashMap<String, List<Map<String, String>>>();
        jsonMap.put("tags", tagList);
        
        return responseJson(model, jsonMap);
    }
}
