package com.srpost.cm.bo.sr.srm.core.alim;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.tpl.TplUtil;
import com.srpost.salmon.constant.Constant;
import com.srpost.salmon.constant.Message;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.crypto.SalmonCrypto;
import com.srpost.salmon.spi.sender.ISalmonMessageSender;

import static com.srpost.salmon.constant.StringPool.EMPTY;
import static com.srpost.salmon.constant.StringPool.MINUS_ONE;
import static com.srpost.salmon.constant.StringPool.Y;

/**
 * VOC 알림 메시지 handler
 *
 * @author  finkle
 * @date    2014-12-16
 * @since   3.0
 */
public class VocAlimHandler {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    SalmonCrypto salmonCtypto;
    @Resource
    VocAlimMessageParser messageParser;
    @Resource
    IVocAlimService service;
    
    protected Map<String, ISalmonMessageSender> senderMap;
    
    
    public void execute(VocAlimMap alimMap) {

        if (StringUtil.isEmpty(senderMap)) return;

        /*-------------------------
         * 정보 추출
         */
        String actionCd = alimMap.getActionCd();
        VocBean dataBean = alimMap.getVocBean();
        List<MgrBean> mgrList = alimMap.getMgrList();
        MgrBean mgrBean = alimMap.getMgrBean();

        /*-------------------------
         * 알림 메시지 파싱
         */
        messageParser.extraValuables(alimMap);

        String mgrEmailTitle = EMPTY;
        String mgrSmsContents = EMPTY;
        String mgrEmailContents = EMPTY;
        if (StringUtil.isNotEmpty(mgrList)) {
            mgrEmailTitle = messageParser.getTitle(TplUtil.KIND_MGR, Constant.ALIM_EMAIL, actionCd);
            mgrSmsContents = messageParser.getTitle(TplUtil.KIND_MGR, Constant.ALIM_MOBILE, actionCd);
            
            alimMap.put("mgrEmailTitle", mgrEmailTitle);
            
            mgrEmailContents = messageParser.getContents(TplUtil.KIND_MGR, alimMap);
        }
        
        String userEmailTitle = EMPTY;
        String userSmsContents = EMPTY;
        String userEmailContents = EMPTY;
        if (StringUtil.isNotEmpty(mgrBean)) {
            userEmailTitle = messageParser.getTitle(TplUtil.KIND_USER, Constant.ALIM_EMAIL, actionCd);
            userSmsContents = messageParser.getTitle(TplUtil.KIND_USER, Constant.ALIM_MOBILE, actionCd);
            
            alimMap.put("userEmailTitle", userEmailTitle);
            
            userEmailContents = messageParser.getContents(TplUtil.KIND_USER, alimMap);
        }        
        
        /*-------------------------
         * 전송
         */
        Iterator<String> keys = senderMap.keySet().iterator();
        
        while (keys.hasNext()) {
            
            String key = keys.next();
            ISalmonMessageSender sender = senderMap.get(key);
            
            if (StringUtil.equals(key, Constant.ALIM_EMAIL)) {

                if (mgrList != null) {
                    for (MgrBean item : mgrList) {
                        if (StringUtil.equals(item.getEmailYn(), Y) && StringUtil.isNotEmpty(item.getEmail())) {                            
                            sendInternal(sender, dataBean.getVocSeq(), key, item.getMgrNm(), item.getMgrId(),
                                    EMPTY, item.getEmail(), mgrEmailTitle, mgrEmailContents);
                        }
                    }
                }
                if (mgrBean != null && StringUtil.isNotEmpty(dataBean.getAlertCds())) {
                    if (dataBean.getAlertCds().indexOf(Constant.ALIM_EMAIL) != -1 
                            && StringUtil.isNotEmpty(mgrBean.getEmail())) {

                        sendInternal(sender, dataBean.getVocSeq(), key, mgrBean.getMgrNm(), mgrBean.getMgrId(),
                                EMPTY, mgrBean.getEmail(), userEmailTitle, userEmailContents);
                    }
                }
            }
            else if (StringUtil.equals(key, Constant.ALIM_MOBILE)) {

                if (mgrList != null) {
                    for (MgrBean item : mgrList) {
                        if (StringUtil.equals(item.getSmsYn(), Y) && StringUtil.isNotEmpty(item.getMobile())) {                            
                            sendInternal(sender, dataBean.getVocSeq(), key, item.getMgrNm(), item.getMgrId(),
                                    item.getMobile(), EMPTY, mgrSmsContents);
                        }
                    }
                }
                if (mgrBean != null && StringUtil.isNotEmpty(dataBean.getAlertCds())) {
                    if (dataBean.getAlertCds().indexOf(Constant.ALIM_MOBILE) != -1 
                            && StringUtil.isNotEmpty(mgrBean.getMobile())) {       
                        
                        sendInternal(sender, dataBean.getVocSeq(), key, mgrBean.getMgrNm(), mgrBean.getMgrId(),
                                mgrBean.getMobile(), EMPTY, userSmsContents);
                    }
                }
            }
            else if (StringUtil.equals(key, Constant.ALIM_OTHERS)) {
                
                /* TODO */
            }
        }
    }

    
    
    private void sendInternal(ISalmonMessageSender sender, Integer vocSeq,
            String alertCd, String rcvNm, String mgrId, String mobile, String email, String title) {
        
        sendInternal(sender, vocSeq, alertCd, rcvNm, mgrId, mobile, email, title, EMPTY);
    }
    private void sendInternal(ISalmonMessageSender sender, Integer vocSeq,
            String alertCd, String rcvNm, String mgrId, String mobile, String email, String title, String contents) {

        Map<String, Object> alimValuableMap = new HashMap<String, Object>();
        
        if (StringUtil.equals(alertCd, Constant.ALIM_EMAIL)) {
            if (StringUtil.isEmpty(title) || StringUtil.isEmpty(contents)) {
                return;
            }
            alimValuableMap.put(ISalmonMessageSender.KEY_TO, rcvNm + "<" + email + ">");
            alimValuableMap.put(ISalmonMessageSender.KEY_SUBJECT, title);
            alimValuableMap.put(ISalmonMessageSender.KEY_CONTENTS, contents);
        }
        else if (StringUtil.equals(alertCd, Constant.ALIM_MOBILE)) {
            if (StringUtil.isEmpty(title)) {
                return;
            }
            alimValuableMap.put(ISalmonMessageSender.KEY_TO, mobile);
            alimValuableMap.put(ISalmonMessageSender.KEY_CONTENTS, title);
        }
        else {
            return;
        }
        
        /*----------------------------- 
         * 메시지 전송
         */
        String result = sender.send(alimValuableMap);
        
        /*----------------------------- 
         * 알림 결과 등록 : VOC_ALIM_LOG 
         */
        VocAlimBean bean = new VocAlimBean();
        bean.setVocSeq(vocSeq);
        bean.setAlertCd(alertCd);
        bean.setRcvNm(rcvNm);
        bean.setMgrId(mgrId);
        bean.setEncMobile(mobile);
        bean.setEncEmail(email);
        bean.setFileSeq(MINUS_ONE);
        bean.setTitle(title);
        bean.setContents(contents);
        bean.setResult(
            StringUtil.equals(result, Message.SUCCESS) ? EMPTY : result);
        
        service.insertAction(bean);
        
        logger.info("알림 메시지 전송 {} -> {}", alertCd, result);
    }
    
    

    public void setSenderMap(Map<String, ISalmonMessageSender> senderMap) {
        this.senderMap = senderMap;
    }
}
