package com.srpost.cm.bo.sr.srm.core;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.MS_END;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.base.file.FileDao;
import com.srpost.cm.bo.sr.srm.core.extdt.VocExtDtBean;
import com.srpost.salmon.bean.BasePagerBean;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.crypto.SalmonCrypto;

import static com.srpost.salmon.constant.StringPool.HAT;
import static com.srpost.salmon.constant.StringPool.N;
import static com.srpost.salmon.constant.StringPool.Y;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC DAO
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
@Repository
public class VocDao extends EgovAbstractMapper {

    @Resource
    SalmonCrypto salmonCtypto;
    @Resource
    FileDao fileDao;

    public BasePagerBean list(VocListBean bean) {
        
        Map<String, Object> parameterMap = VocUtil.getParameterMap(bean);

        List<VocBean> dataList = selectList("_voc.list", parameterMap);
        int totalCount = (Integer)selectOne("_voc.listCount", parameterMap);

        return new BasePagerBean(dataList, totalCount, bean);
    }
    
    public List<Map<String, Object>> listExcel(VocListBean bean) {
    	
        Map<String, Object> parameterMap = VocUtil.getParameterMap(bean);
    	
        VocExcelRowHandler rowHandler = new VocExcelRowHandler(salmonCtypto);
        
    	if ( StringUtil.equals(bean.getXlsScope(), VocBean.SCOPE_TOTAL)) {
    		getSqlSession().select("_vocExcel.listVocAll", parameterMap, rowHandler);
    	}
    	else {
    	    getSqlSession().select("_vocExcel.listVoc", parameterMap, rowHandler);
    	}
    	
    	return rowHandler.getList();
    }
    
    public VocBean view(VocBean bean, boolean needUpdateReadCnt) {
        
        VocBean dataBean = (VocBean)selectOne("_voc.view", bean.getVocSeq());
        
        if (dataBean != null) {
            dataBean.setUserFileList( fileDao.list(dataBean.getUserFileSeq()) );
            dataBean.setMgrFileList( fileDao.list(dataBean.getMgrFileSeq()) );
            
            // 회신유형
            dataBean.setAlertNm(VocUtil.getAlertNms(dataBean.getAlertCds()));
            
            Map<String, Integer> parameterMap = new HashMap<String, Integer>();
            parameterMap.put("vocSeq", bean.getVocSeq());

            List<VocDivBean> divList = selectList("_vocSupport.listDiv", parameterMap);
            for (VocDivBean item : divList) {
                // 복합 VOC이면서 협조부서 처리완료가 된 경우 답변정보 설정
                if (StringUtil.equals(item.getMasterYn(), N) &&
                        StringUtil.equals(item.getMgrStatusCd(), MS_END)) {
                    
                    VocDivBean dbDivBean = selectOne("_vocSupport.viewDiv", item);
                    item.setReply(dbDivBean.getReply());
                    item.setFileList(fileDao.list(dbDivBean.getFileSeq()));
                }
            }            
            dataBean.setDivList(divList);
            
            if (dataBean.getExtReqCnt() > 0) {
                dataBean.setExtDtBean((VocExtDtBean)selectOne("_vocSupport.viewExtDt", bean.getVocSeq()));
            }
            
            if (StringUtil.equals(dataBean.getSancYn(), Y)) {
                List<VocSancBean> sancList = selectList("_vocSupport.listSanc", bean.getVocSeq());
                dataBean.setSancList(sancList);
            }
            
            if (needUpdateReadCnt) {
                update("_voc.updateReadCnt", bean);
            }
        }
        return dataBean;
    }
    
    public VocBean view(Integer vocSeq) {

        VocBean dataBean = (VocBean)selectOne("_voc.view", vocSeq);
        
        if (dataBean != null) {
            Map<String, Integer> parameterMap = new HashMap<String, Integer>();
            parameterMap.put("vocSeq", vocSeq);
            
            List<VocDivBean> divList = selectList("_vocSupport.listDiv", parameterMap);
            
            dataBean.setDivList(divList);
        }
        return dataBean;
    }
    
    public VocBean viewSimple(Integer vocSeq) {
        
        return selectOne("_voc.view", vocSeq);
    }
    
    public Map<String, Integer> countMyEntryMap(VocEntryBean bean) {
     
        String[] infos = 
                StringUtil.split((String)selectOne("_vocSupport.countMyEntryInfo", bean), HAT);

        Map<String, Integer> countMyEntryMap = new HashMap<String, Integer>();
        countMyEntryMap.put("entryActive", Integer.valueOf(infos[0]));
        countMyEntryMap.put("entryInactive", Integer.valueOf(infos[1]));
        countMyEntryMap.put("entryTotal", Integer.valueOf(infos[2]));
        
        return countMyEntryMap;
    }
}
