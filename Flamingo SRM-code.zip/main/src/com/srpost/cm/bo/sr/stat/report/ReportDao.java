package com.srpost.cm.bo.sr.stat.report;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.bean.BaseListBean;
import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 리포트 DAO
 *
 * @author  finkle
 * @date    2014-12-18
 * @since   3.0
 */
@Repository
public class ReportDao extends EgovAbstractMapper {

    public List<ReportResultBean> allCtgList() {

        return selectList("_report.allCtgList");
    }

    public BasePagerBean allTagList(BaseListBean bean) {

        Map<String, Object> parameterMap = bean.createPagerMap();
        
        List<ReportResultBean> dataList = selectList("_report.allTagList", parameterMap);
        int totalCount = (Integer)selectOne("_report.allTagListCount", parameterMap);

        return new BasePagerBean(dataList, totalCount, bean);
    }
}
