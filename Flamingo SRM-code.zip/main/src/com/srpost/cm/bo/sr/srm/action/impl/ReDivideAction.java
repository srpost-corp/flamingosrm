package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;

/**
 * DIVIDE : 재분배 - 접수자 (복합 VOC일 경우에만 사용됨)
 *
 * @author  finkle
 * @date    2015-01-07
 * @since   3.0
 */
public class ReDivideAction extends OffInsertAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();
        
        // 기존부서코드|재분배부서코드,기존부서코드|재분배부서코드
        String[] deptCds = StringUtil.split((String)parameterMap.get("deptCds"), COMMA);
        
        // 기존부서명|재분배부서명,기존부서명|재분배부서명
        String[] deptNms = StringUtil.split((String)parameterMap.get("deptNms"), COMMA);
        
        if (StringUtil.isEmpty(deptCds) || StringUtil.isEmpty(deptNms)) {
            return;
        }
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        String today = (String)transientVars.get("today");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());

        int affected = ONE;

        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || divList.size() == 0 || 
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                !StringUtil.equals(orgBean.getKindCd(), KND_COMPLEX) ||
                orgBean.getSnbkReqCnt() == 0 ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * VOC 수정
         */
        boolean isAllSameStatus = VocUtil.isAllSameStatus(divList, loginBean, MS_DIVIDE);
        
        if (isAllSameStatus) {
            vocBean.setMgrStatusCd(MS_DIVIDE);

            affected = insert("_vocAction.updateVocForReDivide", vocBean);
        }

        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 수정
             */
            // 기한연장 요청이 없을 때 행위자 ENTRY 비활성화
            if ( orgBean.getExtReqCnt() == ZERO ) {
                update("_vocAction.updateEntryForce", new VocEntryBean(
                        vocBean.getVocSeq(), loginBean.getMgrId(), AUTH_RECEIVER, ACT_WORKER));
            }
            
            // 재분배 대상 부서 분배자 ENTRY 활성화 등록            
            MgrBean paramMgrBean = new MgrBean();
            paramMgrBean.setAuthCd(AUTH_DIVIDER);
            
            for (String value : deptCds) {
                String[] items = StringUtil.split(value, PIPE);
                String tgtDeptCd = items[1];
                
                paramMgrBean.setDeptCd(tgtDeptCd);
                
                List<MgrBean> dividerList = selectList("_vocSupport.listMgr", paramMgrBean);
                for (MgrBean dividerBean : dividerList) {
                    insert("_vocAction.insertEntry", new VocEntryBean(
                        vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_ACTIVE));
                }
                
                alimMap.addAllMgr(dividerList);
            }
            
            /*-------------------------
             * DIV 수정
             */
            for (String value : deptCds) {
                String[] items = StringUtil.split(value, PIPE);
                String srcDeptCd = items[0];
                String tgtDeptCd = items[1];
                
                VocDivBean srcDivBean = VocUtil.getMyVocDivBean(divList, srcDeptCd);
                
                VocDivBean divBean = new VocDivBean();
                divBean.setVocSeq(vocBean.getVocSeq());
                divBean.setOrderNo(srcDivBean.getOrderNo());
                divBean.setDeptCd(tgtDeptCd);
                divBean.setDivDt(today);
                divBean.setMgrStatusCd(MS_DIVIDE);
                divBean.setSnbkReqDt("-1");
                
                update("_vocAction.updateDiv", divBean);
                
                // 워크플로우 실행
                executeWorkflow(transientVars, srcDivBean.getWfId());
            }

            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>부서 재분배</strong>");

            for (String value : deptNms) {
                String[] items = StringUtil.split(value, PIPE);
                String srcDeptNm = items[0];
                String tgtDeptNm = items[1];
                logContents.append("<br/>" + srcDeptNm + " &rarr; <span class='emphasis'>" + tgtDeptNm + "</span>");
            }
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 부서 분배자
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            
            executeAlim(alimMap);
        }
    }
}
