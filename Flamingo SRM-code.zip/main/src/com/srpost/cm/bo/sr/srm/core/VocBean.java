package com.srpost.cm.bo.sr.srm.core;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.srpost.cm.bo.sr.srm.core.extdt.VocExtDtBean;
import com.srpost.salmon.bean.BaseFileBean;
import com.srpost.salmon.bean.BaseListBean;

/**
 * 내부단 VOC 정보 Bean
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
@Alias("vocBean")
@SuppressWarnings("serial")
public class VocBean extends BaseListBean {

    /** Action CODE */
    private String action;
    
    /** 첨부파일 목록 : 신청인 */
    private List<BaseFileBean> userFileList;
    /** 첨부파일 목록 : 관리자 */
    private List<BaseFileBean> mgrFileList;
    /** 분배 목록 */
    private List<VocDivBean> divList;
    /** 결재 목록 */
    private List<VocSancBean> sancList;
    
    /** 기한연장 정보 */
    private VocExtDtBean extDtBean;
    
    /** VOC_CD */
    private Integer vocCd;
    /** VOC_이름 */
    private String vocNm;
    /** VOC_일련번호 */
    private Integer vocSeq;
    /** 워크플로우_액션_ID */
    private Integer actionId;
    /** 접수_번호 */
    private String rcvNo;
    /** 제목 */
    private String title;
    /** 태그 */
    private String tags;
    /** 질문 */
    private String question;
    /** 답변 */
    private String reply;
    /** VOC_질의_요약 */
    private String summary;
    /** VOC_요지 */
    private String vocMemo;
    /** 사용자_상태코드 */
    private String userStatusCd;
    /** 담당자_상태코드 */
    private String mgrStatusCd;
    /** 사용자_첨부파일_일련번호 */
    private Integer userFileSeq = -1;
    /** 담당자_첨부파일_일련번호 */
    private Integer mgrFileSeq = -1;
    /** 신청인_ID */
    private String writerId;
    /** 접수자 의견 */
    private String rcvMemo;
    /** 등록자_ID */
    private String regId;
    /** 접수자_ID */
    private String rcvId;
    /** 상신자_ID */
    private String reporterId;
    /** 접수_일시 */
    private String rcvDt;
    /** 분배_일시 */
    private String divDt;
    /** 지정_일시 */
    private String asnDt;
    /** 처리기한_일시 */
    private String lmtDt;
    /** 완료_일시 */
    private String endDt;
    /** 공개_여부 */
    private String openYn;
    /** 삭제_여부 */
    private String delYn;
    /** 집단상담_여부 */
    private String manyYn = "N";
    /** 반복상담_여부 */
    private String rptYn = "N";
    /** FAQ 여부 */
    private String faqYn;
    /** 결재 여부 */
    private String sancYn;
    /** 만족도 평균 */
    private Integer scoreAvg = 0;
    /** 만족도 평가여부 */
    private String scoreYn;
    /** 만족도 기타의견 */
    private String scoreDesc;
    /** 회신_코드 */
    private String alertCds;
    /** 카테고리_코드1 */
    private String ctgCd1;
    /** 카테고리_코드2 */
    private String ctgCd2;
    /** 카테고리_코드3 */
    private String ctgCd3;
    /** 유입경로_코드 */
    private String fromCd;
    /** 유입경로(채널)_코드 */
    private String fromChnlCd;
    /** 유입경로(대외기관)_코드 */
    private String fromOrgCd;
    /** 종류_코드 */
    private String kindCd;
    /** 유형_코드 */
    private String typeCd;
    /** 불만_코드 */
    private String cmplnCd;
    /** 완료_코드 */
    private String endCd;
    /** 완료_기간 (총 완료 시간 msec) */
    private Long endCnt = -1L;
    /** 조회수 */
    private Integer readCnt = 0;
    /** 등록_일시 */
    private String regDt;
    /** 수정_일시 */
    private String modiDt;
    
    /** 기한연장_횟수 */
    private Integer extCnt = 0;
    /** 반송_횟수 */
    private Integer snbkCnt = 0;
    /** 협조_횟수 */
    private Integer subReqCnt = 0;

    private String writerNm;
    private String mobile;
    private String email;
    private String regNm;
    private String rcvNm;
    private String userStatusNm;
    private String mgrStatusNm;
    private String alertNm;
    private String fromNm;
    private String fromChnlNm;
    private String fromOrgNm;
    private String kindNm;
    private String typeNm;
    private String cmplnNm;
    private String ctgNm1;
    private String ctgNm2;
    private String ctgNm3;
    private String endNm;
    private String divInfo;
    private String mgrInfo;

    /** 첨부파일 수 */
    private Integer fileCnt;
    /** 반송요청 수 */
    private Integer snbkReqCnt;
    /** 기한요청 수 */
    private Integer extReqCnt;
    /** 처리 기한 일수 */
    private Integer lmtCnt;
    /** 의견 수 */
    private Integer cmtCnt;
    
    /** 일련번호 배열 */
    private Integer[] vocSeqs;
    /** 첨부파일 배열 */
    private String[] fileIds;
    
    /** 스크랩 유무 */
    private String scrapYn;
    
    public List<BaseFileBean> getUserFileList() {
        return userFileList;
    }
    public void setUserFileList(List<BaseFileBean> userFileList) {
        this.userFileList = userFileList;
    }
    public List<BaseFileBean> getMgrFileList() {
        return mgrFileList;
    }
    public void setMgrFileList(List<BaseFileBean> mgrFileList) {
        this.mgrFileList = mgrFileList;
    }
    public Integer getFileCnt() {
        return fileCnt;
    }
    public void setFileCnt(Integer fileCnt) {
        this.fileCnt = fileCnt;
    }
    public Integer getVocCd() {
        return vocCd;
    }
    public void setVocCd(Integer vocCd) {
        this.vocCd = vocCd;
    }
    public String getVocNm() {
        return vocNm;
    }
    public void setVocNm(String vocNm) {
        this.vocNm = vocNm;
    }
    public Integer getVocSeq() {
        return vocSeq;
    }
    public void setVocSeq(Integer vocSeq) {
        this.vocSeq = vocSeq;
    }
    public String getRcvNo() {
        return rcvNo;
    }
    public void setRcvNo(String rcvNo) {
        this.rcvNo = rcvNo;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getQuestion() {
        return question;
    }
    public void setQuestion(String question) {
        this.question = question;
    }
    public String getReply() {
        return reply;
    }
    public void setReply(String reply) {
        this.reply = reply;
    }
    public String getUserStatusCd() {
        return userStatusCd;
    }
    public void setUserStatusCd(String userStatusCd) {
        this.userStatusCd = userStatusCd;
    }
    public String getMgrStatusCd() {
        return mgrStatusCd;
    }
    public void setMgrStatusCd(String mgrStatusCd) {
        this.mgrStatusCd = mgrStatusCd;
    }
    public Integer getUserFileSeq() {
        return userFileSeq;
    }
    public void setUserFileSeq(Integer userFileSeq) {
        this.userFileSeq = userFileSeq;
    }
    public Integer getMgrFileSeq() {
        return mgrFileSeq;
    }
    public void setMgrFileSeq(Integer mgrFileSeq) {
        this.mgrFileSeq = mgrFileSeq;
    }
    public String getRcvMemo() {
        return rcvMemo;
    }
    public void setRcvMemo(String rcvMemo) {
        this.rcvMemo = rcvMemo;
    }
    public String getRcvId() {
        return rcvId;
    }
    public void setRcvId(String rcvId) {
        this.rcvId = rcvId;
    }
    public String getRcvDt() {
        return rcvDt;
    }
    public void setRcvDt(String rcvDt) {
        this.rcvDt = rcvDt;
    }
    public String getDivDt() {
        return divDt;
    }
    public void setDivDt(String divDt) {
        this.divDt = divDt;
    }
    public String getAsnDt() {
        return asnDt;
    }
    public void setAsnDt(String asnDt) {
        this.asnDt = asnDt;
    }
    public String getLmtDt() {
        return lmtDt;
    }
    public void setLmtDt(String lmtDt) {
        this.lmtDt = lmtDt;
    }
    public String getEndDt() {
        return endDt;
    }
    public void setEndDt(String endDt) {
        this.endDt = endDt;
    }
    public String getOpenYn() {
        return openYn;
    }
    public void setOpenYn(String openYn) {
        this.openYn = openYn;
    }
    public String getDelYn() {
        return delYn;
    }
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }
    public String getManyYn() {
        return manyYn;
    }
    public void setManyYn(String manyYn) {
        this.manyYn = manyYn;
    }
    public String getRptYn() {
        return rptYn;
    }
    public void setRptYn(String rptYn) {
        this.rptYn = rptYn;
    }
    public String getFaqYn() {
        return faqYn;
    }
    public void setFaqYn(String faqYn) {
        this.faqYn = faqYn;
    }
    public String getSancYn() {
        return sancYn;
    }
    public void setSancYn(String sancYn) {
        this.sancYn = sancYn;
    }
    public Integer getScoreAvg() {
        return scoreAvg;
    }
    public void setScoreAvg(Integer scoreAvg) {
        this.scoreAvg = scoreAvg;
    }
    public String getScoreYn() {
        return scoreYn;
    }
    public void setScoreYn(String scoreYn) {
        this.scoreYn = scoreYn;
    }
    public String getScoreDesc() {
        return scoreDesc;
    }
    public void setScoreDesc(String scoreDesc) {
        this.scoreDesc = scoreDesc;
    }
    public String getAlertCds() {
        return alertCds;
    }
    public void setAlertCds(String alertCds) {
        this.alertCds = alertCds;
    }
    public String getFromCd() {
        return fromCd;
    }
    public void setFromCd(String fromCd) {
        this.fromCd = fromCd;
    }
    public String getKindCd() {
        return kindCd;
    }
    public void setKindCd(String kindCd) {
        this.kindCd = kindCd;
    }
    public String getTypeCd() {
        return typeCd;
    }
    public void setTypeCd(String typeCd) {
        this.typeCd = typeCd;
    }
    public String getEndCd() {
        return endCd;
    }
    public void setEndCd(String endCd) {
        this.endCd = endCd;
    }
    public Long getEndCnt() {
        return endCnt;
    }
    public void setEndCnt(Long endCnt) {
        this.endCnt = endCnt;
    }
    public Integer getReadCnt() {
        return readCnt;
    }
    public void setReadCnt(Integer readCnt) {
        this.readCnt = readCnt;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
    public String getModiDt() {
        return modiDt;
    }
    public void setModiDt(String modiDt) {
        this.modiDt = modiDt;
    }
    public String getRcvNm() {
        return rcvNm;
    }
    public void setRcvNm(String rcvNm) {
        this.rcvNm = rcvNm;
    }
    public String getUserStatusNm() {
        return userStatusNm;
    }
    public void setUserStatusNm(String userStatusNm) {
        this.userStatusNm = userStatusNm;
    }
    public String getMgrStatusNm() {
        return mgrStatusNm;
    }
    public void setMgrStatusNm(String mgrStatusNm) {
        this.mgrStatusNm = mgrStatusNm;
    }
    public String getAlertNm() {
        return alertNm;
    }
    public void setAlertNm(String alertNm) {
        this.alertNm = alertNm;
    }
    public String getFromNm() {
        return fromNm;
    }
    public void setFromNm(String fromNm) {
        this.fromNm = fromNm;
    }
    public String getKindNm() {
        return kindNm;
    }
    public void setKindNm(String kindNm) {
        this.kindNm = kindNm;
    }
    public String getTypeNm() {
        return typeNm;
    }
    public void setTypeNm(String typeNm) {
        this.typeNm = typeNm;
    }
    public String getEndNm() {
        return endNm;
    }
    public void setEndNm(String endNm) {
        this.endNm = endNm;
    }
    public Integer[] getVocSeqs() {
        return vocSeqs;
    }
    public void setVocSeqs(Integer[] vocSeqs) {
        this.vocSeqs = vocSeqs;
    }
    public String[] getFileIds() {
        return fileIds;
    }
    public void setFileIds(String[] fileIds) {
        this.fileIds = fileIds;
    }
    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
    public String getRegId() {
        return regId;
    }
    public void setRegId(String regId) {
        this.regId = regId;
    }
    public String getRegNm() {
        return regNm;
    }
    public void setRegNm(String regNm) {
        this.regNm = regNm;
    }
    public List<VocDivBean> getDivList() {
        return divList;
    }
    public void setDivList(List<VocDivBean> divList) {
        this.divList = divList;
    }
    public List<VocSancBean> getSancList() {
        return sancList;
    }
    public void setSancList(List<VocSancBean> sancList) {
        this.sancList = sancList;
    }
    public Integer getActionId() {
        return actionId;
    }
    public void setActionId(Integer actionId) {
        this.actionId = actionId;
    }
    public String getDivInfo() {
        return divInfo;
    }
    public void setDivInfo(String divInfo) {
        this.divInfo = divInfo;
    }
    public Integer getSnbkReqCnt() {
        return snbkReqCnt;
    }
    public void setSnbkReqCnt(Integer snbkReqCnt) {
        this.snbkReqCnt = snbkReqCnt;
    }
    public Integer getExtReqCnt() {
        return extReqCnt;
    }
    public void setExtReqCnt(Integer extReqCnt) {
        this.extReqCnt = extReqCnt;
    }
    public Integer getExtCnt() {
        return extCnt;
    }
    public void setExtCnt(Integer extCnt) {
        this.extCnt = extCnt;
    }
    public Integer getSnbkCnt() {
        return snbkCnt;
    }
    public void setSnbkCnt(Integer snbkCnt) {
        this.snbkCnt = snbkCnt;
    }
    public String getMgrInfo() {
        return mgrInfo;
    }
    public void setMgrInfo(String mgrInfo) {
        this.mgrInfo = mgrInfo;
    }
    public String getVocMemo() {
        return vocMemo;
    }
    public void setVocMemo(String vocMemo) {
        this.vocMemo = vocMemo;
    }
    public String getFromChnlCd() {
        return fromChnlCd;
    }
    public void setFromChnlCd(String fromChnlCd) {
        this.fromChnlCd = fromChnlCd;
    }
    public String getFromOrgCd() {
        return fromOrgCd;
    }
    public void setFromOrgCd(String fromOrgCd) {
        this.fromOrgCd = fromOrgCd;
    }
    public String getFromChnlNm() {
        return fromChnlNm;
    }
    public void setFromChnlNm(String fromChnlNm) {
        this.fromChnlNm = fromChnlNm;
    }
    public String getFromOrgNm() {
        return fromOrgNm;
    }
    public void setFromOrgNm(String fromOrgNm) {
        this.fromOrgNm = fromOrgNm;
    }
    public VocExtDtBean getExtDtBean() {
        return extDtBean;
    }
    public void setExtDtBean(VocExtDtBean extDtBean) {
        this.extDtBean = extDtBean;
    }
    public String getReporterId() {
        return reporterId;
    }
    public void setReporterId(String reporterId) {
        this.reporterId = reporterId;
    }
    public String getCmplnCd() {
        return cmplnCd;
    }
    public void setCmplnCd(String cmplnCd) {
        this.cmplnCd = cmplnCd;
    }
    public String getCmplnNm() {
        return cmplnNm;
    }
    public void setCmplnNm(String cmplnNm) {
        this.cmplnNm = cmplnNm;
    }
    public String getWriterId() {
        return writerId;
    }
    public void setWriterId(String writerId) {
        this.writerId = writerId;
    }
    public String getWriterNm() {
        return writerNm;
    }
    public void setWriterNm(String writerNm) {
        this.writerNm = writerNm;
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getCtgCd1() {
        return ctgCd1;
    }
    public void setCtgCd1(String ctgCd1) {
        this.ctgCd1 = ctgCd1;
    }
    public String getCtgCd2() {
        return ctgCd2;
    }
    public void setCtgCd2(String ctgCd2) {
        this.ctgCd2 = ctgCd2;
    }
    public String getCtgCd3() {
        return ctgCd3;
    }
    public void setCtgCd3(String ctgCd3) {
        this.ctgCd3 = ctgCd3;
    }
    public String getCtgNm1() {
        return ctgNm1;
    }
    public void setCtgNm1(String ctgNm1) {
        this.ctgNm1 = ctgNm1;
    }
    public String getCtgNm2() {
        return ctgNm2;
    }
    public void setCtgNm2(String ctgNm2) {
        this.ctgNm2 = ctgNm2;
    }
    public String getCtgNm3() {
        return ctgNm3;
    }
    public void setCtgNm3(String ctgNm3) {
        this.ctgNm3 = ctgNm3;
    }
    public Integer getLmtCnt() {
        return lmtCnt;
    }
    public void setLmtCnt(Integer lmtCnt) {
        this.lmtCnt = lmtCnt;
    }
    public Integer getCmtCnt() {
        return cmtCnt;
    }
    public void setCmtCnt(Integer cmtCnt) {
        this.cmtCnt = cmtCnt;
    }
    public String getTags() {
        return tags;
    }
    public void setTags(String tags) {
        this.tags = tags;
    }
    public String getScrapYn() {
        return scrapYn;
    }
    public void setScrapYn(String scrapYn) {
        this.scrapYn = scrapYn;
    }
    public String getSummary() {
        return summary;
    }
    public void setSummary(String summary) {
        this.summary = summary;
    }
    public Integer getSubReqCnt() {
        return subReqCnt;
    }
    public void setSubReqCnt(Integer subReqCnt) {
        this.subReqCnt = subReqCnt;
    }

}
