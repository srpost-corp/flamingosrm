package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;

import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.cm.bo.sr.srm.core.score.VocScoreBean;
import com.srpost.salmon.lang.StringUtil;

import static com.srpost.salmon.constant.StringPool.COMMA;
import static com.srpost.salmon.constant.StringPool.ONE;
import static com.srpost.salmon.constant.StringPool.ZERO;

/**
 * USER_INSERT : 고객 VOC 만족도 평가
 *
 * @author  finkle
 * @date    2015-02-06
 * @since   3.0
 */
public class UserScoreAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        Map<String, Object> parameterMap = getParameterMap();

        String[] orderNos = StringUtil.split((String)parameterMap.get("orderNos"), COMMA);
        String[] scores = StringUtil.split((String)parameterMap.get("scores"), COMMA);
        
        int scoreSum = ZERO;
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();

        /*-------------------------
         * VOC 만족도 등록
         */
        
        if (StringUtil.isNotEmpty(orderNos)) {
            
            int orderNosLen = orderNos.length;
            
            for (int i=0; i<orderNosLen; i++) {
                
                VocScoreBean scoreBean = new VocScoreBean();
                scoreBean.setVocSeq(vocBean.getVocSeq());
                scoreBean.setOrderNo(Integer.parseInt(orderNos[i]));
                scoreBean.setScore(Integer.parseInt(scores[i]));
                
                scoreSum += scoreBean.getScore();
                
                update("_vocScore.insert", scoreBean);
            }
            
            vocBean.setScoreAvg(Math.round(scoreSum/orderNos.length));
        }

        /*-------------------------
         * VOC 수정
         */
        int affected = update("_vocAction.updateVocForUserScore", vocBean);

        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {

            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>신청인 만족도 평가</strong>");
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 처리자, 고객
             */
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            
            VocDivBean masterDivBean = alimMap.getDivBean();

            alimMap.addMgr((MgrBean)selectOne("_mgr.view", masterDivBean.getMgrId()));

            if (alimMap.getVocBean().getScoreAvg() < 50) {
                alimMap.setActionCd(__ACTION_LOW_SCORE__);
            }
            else {
                alimMap.setActionCd(vocBean.getAction());
                alimMap.setMgrBean((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getWriterId()));
            }
            
            executeAlim(alimMap);
        }
    }
}
