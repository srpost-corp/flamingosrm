package com.srpost.cm.bo.sr.srm.supporter;

/**
 * VOC 접수번호 생성기 인터페이스
 *
 * @author  finkle
 * @date    2014-12-01
 * @since   3.0
 */
public interface IVocRcvNoGenerator {

    /**
     * 접수번호 생성
     */
    String create(Object org);
}
