package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.conf.VocConfBean;
import com.srpost.cm.bo.sr.srm.conf.VocReceiverBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;

import static com.srpost.salmon.constant.StringPool.EMPTY;
import static com.srpost.salmon.constant.StringPool.ONE;
import static com.srpost.salmon.constant.StringPool.Y;

/**
 * USER_INSERT : 고객 VOC 등록
 *
 * @author  finkle
 * @date    2015-02-06
 * @since   3.0
 */
public class UserInsertAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        String today = (String)transientVars.get("today");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * VOC 등록
         */        
        VocUtil.setNotNullValue(vocBean);
        
        vocBean.setVocSeq(vocSeqGenerator.getNextInteger());
        vocBean.setWriterId(loginBean.getMgrId());
        vocBean.setRegId(EMPTY);
        vocBean.setUserFileSeq(fileDao.insertAction(vocBean.getUserFileList()));
        vocBean.setUserStatusCd(US_READY);
        vocBean.setMgrStatusCd(MS_READY);
        vocBean.setRegDt(today);
        
        int affected = insert("_voc.insert", vocBean);
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 등록
             */
            // 접수자 ENTRY 활성화 등록
            VocConfBean confBean = VocUtil.getConfBean(vocBean.getVocCd());

            List<VocReceiverBean> receiverList = confBean.getReceiverList();
            for (VocReceiverBean receiverBean : receiverList) {
                
                insert("_vocAction.insertEntry", new VocEntryBean(
                    vocBean.getVocSeq(), receiverBean.getMgrId(), AUTH_RECEIVER, ACT_ACTIVE));
                
                alimMap.addMgr((MgrBean)selectOne("_mgr.view", receiverBean.getMgrId()));
            }

            /*-------------------------
             * DIV 등록
             */
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setWfId(createtWorkflow(transientVars));
            divBean.setMasterYn(Y);
            divBean.setMgrStatusCd(vocBean.getMgrStatusCd());
            divBean.setEndCnt(-1L);
            
            insert("_vocAction.insertDiv", divBean);
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>고객 VOC 등록</strong>");
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(EMPTY);
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 접수자
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            
            executeAlim(alimMap);
        }
    }
}
