package com.srpost.cm.bo.sr.stat.term;

import static com.srpost.salmon.constant.Constant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jodd.json.JsonParser;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;
import com.srpost.salmon.web.mvc.view.Excel2007View;
import com.srpost.salmon.web.mvc.view.ExcelView;

/**
 * 내부단 VOC 통계(기간별) 컨트롤러
 *
 * @author  finkle
 * @date    2014-12-24
 * @since   2.0
 */
@Controller
@SuppressWarnings("deprecation")
@RequestMapping(value="/bo/sr/stat/term")
public class StatTermController extends BaseController {

    @Resource
    IStatTermService service;    
    @Resource
    ExcelView excelView;
    
    /**
     * 통계 메인
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index(ModelMap model) {
    }
    
    /**
     * 연간 통계
     */
    @RequestMapping(value="a_year.do", method=RequestMethod.GET)
    public void year(@RequestParam(required=false, value="vocCd") Integer vocCd,
            @RequestParam(required=false, value="year") Integer year, ModelMap model) {
        
        if (StringUtil.isEmpty(year)) {
            year = Calendar.getInstance().get(Calendar.YEAR);
        }
        
        model.addAttribute("dataBean", service.year(vocCd, year));
        model.addAttribute("yearList", StatTermUtil.createYearList(year));
        model.addAttribute("searchYear", year);
        model.addAttribute("vocList", VocUtil.getConfList());
    }
    
    /**
     * 월간 통계
     */
    @RequestMapping(value="a_month.do", method=RequestMethod.GET)
    public void month(@RequestParam(required=false, value="vocCd") Integer vocCd,
            @RequestParam(required=false, value="year") Integer year, ModelMap model) {

        if (StringUtil.isEmpty(year)) {
            year = Calendar.getInstance().get(Calendar.YEAR);
        }
        
        String startDd = year + "0101";
        String endDd = year + "1231";
        
        model.addAttribute("dataBean", service.month(vocCd, startDd, endDd));
        model.addAttribute("yearList", StatTermUtil.createYearList(year));
        model.addAttribute("searchYear", year);
        model.addAttribute("vocList", VocUtil.getConfList());
    }
    
    /**
     * 일간 통계
     */
    @RequestMapping(value="a_day.do", method=RequestMethod.GET)
    public void day(@RequestParam(required=false, value="vocCd") Integer vocCd,
            @RequestParam(required=false, value="year") Integer year, 
            @RequestParam(required=false, value="month") String month, ModelMap model) {

        String todayShort = DateTimeUtil.getTodayShort();
        
        if (StringUtil.isEmpty(year)) {
            year = Integer.parseInt(todayShort.substring(0, 4));
        }
        if (StringUtil.isEmpty(month)) {
            month = todayShort.substring(4, 6);
        }
        String startMonth = year + month;
        
        model.addAttribute("dataBean", service.day(vocCd, startMonth));
        model.addAttribute("yearList", StatTermUtil.createYearList(year));
        model.addAttribute("monthList", StatTermUtil.createMonthList(true));
        model.addAttribute("searchYear", year);
        model.addAttribute("searchMonth", month);
        model.addAttribute("vocList", VocUtil.getConfList());
    }
    
    /** 
     * 요일별 통계 
     */
    @RequestMapping(value="a_dow.do", method=RequestMethod.GET)
    public void dow(@RequestParam(required=false, value="vocCd") Integer vocCd,
            @RequestParam(required=false, value="startDd") String startDd, 
            @RequestParam(required=false, value="endDd") String endDd, ModelMap model) {

        String todayMonth = DateTimeUtil.getTodayShort().substring(0, 6);
        
        if (StringUtil.isEmpty(startDd)) startDd = todayMonth + "01";
        else startDd = DateTimeUtil.removeDash(startDd);
        
        if (StringUtil.isEmpty(endDd))endDd = todayMonth + "31";
        else endDd = DateTimeUtil.removeDash(endDd);
        
        model.addAttribute("dataBean", service.dow(vocCd, startDd, endDd));
        model.addAttribute("startDd", DateTimeUtil.appendDash(startDd));
        model.addAttribute("endDd", DateTimeUtil.appendDash(endDd));
        model.addAttribute("vocList", VocUtil.getConfList());
    }
    
    /**
     * 통계 엑셀 변환
     */
    @RequestMapping(value="x_excel.do", method=RequestMethod.POST)
    public void excel(
            @RequestParam(value="xlsStatCd") String xlsStatCd,
            @RequestParam(value="xlsData") String xlsData, 
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        
        String encodedFileName = 
            excelView.getEncodedFileName(request,
                xlsStatCd + UNDERSCORE + DateTimeUtil.totDateShort(new Date()) + Excel2007View.EXTENSION);
        
        String contentType = excelView.getContentType();
        
        try {
            StringBuilder builder = new StringBuilder()
            .append("<html>\n<head>\n")
            .append("<meta http-equiv='Content-Type' ")
            .append("content='application/vnd.ms-excel;charset=" + ENCODING +"' />\n")
            .append("</head>\n<body>\n")
            .append(xlsData)
            .append("\n</body>\n</html>\n");

            byte[] xlsBytes = builder.toString().getBytes(ENCODING);

            out.write(xlsBytes);
            
            response.setContentType(contentType);
            response.setHeader("Content-Disposition","attachment;filename=" + encodedFileName + ";");
            response.setContentLength(out.size());
            
            response.getOutputStream().write(out.toByteArray());
            response.getOutputStream().flush();
        } 
        catch (Exception e) {
            logger.error(EMPTY, e);
        }
        finally {
            IOUtils.closeQuietly(out);
        }
    }
    
    /**
     * 통계 엑셀 변환 : 
     * 기존 헤더값 변경처리를 통한 엑셀다운로드는 MS-Office 보안정책 변경에 따라
     * 지원하지 않으므로 POI 방식으로 변경 처리
     */
    @RequestMapping(value="poi/x_excel.do", method={RequestMethod.GET, RequestMethod.POST})
    public ModelAndView poiExcel(HttpServletRequest request,
            StatTypeSearchBean bean, ModelMap model) {
        
        List<Map<String, Object>> dataList = new ArrayList<Map<String,Object>>();
        
        if ( StringUtil.isNotEmpty(bean.getXlsList()) ) {
            
            for ( String data : bean.getXlsList() ) {
                
                JsonParser jsonParser = new JsonParser();
                Map<String, Object> dataMap = jsonParser.parse(data);
                
                dataList.add(dataMap);
            }
        }
        
        return responseExcel(model, dataList, bean);
    }
}
