package com.srpost.cm.bo.sr.srm.core.user;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 고객정보 서비스 구현체
 *
 * @author  finkle
 * @date    2015-09-03
 * @since   3.0
 */
@Service
public class VocUserServiceImpl extends EgovAbstractServiceImpl implements IVocUserService {

    @Resource
    VocUserDao dao;

    @Override
    public BasePagerBean list(MgrBean bean) {
        
        return dao.list(bean);
    }
}
