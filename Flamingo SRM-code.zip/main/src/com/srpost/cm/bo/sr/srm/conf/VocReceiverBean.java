package com.srpost.cm.bo.sr.srm.conf;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 내부단 VOC설정 접수자정보 Bean
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
@Alias("vocReceiverBean")
@SuppressWarnings("serial")
public class VocReceiverBean extends BaseBean {

    /** VOC_코드 */
    private Integer vocCd;
    /** 직원_ID */
    private String mgrId;
    /** 직원_이름 */
    private String mgrNm;
    /** 부서_이름 */
    private String deptNm;
    /** 정렬_순서 */
    private Integer orderNo;
    
    
    public Integer getVocCd() {
        return vocCd;
    }
    public void setVocCd(Integer vocCd) {
        this.vocCd = vocCd;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getMgrNm() {
        return mgrNm;
    }
    public void setMgrNm(String mgrNm) {
        this.mgrNm = mgrNm;
    }
    public String getDeptNm() {
        return deptNm;
    }
    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
}
