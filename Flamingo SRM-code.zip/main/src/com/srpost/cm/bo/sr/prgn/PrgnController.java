package com.srpost.cm.bo.sr.prgn;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.salmon.constant.Message;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 내부단 모범답안 컨트롤러
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/prgn")
public class PrgnController extends BaseController {

    @Resource
    IPrgnService service;
    
    /**
     * 모범답안 메인
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index(ModelMap model) {
    }
    
    /**
     * 모범답안 목록
     */
    @RequestMapping(value="j_list.do", method=RequestMethod.GET)
    public ModelAndView list(PrgnBean bean, ModelMap model) {
        
        return responseJson(model, service.list(bean));
    }

    /**
     * 모범답안 상세정보
     */
    @RequestMapping(value="a_view.do", method=RequestMethod.POST)
    public void view(PrgnBean bean, HttpServletRequest request, ModelMap model) {

        model.addAttribute("dataBean", service.view(bean));
    }
    
    /**
     * 모범답안 등록/수정 폼
     */
    @RequestMapping(value="a_form.do", method=RequestMethod.POST)
    public void form(PrgnBean bean, ModelMap model) {

        if (StringUtil.isEmpty(bean.getOrderNo()))
            model.addAttribute("dataBean", bean);
        else {
            PrgnBean dataBean = service.view(bean);            
            model.addAttribute("dataBean", dataBean == null ? bean : dataBean);
        }
    }
    
    /**
     * 모범답안 등록 액션
     */
    @RequestMapping(value="t_insertAction.do", method=RequestMethod.POST)
    public ModelAndView insertAction(PrgnBean bean, ModelMap model) {

        int affected = service.insertAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_INSERT_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }

    /**
     * 모범답안 수정 액션
     */
    @RequestMapping(value="t_updateAction.do", method=RequestMethod.POST)
    public ModelAndView updateAction(PrgnBean bean, ModelMap model) {

        int affected = service.updateAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_UPDATE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }

    /**
     * 모범답안 삭제 액션
     */
    @RequestMapping(value="t_deleteAction.do", method=RequestMethod.POST)
    public ModelAndView deleteAction(PrgnBean bean, ModelMap model) {

        int affected = service.deleteAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_DELETE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
    
    /**
     * 엑셀 변환 팝업창
     */
    @RequestMapping(value="p_excelForm.do", method=RequestMethod.GET)
    public void excelForm() {
    }
    
    /**
     * 엑셀 변환 액션
     */
    @RequestMapping(value="x_excelAction.do", method=RequestMethod.POST)
    public ModelAndView excelAction(PrgnBean bean, ModelMap model) {

    	List<Map<String, Object>> dataList = service.listExcel(bean);

        return responseExcel(model, dataList, bean);
    }
    
    
    /**
     * 모범답안 내용 조회
     */
    @RequestMapping(value="t_viewOne.do", method=RequestMethod.POST)
    public ModelAndView viewOne(PrgnBean bean, ModelMap model) {

        return responseText(model, service.viewOne(bean));
    }
}
