package com.srpost.cm.bo.sr.srm.core.scrap;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.salmon.bean.BasePagerBean;


/**
 * 내부단 VOC 스크랩 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-12-12
 * @since   2.0
 */
public interface IVocScrapService {

    BasePagerBean list(VocListBean bean);
    
    List<Map<String, Object>> listExcel(VocListBean bean);

    int insertScrapAction(Integer vocSeq, String mgrId);
    
    int deleteScrapAction(Integer vocSeq, String mgrId);
    
    List<VocBean> listForDashboard(VocListBean bean);
}
