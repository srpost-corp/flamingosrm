package com.srpost.cm.bo.sr.srm.core.extdt;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 내부단 VOC 기한연장 요청 정보 Bean
 *
 * @author  finkle
 * @date    2015-02-03
 * @since   3.0
 */
@Alias("vocExtDtBean")
@SuppressWarnings("serial")
public class VocExtDtBean extends BaseBean {

    /** VOC_일련번호 */
    private Integer vocSeq;
    /** 요청자_ID */
    private String mgrId;
    /** 요청자_이름 */
    private String mgrNm;
    /** 연장_사유 */
    private String extReason;
    /** 기한연장 요청_일시 */
    private String extDt;
    /** 등록_일시 */
    private String regDt;
    
    
    public Integer getVocSeq() {
        return vocSeq;
    }
    public void setVocSeq(Integer vocSeq) {
        this.vocSeq = vocSeq;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getMgrNm() {
        return mgrNm;
    }
    public void setMgrNm(String mgrNm) {
        this.mgrNm = mgrNm;
    }
    public String getExtReason() {
        return extReason;
    }
    public void setExtReason(String extReason) {
        this.extReason = extReason;
    }
    public String getExtDt() {
        return extDt;
    }
    public void setExtDt(String extDt) {
        this.extDt = extDt;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
}
