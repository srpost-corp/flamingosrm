package com.srpost.cm.bo.sr.srm.supporter;

import static com.srpost.salmon.constant.StringPool.*;

/**
 * VOC 접수번호 생성기
 *
 * @author  finkle
 * @date    2014-12-01
 * @since   3.0
 */
public class BasicVocRcvNoGenerator implements IVocRcvNoGenerator {

    private String prefix;
    private int cipers = 5;
    private char fillChar = '0';

    public void setCipers(int cipers) {
        this.cipers = cipers;
    }
    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }
    public void setFillChar(char fillChar) {
        this.fillChar = fillChar;
    }

    public String create(Object org) {
        
        if (org == null) return EMPTY;
        
        return prefix + fillString(org.toString(), fillChar, cipers);
    }

    private String fillString(String org, char ch, int cipers) {
        
        int orgLength = org.length();

        if (cipers < orgLength)
            return org;

        int difference = cipers - orgLength;

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < difference; i++)
            builder.append(ch);

        builder.append(org);
        
        return builder.toString();
    }
}
