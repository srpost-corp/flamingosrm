package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.conf.VocConfBean;
import com.srpost.cm.bo.sr.srm.conf.VocReceiverBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;

/**
 * RESTORE : 복원 (휴지통) - 접수자
 *
 * @author  finkle
 * @date    2014-12-15
 * @since   3.0
 */
public class RestoreAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        vocBean.setVocCd(orgBean.getVocCd());
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || 
                StringUtil.equals(N, orgBean.getDelYn()) ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * VOC 수정
         */
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("vocSeq", vocBean.getVocSeq());
        parameterMap.put("mgrStatusCd", MS_READY);
        parameterMap.put("userStatusCd", US_READY);

        int affected = update("_vocTrash.updateVocForRestore", parameterMap);
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * DEL 삭제
             */
            delete("_vocTrash.deleteDel", vocBean.getVocSeq());
            
            /*-------------------------
             * DIV, ENTRY, SANC 삭제
             */
            delete("_vocAction.deleteAllDiv", vocBean.getVocSeq());
            delete("_vocAction.deleteAllEntry", vocBean.getVocSeq());
            delete("_vocAction.deleteAllSanc", vocBean.getVocSeq());
            
            // 기한연장 요청정보 삭제
            delete("_vocAction.deleteVocExtDt", vocBean.getVocSeq());
            
            /*-------------------------
             * ENTRY 등록
             */
            
            // 접수자 ENTRY 활성화 등록
            VocConfBean confBean = VocUtil.getConfBean(orgBean.getVocCd());

            List<VocReceiverBean> receiverList = confBean.getReceiverList();
            for (VocReceiverBean receiverBean : receiverList) {
                insert("_vocAction.insertEntry", new VocEntryBean(
                    vocBean.getVocSeq(), receiverBean.getMgrId(), AUTH_RECEIVER, ACT_ACTIVE));
            }

            /*-------------------------
             * DIV 등록
             */
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setWfId(createtWorkflow(transientVars));
            divBean.setMasterYn(Y);
            divBean.setMgrStatusCd(VocConstant.MS_READY);
            divBean.setEndCnt(-1L);
            
            insert("_vocAction.insertDiv", divBean);
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>복원</strong>");
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
        }
    }
}
