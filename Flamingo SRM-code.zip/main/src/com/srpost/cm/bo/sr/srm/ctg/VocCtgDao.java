package com.srpost.cm.bo.sr.srm.ctg;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.constant.Constant;
import com.srpost.salmon.spi.egov.ISalmonSeqGenerator;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

import static com.srpost.salmon.constant.StringPool.ONE;
import static com.srpost.salmon.constant.StringPool.ZERO;

/**
 * 내부단 VOC분류 관리 DAO
 *
 * @author  finkle
 * @date    2014-11-20
 * @since   2.0
 */
@Repository
public class VocCtgDao extends EgovAbstractMapper {

    @Resource(name = "vocCtgSeqGenerator")
    ISalmonSeqGenerator seqGenerator;
    
    
    public List<VocCtgBean> list(VocCtgBean bean) {
        
        return selectList("_vocCtg.list", bean);
    }
    
    public VocCtgBean view(VocCtgBean bean) {
        
        return (VocCtgBean)selectOne("_vocCtg.view", bean);
    }
    
    public synchronized Object insertAction(VocCtgBean bean) {
        
        bean.setVocCtgCd(seqGenerator.getNextString());
        
        int affected = insert("_vocCtg.insert", bean);
        if (affected == ONE) {
            return bean.getVocCtgCd();
        }
        return null;
    }

    public int updateAction(VocCtgBean bean) {
        
        // 기본 정보 수정
        if ( bean.getOrderNo() == ZERO ) {

            int affected = update("_vocCtg.update", bean);
            if (affected == ONE)
                update("_vocCtg.updateRecursive", bean);
            
            return affected;
        }
        // 정렬 정보 수정
        else {
            
            List<VocCtgBean> sameLevelList = selectList("_vocCtg.listSameLevel", bean);
            int sameLevelLength = sameLevelList.size();
            
            int newOrderNo = bean.getOrderNo();

            if ( newOrderNo <= ZERO )
                newOrderNo = 1;
            if ( newOrderNo > sameLevelLength )
                newOrderNo = sameLevelLength + 1;
            
            sameLevelList.add(newOrderNo-1, bean);
            sameLevelLength++;
            
            int affected = ZERO;
            
            for (int i=0 ; i < sameLevelLength ; i++) {
                VocCtgBean sameLevelBean = (VocCtgBean)sameLevelList.get(i);
                
                sameLevelBean.setOrderNo( i + 1 );
                affected += update("_vocCtg.updateOrder", sameLevelBean);
            }
            
            if ( affected == sameLevelLength ) {
                return ONE;
            }
            else {
                return ZERO;
            }
        }
    }

    public int deleteAction(VocCtgBean bean) {
        
        return delete("_vocCtg.delete", bean);
    }
    
    public List<VocCtgBean> listAll() {
        
        return selectList("_vocCtg.listAll", Constant.TOP_CTG_CD);
    }
    
    public Map<String, List<Object>> listByDepth() {
            
        Map<String, List<Object>> resultMap = new HashMap<String, List<Object>>();
        
        VocCtgBean paramBean = new VocCtgBean();
        paramBean.setHighVocCtgCd(Constant.TOP_CTG_CD);
        
        for (int i=1 ; i <= 3 ; i++) {
            paramBean.setDepth(i);
            resultMap.put("LVL0" + i, selectList("_vocCtg.listByDepth", paramBean));
        }
        return resultMap;
    }
}
