package com.srpost.cm.bo.sr.svc.ctr.ctrInfo;

import java.util.List;

import com.srpost.cm.bo.sr.svc.ctr.CtrBean;

/**
 * 계약 서비스 인터페이스
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
public interface ICtrInfoService {
    
    CtrBean svcCtrView(CtrBean bean);
    
    List<CtrBean> svcCtrList(CtrBean bean);
    
}