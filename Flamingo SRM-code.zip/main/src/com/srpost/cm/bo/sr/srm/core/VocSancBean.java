package com.srpost.cm.bo.sr.srm.core;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 내부단 VOC 정보 Bean
 *
 * @author  finkle
 * @date    2014-12-02
 * @since   2.0
 */
@Alias("vocSancBean")
@SuppressWarnings("serial")
public class VocSancBean extends BaseBean {

    /** VOC_일련번호 */
    private Integer vocSeq;
    /** 결재_순번 */
    private Integer orderNo;
    /** 결재자_ID */
    private String mgrId;
    /** 결재자_이름 */
    private String mgrNm;
    /** 상태_명 */
    private String statusNm;
    /** 결재_일시 */
    private String sancDt;
    
    
    public Integer getVocSeq() {
        return vocSeq;
    }
    public void setVocSeq(Integer vocSeq) {
        this.vocSeq = vocSeq;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getSancDt() {
        return sancDt;
    }
    public void setSancDt(String sancDt) {
        this.sancDt = sancDt;
    }
    public String getMgrNm() {
        return mgrNm;
    }
    public void setMgrNm(String mgrNm) {
        this.mgrNm = mgrNm;
    }
    public String getStatusNm() {
        return statusNm;
    }
    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }
    

}
