package com.srpost.cm.bo.sr.srm.tag.ui;

import static com.srpost.salmon.constant.StringPool.*;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.lang.UTF8Util;

import jodd.util.ArraysUtil;

/**
 * VOC 진행현황 UI taglib
 *
 * @author  finkle
 * @date    2014-12-02
 * @since   2.0
 */
public class VocProgressTag extends SimpleTagSupport {

    private final String[] ARR_NO_RECEIVE = { VocConstant.MS_READY };
    private final String[] ARR_RECEIVE = { VocConstant.MS_RECEIVE, /* VocConstant.MSC_REDIVIDE, VocConstant.MSC_RECALL */ };
    private final String[] ARR_DIVIDE = { VocConstant.MS_DIVIDE, /* VocConstant.MSC_REASSIGN */ };
    private final String[] ARR_ASSIGN = { VocConstant.MS_ASSIGN };
    private final String[] ARR_SANC = { VocConstant.MS_SANC, /* VocConstant.MSC_SANC_DENY */ };
    private final String[] ARR_END = { VocConstant.MS_END };
    
    
    private final String PROGRESS_HTML = 
            "<div class=\"srm-progress-box\">\n" +
            "<table>\n" +       
            "<tr>\n" +
            "    <th><div class=\"step01 {0}\"></div></th>\n" +
            "    <th class=\"divider\"><i class=\"glyphicon glyphicon-menu-right\"></i></th>\n" +
            "    <th><div class=\"step02 {1}\"></div></th>\n" +
            "    <th class=\"divider\"><i class=\"glyphicon glyphicon-menu-right\"></i></th>\n" +
            "    <th><div class=\"step03 {2}\"></div></th>\n" +
            "    <th class=\"divider\"><i class=\"glyphicon glyphicon-menu-right\"></i></th>\n" +
            "    <th><div class=\"step04 {3}\"></div></th>\n" +
            "    <th class=\"divider\"><i class=\"glyphicon glyphicon-menu-right\"></i></th>\n" +
            "    <th><div class=\"step05 {4}\"></div></th>\n" +
            "    <th class=\"divider\"><i class=\"glyphicon glyphicon-menu-right\"></i></th>\n" +
            "    <th><div class=\"step06 {5}\"></div></th>\n" +
            "</tr>\n" +  
            "<tr>\n" +
            "    <td><div class=\"status\">미접수</div>\n{6}\n</td>\n" +
            "    <td>&nbsp;</td>\n" +
            "    <td><div class=\"status\">접수</div>\n{7}\n</td>\n" +
            "    <td>&nbsp;</td>\n" +
            "    <td><div class=\"status\">분배</div>\n{8}\n</td>\n" +
            "    <td>&nbsp;</td>\n" +
            "    <td><div class=\"status\">처리자 지정</div>\n{9}\n</td>\n" +
            "    <td>&nbsp;</td>\n" +
            "    <td><div class=\"status\">결재</div>\n{10}\n</td>\n" +
            "    <td>&nbsp;</td>\n" +
            "    <td><div class=\"status\">처리완료</div>\n{11}\n</td>\n" +
            "</tr>\n" +
            "</table>\n" +
            "</div>\n";

    private VocBean vocBean;
    
    public void doTag() throws JspException, IOException {

        JspWriter writer = getJspContext().getOut();

        writer.write(createHtml());
    }
    
    private String createHtml() {
        
        String mgrStatusCd = vocBean.getMgrStatusCd();
        
        String[] images = null;

        if (ArraysUtil.contains(ARR_NO_RECEIVE, mgrStatusCd)) {
            images = new String[] {
                    "active01", EMPTY, EMPTY, EMPTY, EMPTY, EMPTY,
                    getShortDate(vocBean.getRegDt()), 
                    EMPTY, EMPTY, EMPTY, EMPTY, EMPTY
            };
        }
        else if (ArraysUtil.contains(ARR_RECEIVE, mgrStatusCd)) {
            images = new String[] { 
                    EMPTY, "active02", EMPTY, EMPTY, EMPTY, EMPTY,
                    getShortDate(vocBean.getRegDt()), 
                    getShortDate(vocBean.getRcvDt()) + getReceiver(), 
                    EMPTY, EMPTY, EMPTY, EMPTY
            };
        }
        else if (ArraysUtil.contains(ARR_DIVIDE, mgrStatusCd)) {
            images = new String[] { 
                    EMPTY, EMPTY, "active03", EMPTY, EMPTY, EMPTY,
                    getShortDate(vocBean.getRegDt()), 
                    getShortDate(vocBean.getRcvDt()) + getReceiver(), 
                    getShortDate(vocBean.getDivDt()) + getDealDeptInfo(), 
                    EMPTY, EMPTY, EMPTY
            };
        }
        else if (ArraysUtil.contains(ARR_ASSIGN, mgrStatusCd)) {
            images = new String[] { 
                    EMPTY, EMPTY, EMPTY, "active04", EMPTY, EMPTY,
                    getShortDate(vocBean.getRegDt()), 
                    getShortDate(vocBean.getRcvDt()) + getReceiver(), 
                    getShortDate(vocBean.getDivDt()) + getDealDeptInfo(), 
                    getShortDate(vocBean.getAsnDt()) + getDealMgrInfo(), 
                    EMPTY, EMPTY 
            };
        }
        else if (ArraysUtil.contains(ARR_SANC, mgrStatusCd)) {
            images = new String[] { 
                    EMPTY, EMPTY, EMPTY, EMPTY, "active05", EMPTY,
                    getShortDate(vocBean.getRegDt()), 
                    getShortDate(vocBean.getRcvDt()) + getReceiver(), 
                    getShortDate(vocBean.getDivDt()) + getDealDeptInfo(), 
                    getShortDate(vocBean.getAsnDt()) + getDealMgrInfo(), 
                    getSancInfo(),
                    EMPTY
                    
            };
        }
        else if (ArraysUtil.contains(ARR_END, mgrStatusCd)) {
            images = new String[] { 
                    EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, "active06",
                    getShortDate(vocBean.getRegDt()), 
                    getShortDate(vocBean.getRcvDt()) + getReceiver(), 
                    getShortDate(vocBean.getDivDt()) + getDealDeptInfo(), 
                    getShortDate(vocBean.getAsnDt()) + getDealMgrInfo(),
                    getSancInfo(), 
                    getShortDate(vocBean.getEndDt()) + getEndMgrInfo()
            };
        }
        else {
            images = new String[] { 
                    EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY,
                    getShortDate(vocBean.getRegDt()), 
                    getShortDate(vocBean.getRcvDt()) + getReceiver(), 
                    getShortDate(vocBean.getDivDt()) + getDealDeptInfo(), 
                    getShortDate(vocBean.getAsnDt()) + getDealMgrInfo(), 
                    getSancInfo(), 
                    getShortDate(vocBean.getEndDt()) + getEndMgrInfo()
            };
        }
        
        return new MessageFormat(PROGRESS_HTML).format(images);
    }
    
    private String getShortDate(String src) {
        
        if ( StringUtil.isEmpty(src) ) return EMPTY;
        if ( src.length() >= 18 ) 
            return "<div class='date' title='" + src + "'>" + src.substring(0, 10) + "</div>\n";
        return EMPTY;
    }
    
    
    // 접수단계 : 접수자명 획득
    private String getReceiver() {
        if ( StringUtil.isEmpty(vocBean.getRcvNm()) ) return EMPTY;
        return "<div class='human' title='" + vocBean.getRcvNm() + "'>" + 
                    UTF8Util.fixLength(vocBean.getRcvNm(), 18) + "</div>\n";
    }
    
    // 부서분배 단계 : 부서목록 획득
    private String getDealDeptInfo() {
        
        List<VocDivBean> divList = vocBean.getDivList();
        if ( StringUtil.isEmpty(divList) ) return EMPTY;
        
        StringBuilder builder = new StringBuilder();
        for (VocDivBean _bean : divList) {
            if ( StringUtil.equals("Y", _bean.getMasterYn()) ) {
                builder.append("<div class='human master f-bold' title='" + _bean.getMgrNm() + "'>" + 
                        UTF8Util.fixLength(_bean.getDeptNm(), 18) + "</div>\n");
            }
            else {
                builder.append("<div class='human' title='" + _bean.getMgrNm() + "'>" + 
                        UTF8Util.fixLength(_bean.getDeptNm(), 18) + "</div>\n");
            }
        }
        return builder.toString();
    }
    
    // 담당자지정 단계 : 담당자목록 획득
    private String getDealMgrInfo() {
        
        List<VocDivBean> divList = vocBean.getDivList();
        if ( StringUtil.isEmpty(divList) ) return EMPTY;
        
        StringBuilder builder = new StringBuilder();
        for (VocDivBean _bean : divList) {
            if ( StringUtil.equals("Y", _bean.getMasterYn()) ) {
                builder.append("<div class='human master f-bold' title='" + _bean.getMgrNm() + "'>" + 
                        UTF8Util.fixLength(_bean.getMgrNm(), 18) + "</div>\n");
            }
            else {
                builder.append("<div class='human' title='" + _bean.getMgrNm() + "'>" + 
                        UTF8Util.fixLength(_bean.getMgrNm(), 18) + "</div>\n");
            }
        }
        return builder.toString();
    }
    
    // 결재 단계 : 
    private String getSancInfo() {
        
        List<VocSancBean> sancList = vocBean.getSancList();
        if ( StringUtil.isEmpty(sancList) ) 
            return getShortDate(vocBean.getEndDt()) + "<div class='human f-bold'>전결</div>";
        
        StringBuilder builder = new StringBuilder();
        int i = ONE;
        for (VocSancBean _bean : sancList) {
            builder.append("<div class='human' data-toggle='tooltip' data-placement='top' title='" + _bean.getStatusNm() + "'>" + 
                    (i++) + ". " + _bean.getMgrNm() + "</div>\n");
        }
        
        return builder.toString();
    }
    
    // 완료 단계 : 담당자명 획득
    private String getEndMgrInfo() {
        
        List<VocDivBean> divList = vocBean.getDivList();
        if ( StringUtil.isEmpty(divList) ) return EMPTY;
        
        for (VocDivBean _bean : divList) {
            if ( StringUtil.equals("Y", _bean.getMasterYn()) ) {
                return "<div class='human' title='" + _bean.getMgrNm() + "'>" + 
                        UTF8Util.fixLength(_bean.getMgrNm(), 18) + "</div>";
            }
        }
        return EMPTY;
    }
    
    
    public void setVocBean(VocBean vocBean) {
        this.vocBean = vocBean;
    }
}
