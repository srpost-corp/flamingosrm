package com.srpost.cm.bo.sr.srm.action.condition.step;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.opensymphony.module.propertyset.PropertySet;
import com.opensymphony.workflow.Condition;
import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.salmon.lang.StringUtil;

/**
 * 오프 등록 - 부서 분배 : 워크플로우 생성 시 분배자 스텝 이동 여부 판단 Condition
 *
 * @author  finkle
 * @date    2014-12-02
 * @since   3.0
 */
@SuppressWarnings("rawtypes")
@Component(value="STEP_offInsertDivideCondition")
public class OffInsertDivideCondition implements Condition {

    public boolean passesCondition(Map transientVars, Map args, PropertySet ps) {
        
        String mgrStatusCd = (String)transientVars.get("mgrStatusCd");
        
        return StringUtil.equals(mgrStatusCd, VocConstant.MS_DIVIDE);
    }
}
