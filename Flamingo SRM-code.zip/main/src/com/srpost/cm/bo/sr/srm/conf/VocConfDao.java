package com.srpost.cm.bo.sr.srm.conf;

import static com.srpost.salmon.constant.StringPool.*;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.bean.BasePagerBean;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.egov.ISalmonSeqGenerator;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC설정 DAO
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
@Repository
public class VocConfDao extends EgovAbstractMapper {

    @Resource(name = "vocConfSeqGenerator")
    ISalmonSeqGenerator seqGenerator;
    
    public BasePagerBean list(VocConfBean bean) {
        
        Map<String, Object> parameterMap = VocConfUtil.getParameterMap(bean);
        
        List<VocConfBean> dataList = selectList("_vocConf.list", parameterMap);
        int totalCount = (Integer)selectOne("_vocConf.listCount", parameterMap);

        return new BasePagerBean(dataList, totalCount, bean);
    }
    
    public List<Map<String, Object>> listExcel(VocConfBean bean) {
    	
        Map<String, Object> parameterMap = VocConfUtil.getParameterMap(bean);
    	
        VocConfExcelRowHandler rowHandler = new VocConfExcelRowHandler();
        
    	if ( StringUtil.equals(bean.getXlsScope(), VocConfBean.SCOPE_TOTAL)) {
    		getSqlSession().select("_vocConf.listExcel", parameterMap, rowHandler);
    	}
    	else {
    	    getSqlSession().select("_vocConf.list", parameterMap, rowHandler);
    	}
    	
    	return rowHandler.getList();
    }
    
    public VocConfBean view(VocConfBean bean) {
        
        VocConfBean dataBean = (VocConfBean)selectOne("_vocConf.view", bean);
        if (dataBean != null) {
            dataBean.setReceiverList( listVocReceiver(bean.getVocCd()) );
        }
        return dataBean;
    }
    
    public synchronized int insertAction(VocConfBean bean, String[] mgrDatas) {
        
        VocConfUtil.setNotNullValue(bean);
        
        bean.setVocCd(seqGenerator.getNextInteger());
        
        int affected = insert("_vocConf.insert", bean);
        if (affected == ONE) {
            insertVocMgrAction(bean.getVocCd(), mgrDatas);
        }
        return affected;
    }

    public int updateAction(VocConfBean bean, String[] mgrDatas) {
        
        VocConfUtil.setNotNullValue(bean);
        
        int affected = update("_vocConf.update", bean);
        if (affected == ONE) {
            insertVocMgrAction(bean.getVocCd(), mgrDatas);
        }
        return affected;
    }    

    public int deleteAction(VocConfBean bean) {
        
        if (StringUtil.isNotEmpty(bean.getVocCds())) {
            
            // TODO : VOC 삭제 전 알림정보 선 삭제
            
            int affected = delete("_vocConf.delete", bean);
            if (affected == Array.getLength(bean.getVocCds())) 
                return ONE;
        }
        
        return ZERO;
    }
    
    
    
    private List<VocReceiverBean> listVocReceiver(Integer vocCd) {
        
        return selectList("_vocConf.listVocReceiver", vocCd);
    }
    
    private int insertVocMgrAction(Integer vocCd, String[] mgrDatas) {
        
        int affected = ZERO;
        
        if (StringUtil.isNotEmpty(mgrDatas)) {
            
            delete("_vocConf.deleteVocReceiverAll", vocCd);
            
            int orderNo = ONE;
            
            for (String mgrData : mgrDatas) {
                String[] mgrArray = StringUtil.split(mgrData, HAT);
                
                VocReceiverBean receiverBean = new VocReceiverBean();
                receiverBean.setVocCd(vocCd);
                receiverBean.setMgrId(mgrArray[0]);
                receiverBean.setMgrNm(mgrArray[1]);
                receiverBean.setOrderNo(orderNo++);
                
                affected += insert("_vocConf.inserVocReceiver", receiverBean);
            }
        }
        return affected;
    }
    
    
    public List<VocConfBean> listCache() {
        
        Map<String, String> parameterMap = new HashMap<String, String>();
        parameterMap.put("useYn", Y);
        
        return selectList("_vocConf.listExcel", parameterMap);
    }
}
