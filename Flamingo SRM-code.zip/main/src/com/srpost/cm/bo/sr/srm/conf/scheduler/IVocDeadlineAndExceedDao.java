package com.srpost.cm.bo.sr.srm.conf.scheduler;

import java.util.List;

import com.srpost.cm.bo.sr.srm.core.VocBean;

public interface IVocDeadlineAndExceedDao {

    List<VocBean> deadlineList(Integer[] deadlineVocs);
    
    List<VocBean> exceedList(Integer[] exceedVocs);
}
