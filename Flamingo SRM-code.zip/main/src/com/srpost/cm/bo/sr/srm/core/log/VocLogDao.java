package com.srpost.cm.bo.sr.srm.core.log;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.lang.UTF8Util;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 로그 DAO
 *
 * @author  finkle
 * @date    2014-12-01
 * @since   2.0
 */
@Repository
public class VocLogDao extends EgovAbstractMapper {

    public List<VocLogBean> list(VocLogBean bean) {

        return selectList("_vocLog.list", bean.getVocSeq());
    }
    
    public int insertAction(VocLogBean bean) {
        
        bean.setLogContents(
                UTF8Util.fixLength(bean.getLogContents(), 995));
        
        return insert("_vocLog.insert", bean);
    }
 
    public String viewUpdateReplyLog(Integer vocSeq, Integer orderNo) {

        Map<String, Integer> parameterMap = new HashMap<String, Integer>();
        parameterMap.put("vocSeq", vocSeq);
        parameterMap.put("orderNo", orderNo);
        
        return selectOne("_vocLog.viewUpdateReplyLog", parameterMap);
    }

    public int insertUpdateReplyLog(VocUpdateReplyLogBean bean) {
        
        return insert("_vocLog.insertUpdateReplyLog", bean);
    }
}
