package com.srpost.cm.bo.sr.srm.core.tags;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.lang.UTF8Util;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC TAG DAO
 *
 * @author  finkle
 * @date    2014-12-19
 * @since   2.0
 */
@Repository
public class VocTagsDao extends EgovAbstractMapper {

    public List<String> list(Integer vocSeq) {
        
        return selectList("_vocTags.list", vocSeq);
    }

    public int insertAction(Integer vocSeq, String[] tags) {
        
        int affected = 0;
        
        if (StringUtil.isEmpty(tags))
            return affected;
        
        for (String tag : tags) {
            
            if (StringUtil.isEmpty(tag)) continue;
            
            VocTagsBean bean = new VocTagsBean(vocSeq, tag);
            bean.setTagNm(UTF8Util.fixLength(tag, 60));
            
            affected += insert("_vocTags.insert", bean);
        }
        
        return affected;
    }
    
    
    public List<String> listSearch(String tag) {
        
        return selectList("_vocTags.listSearch", tag);
    }
}
