package com.srpost.cm.bo.sr.srm.core.incomment;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 내부의견글 서비스 구현체
 *
 * @author  finkle
 * @date    2015-01-16
 * @since   2.0
 */
@Service
public class VocInCmtServiceImpl extends EgovAbstractServiceImpl implements IVocInCmtService {

    @Resource
    VocInCmtDao dao;

    @Override
    public List<VocInCmtBean> list(VocInCmtBean bean) {

        return dao.list(bean);
    }

    @Override
    public VocInCmtBean view(VocInCmtBean bean) {

        return dao.view(bean);
    }

    @Override
    public int insertAction(VocInCmtBean bean) {

        return dao.insertAction(bean);
    }

    @Override
    public int updateAction(VocInCmtBean bean) {

        return dao.updateAction(bean);
    }

    @Override
    public int replyAction(VocInCmtBean bean) {

        return dao.replyAction(bean);
    }

    @Override
    public int deleteAction(VocInCmtBean bean) {

        return dao.deleteAction(bean);
    }

    
}
