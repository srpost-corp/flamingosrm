package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.Map;

import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;

/**
 * FORCE_DELETE : 영구 삭제 (휴지통) - 접수자
 *
 * @author  finkle
 * @date    2014-12-15
 * @since   3.0
 */
public class ForceDeleteAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 기본 변수 설정
         */
        VocBean vocBean = (VocBean)transientVars.get("vocBean");

        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());

        /*-------------------------
         * 이미 처리된 요청 여부 체크
         */
        if (StringUtil.isEmpty(orgBean)) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || 
                !StringUtil.equals(Y, orgBean.getDelYn()) ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * VOC 삭제
         */
        int affected = delete("_vocTrash.delete", vocBean.getVocSeq());
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {

            /*-------------------------
             * 첨부파일 삭제
             */
            if (orgBean.getUserFileSeq() != MINUS_ONE)
                fileDao.deleteAction(orgBean.getUserFileSeq());
            if (orgBean.getMgrFileSeq() != MINUS_ONE)
                fileDao.deleteAction(orgBean.getMgrFileSeq());
        }
    }
}
