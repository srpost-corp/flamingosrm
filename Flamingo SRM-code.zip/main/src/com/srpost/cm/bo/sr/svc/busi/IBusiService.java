package com.srpost.cm.bo.sr.svc.busi;

import java.util.List;
import java.util.Map;

import com.srpost.salmon.bean.BasePagerBean;

/**
 * 사업자 서비스 인터페이스
 *
 * @author  Bella
 * @date    2017-04-18
 * @since   3.0
 */
public interface IBusiService {
    
    BasePagerBean list(BusiBean bean);
    
    List<Map<String, Object>> listExcel(BusiBean bean);
    
    BusiBean view(BusiBean bean);
    
    int insertAction(BusiBean bean);
    
    int updateAction(BusiBean bean);
    
    int deleteAction(BusiBean bean);
    
    List<BusiBean> listAll();
    
}
