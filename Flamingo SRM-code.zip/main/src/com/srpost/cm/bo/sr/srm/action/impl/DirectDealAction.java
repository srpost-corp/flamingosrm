package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.cm.bo.sr.srm.supporter.LmtDtCalculator;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * DIRECT_DEAL : 직접처리 - 접수자
 *
 * @author  finkle
 * @date    2014-12-03
 * @since   3.0
 */
public class DirectDealAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        String today = (String)transientVars.get("today");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());        
        LmtDtCalculator lmtDtCalculator = new LmtDtCalculator(vocBean);
        
        int affected = ONE;
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || 
                StringUtil.equals(orgBean.getDelYn(), Y) ||
                !(StringUtil.equals(orgBean.getMgrStatusCd(), MS_READY) || StringUtil.equals(orgBean.getMgrStatusCd(), MS_RECEIVE)) ||
                orgBean.getVocCd() != vocBean.getVocCd() ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * 워크플로우 실행
         */

        /*-------------------------
         * VOC 수정
         */
        VocUtil.setNotNullValue(vocBean);
        
        if (StringUtil.isEmpty(orgBean.getRcvDt()))
            vocBean.setRcvDt(today);
        
        if (StringUtil.isEmpty(orgBean.getRcvId()))
            vocBean.setRcvId(loginBean.getMgrId());
        
        if (StringUtil.isEmpty(orgBean.getRcvNo()))
            vocBean.setRcvNo(rcvNoGenerator.create(vocBean.getVocSeq()));
        
        vocBean.setMgrFileSeq(fileDao.insertAction(vocBean.getMgrFileList()));
        vocBean.setUserStatusCd(US_END);
        vocBean.setMgrStatusCd(MS_END);
        vocBean.setKindCd(KND_SIMPLE);
        if (!StringUtil.equals(vocBean.getTypeCd(), TYPE_CMPLN_CD)) {
            vocBean.setCmplnCd(EMPTY);
        }
        
        vocBean.setDivDt(today);
        vocBean.setAsnDt(today);
        vocBean.setLmtDt(lmtDtCalculator.getLmtDt());
        vocBean.setEndDt(today);
        vocBean.setEndCnt(0L);
        
        affected = update("_vocAction.updateVocForDirectDeal", vocBean);

        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {

            /*-------------------------
             * DIV 삭제, ENTRY 수정
             */
            delete("_vocAction.deleteAllDiv", vocBean.getVocSeq());
            
            // 처리완료이므로 연관화 ENTRY 제외한 모든 ENTRY 비활성화 수정
            VocEntryBean entryBean = new VocEntryBean();
            entryBean.setVocSeq(vocBean.getVocSeq());
            entryBean.setActivate(ACT_INACTIVE);
            
            update("_vocAction.updateEntryForDirectDeal", entryBean);
            
            // 행위자 ENTRY 연관화 수정
            update("_vocAction.updateEntryForce", new VocEntryBean(
                    vocBean.getVocSeq(), loginBean.getMgrId(), AUTH_RECEIVER, ACT_WORKER));
            
            /*-------------------------
             * DIV 등록
             */
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setWfId(-1L);
            divBean.setMasterYn(Y);
            divBean.setDeptCd(loginBean.getDeptCd());
            divBean.setMgrId(loginBean.getMgrId());
            divBean.setMgrStatusCd(vocBean.getMgrStatusCd());
            divBean.setDivDt(today);
            divBean.setAsnDt(today);
            divBean.setRplDt(today);
            divBean.setEndDt(today);
            divBean.setEndCnt(0L);
            
            insert("_vocAction.insertDiv", divBean);
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>직접 처리</strong>");
            logContents.append("<br/>처리기한 : <span title='" + lmtDtCalculator.getLmtDtLog() + "'>");
            logContents.append(DateTimeUtil.toDateFull(vocBean.getLmtDt()) + "</span>");
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 고객
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            alimMap.setMgrBean((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getWriterId()));
            
            executeAlim(alimMap);
        }
    }
}
