package com.srpost.cm.bo.sr.srm.doc;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 처리대장 DAO
 *
 * @author  finkle
 * @date    2014-12-19
 * @since   2.0
 */
@Repository
public class VocDocDao extends EgovAbstractMapper {

    public BasePagerBean list(VocListBean bean) {
        
        Map<String, Object> parameterMap = VocUtil.getParameterMap(bean);

        List<VocBean> dataList = selectList("_vocDoc.list", parameterMap);
        int totalCount = (Integer)selectOne("_vocDoc.listCount", parameterMap);

        return new BasePagerBean(dataList, totalCount, bean);
    }
}
