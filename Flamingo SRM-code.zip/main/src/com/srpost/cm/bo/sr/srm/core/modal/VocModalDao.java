package com.srpost.cm.bo.sr.srm.core.modal;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.base.dept.DeptBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.constant.Constant;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 모달창 DAO
 *
 * @author  finkle
 * @date    2014-11-26
 * @since   3.0
 */
@Repository
public class VocModalDao extends EgovAbstractMapper {

    public List<DeptBean> listDept(String highDeptCd, Integer authCd, 
            String deptCds) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("topDeptCd", Constant.TOP_DEPT_CD);
        parameterMap.put("highDeptCd", highDeptCd);
        parameterMap.put("authCd", authCd);
        
        DeptDisabledRowHandler rowHandler = 
                new DeptDisabledRowHandler(deptCds);
        
        getSqlSession().select("_vocSupport.listDept", parameterMap, rowHandler);
        
        return rowHandler.getList();
    }
    
    @SuppressWarnings("deprecation")
    public List<DeptBean> listDeptCheck(String highDeptCd, Integer authCd,
            String masterDeptCd, String supportDeptCds) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("topDeptCd", Constant.TOP_DEPT_CD);
        parameterMap.put("highDeptCd", highDeptCd);
        parameterMap.put("authCd", authCd);
        
        
        DeptCheckRowHandler rowHandler = 
                new DeptCheckRowHandler(masterDeptCd, supportDeptCds);
        
        getSqlSession().select("_vocSupport.listDept", parameterMap, rowHandler);
        
        return rowHandler.getList();
    }
    

    public String listDeptAllJSON(Integer authCd) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("topDeptCd", Constant.TOP_DEPT_CD);
        parameterMap.put("authCd", authCd);
        
        List<String> dataList = selectList("_vocSupport.listDeptAllJSON", parameterMap);
        
        StringBuilder builder = new StringBuilder(LEFT_SQ_BRACKET);
        for (String item : dataList) {
            builder.append(item);
        }
        builder.append(RIGHT_SQ_BRACKET);
        return builder.toString();
    }
    
    public List<MgrBean> listDealer(MgrBean bean) {
        
        return selectList("_vocSupport.listMgr", bean);
    }
    
    public List<VocDivBean> listDiv(Map<String, Object> parameterMap) {
        
        return selectList("_vocSupport.listDiv", parameterMap);
    }
    
    public List<VocSancBean> listSanc(Map<String, Object> parameterMap) {
        
        Integer vocSeq = (Integer)parameterMap.get("vocSeq");
        
        return selectList("_vocSupport.listSanc", vocSeq);
    }
    
    public List<String> listMySancStore(String mgrId) {
        
        return selectList("_vocSupport.listMySancStore", mgrId);
    }
    
    public int deleteSancLineAction(String mgrId, String sancLine) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("mgrId", mgrId);
        parameterMap.put("sancLine", sancLine);
        
        return delete("_vocSupport.deleteSancLine", parameterMap);
    }
    
    
    public VocLogBean viewExtReqLog(Integer vocSeq) {
        
        return selectOne("_vocSupport.viewExtReqLog", vocSeq);
    }
}
