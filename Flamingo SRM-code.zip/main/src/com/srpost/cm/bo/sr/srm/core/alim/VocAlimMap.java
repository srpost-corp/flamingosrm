package com.srpost.cm.bo.sr.srm.core.alim;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDao;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;

import static com.srpost.salmon.constant.StringPool.ONE;

/**
 * VOC 알림 메시지 변수 저장소
 *
 * @author  finkle
 * @date    2015-02-03
 * @since   3.0
 */
@SuppressWarnings("serial")
public final class VocAlimMap extends HashMap<String, Object> {

    /** 액션_코드 */
    private String actionCd;
    /** VOC 정보 */
    private VocBean vocBean;
    /** 분배 정보 */
    private VocDivBean divBean;
    /** 신청인 정보 */
    private MgrBean mgrBean;
    /** 직원 목록 */
    private List<MgrBean> mgrList = new ArrayList<MgrBean>();
    /** 사유 */
    private String reason;

    public void setActionCd(String actionCd) {
        this.actionCd = actionCd;
    }
    public void setVocBean(VocDao vocDao, Integer vocSeq) {
        vocBean = vocDao.view(vocSeq);
        divBean = VocUtil.getMyVocDivBean(vocBean.getDivList(), ONE);
    }
    public void setMgrBean(MgrBean bean) {
        mgrBean = bean;
    }
    public void addMgr(MgrBean bean) {
        mgrList.add(bean);
    }
    public void addAllMgr(List<MgrBean> list) {
        mgrList.addAll(list);
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
    
    public String getActionCd() {
        return actionCd;
    }
    public VocBean getVocBean() {
        return vocBean;
    }
    public VocDivBean getDivBean() {
        return divBean;
    }
    public List<MgrBean> getMgrList() {
        return mgrList;
    }
    public MgrBean getMgrBean() {
        return mgrBean;
    }
    public String getReason() {
        return reason;
    }
}
