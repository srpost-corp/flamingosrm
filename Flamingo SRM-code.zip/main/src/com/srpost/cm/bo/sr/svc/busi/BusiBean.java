package com.srpost.cm.bo.sr.svc.busi;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseListBean;

/**
 * 사업자 정보 Bean
 *
 * @author  Bella
 * @date    2017-04-18
 * @since   3.0
 */
@Alias("busiBean")
@SuppressWarnings("serial")
public class BusiBean extends BaseListBean {
    
    /** 사업_일련번호 */
    private Integer busiSeq;
    /** 사업_명 */
    private String busiNm;
    /** 사업자_번호 */
    private String busiNo;
    /** 대표자_명 */
    private String chiefNm;
    /** 이메일 */
    private String email;
    /** 전화_번호 */
    private String telNum;
    /** 팩스_번호 */
    private String faxNum;
    /** 우편번호 */
    private String postCd;
    /** 주소1 */
    private String addr1;
    /** 주소2 */
    private String addr2;
    /** 메인_업무 */
    private String mainOper;
    /** 사용_여부 */
    private String useYn;
    /** 등록일 */
    private String regDt;
    /** 수정일 */
    private String modiDt;
    
    /** 계약_일련번호 */
    private String ctrSeq;
    /** 정렬_순서 */
    private String orderNo;
    
    /** 사업_일련번호_배열 */
    private Integer[] busiSeqs;
    
    public Integer getBusiSeq() {
        return busiSeq;
    }
    public void setBusiSeq(Integer busiSeq) {
        this.busiSeq = busiSeq;
    }
    public String getBusiNm() {
        return busiNm;
    }
    public void setBusiNm(String busiNm) {
        this.busiNm = busiNm;
    }
    public String getBusiNo() {
        return busiNo;
    }
    public void setBusiNo(String busiNo) {
        this.busiNo = busiNo;
    }
    public String getChiefNm() {
        return chiefNm;
    }
    public void setChiefNm(String chiefNm) {
        this.chiefNm = chiefNm;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getTelNum() {
        return telNum;
    }
    public void setTelNum(String telNum) {
        this.telNum = telNum;
    }
    public String getFaxNum() {
        return faxNum;
    }
    public void setFaxNum(String faxNum) {
        this.faxNum = faxNum;
    }
    public String getPostCd() {
        return postCd;
    }
    public void setPostCd(String postCd) {
        this.postCd = postCd;
    }
    public String getAddr1() {
        return addr1;
    }
    public void setAddr1(String addr1) {
        this.addr1 = addr1;
    }
    public String getAddr2() {
        return addr2;
    }
    public void setAddr2(String addr2) {
        this.addr2 = addr2;
    }
    public String getMainOper() {
        return mainOper;
    }
    public void setMainOper(String mainOper) {
        this.mainOper = mainOper;
    }
    public String getUseYn() {
        return useYn;
    }
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
    public String getModiDt() {
        return modiDt;
    }
    public void setModiDt(String modiDt) {
        this.modiDt = modiDt;
    }
    public String getCtrSeq() {
        return ctrSeq;
    }
    public void setCtrSeq(String ctrSeq) {
        this.ctrSeq = ctrSeq;
    }
    public String getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    public Integer[] getBusiSeqs() {
        return busiSeqs;
    }
    public void setBusiSeqs(Integer[] busiSeqs) {
        this.busiSeqs = busiSeqs;
    }
    
}
