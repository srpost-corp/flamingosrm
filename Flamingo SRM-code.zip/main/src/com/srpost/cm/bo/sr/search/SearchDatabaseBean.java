package com.srpost.cm.bo.sr.search;

import java.util.List;
import java.util.Map;

import com.srpost.salmon.bean.BaseBean;

/**
 * SDB 현황 정보 Bean
 *
 * @author  finkle
 * @date    2014-11-11
 * @since   2.0
 */
@SuppressWarnings("serial")
public class SearchDatabaseBean extends BaseBean {
    
    /** DB 명 */
    private String dbName;
    /** DB 주소 */
    private long address;
    /** 테이블 정보 목록 */
    private List<Map<String, Object>> tableList;
    /** 스키마 정보 목록 */
    private List<Map<String, Object>> schemaList;
    
    
    public String getDbName() {
        return dbName;
    }
    public void setDbName(String dbName) {
        this.dbName = dbName;
    }
    public long getAddress() {
        return address;
    }
    public void setAddress(long address) {
        this.address = address;
    }
    public List<Map<String, Object>> getTableList() {
        return tableList;
    }
    public void setTableList(List<Map<String, Object>> tableList) {
        this.tableList = tableList;
    }
    public List<Map<String, Object>> getSchemaList() {
        return schemaList;
    }
    public void setSchemaList(List<Map<String, Object>> schemaList) {
        this.schemaList = schemaList;
    }
}
