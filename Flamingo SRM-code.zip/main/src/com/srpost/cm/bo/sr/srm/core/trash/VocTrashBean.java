package com.srpost.cm.bo.sr.srm.core.trash;

import org.apache.ibatis.type.Alias;

import com.srpost.cm.bo.sr.srm.core.VocBean;

/**
 * 내부단 VOC 삭제 정보 Bean
 *
 * @author  finkle
 * @date    2014-12-01
 * @since   2.0
 */
@Alias("vocTrashBean")
@SuppressWarnings("serial")
public class VocTrashBean extends VocBean {
    
    /** 삭제_코드 */
    private String delCd;
    /** 삭제_코드_명 */
    private String delNm;
    /** 삭제_사유 */
    private String delDesc;
    /** 삭제_일시 */
    private String delDt;
    
    public String getDelCd() {
        return delCd;
    }
    public void setDelCd(String delCd) {
        this.delCd = delCd;
    }
    public String getDelDesc() {
        return delDesc;
    }
    public void setDelDesc(String delDesc) {
        this.delDesc = delDesc;
    }
    public String getDelDt() {
        return delDt;
    }
    public void setDelDt(String delDt) {
        this.delDt = delDt;
    }
    public String getDelNm() {
        return delNm;
    }
    public void setDelNm(String delNm) {
        this.delNm = delNm;
    }
}
