package com.srpost.cm.bo.sr.srm.conf;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import com.srpost.salmon.cache.AbstractCache;
import com.srpost.salmon.cache.Cache;
import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 VOC설정 정보 Cache
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
public class VocConfCache extends AbstractCache {

    public static final String LIST_KEY = "__vc_lk__";
    public static final String VIEW_KEY = "__vc_vk__";
    
    private List<VocConfBean> cacheList = new ArrayList<VocConfBean>();
    
    @Resource
    IVocConfService service;
    
    @Override
    public void createCache() {
     
        List<VocConfBean> dataList = service.listCache();
        
        if (StringUtil.isNotEmpty(dataList)) {
            
            cacheList.clear();
            
            for (VocConfBean bean : dataList) {
                VocConfBean dataBean = service.view(bean);
                Cache.put(VIEW_KEY + bean.getVocCd(), dataBean);
                
                cacheList.add(dataBean);
            }
        }
        
        Cache.put(LIST_KEY, dataList);
    }

    @Override
    public void clearCache() {
        
        Cache.clear(LIST_KEY);
        Cache.clear(VIEW_KEY);
    }

    @Override
    public Object getCacheContents() {
        
        return cacheList;
    }

    @Override
    public String getName() {
        
        return "VOC 설정 정보";
    }

}
