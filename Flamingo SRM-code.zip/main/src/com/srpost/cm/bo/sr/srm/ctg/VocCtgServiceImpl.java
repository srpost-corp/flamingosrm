package com.srpost.cm.bo.sr.srm.ctg;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC분류 관리 서비스 구현체
 *
 * @author  finkle
 * @date    2014-11-20
 * @since   2.0
 */
@Service
public class VocCtgServiceImpl extends EgovAbstractServiceImpl implements IVocCtgService {

    @Resource
    VocCtgDao dao;
    
    @Override
    public List<VocCtgBean> list(VocCtgBean bean) {
        
        return dao.list(bean);
    }

    @Override
    public VocCtgBean view(VocCtgBean bean) {
        
        return dao.view(bean);
    }

    @Override
    public Object insertAction(VocCtgBean bean) {
        
        return dao.insertAction(bean);
    }

    @Override
    public int updateAction(VocCtgBean bean) {
        
        return dao.updateAction(bean);
    }

    @Override
    public int deleteAction(VocCtgBean bean) {
        
        return dao.deleteAction(bean);
    }
    
    @Override
    public List<VocCtgBean> listAll() {
        
        return dao.listAll();
    }
    
    @Override
    public Map<String, List<Object>> listByDepth() {
        
        return dao.listByDepth();
    }
}
