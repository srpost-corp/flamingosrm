package com.srpost.cm.bo.sr.stat.term;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.srpost.salmon.bean.BaseKeyValueBean;

/**
 * 내부단 VOC 통계(기간별) Util
 *
 * @author  finkle
 * @date    2014-12-24
 * @since   2.0
 */
public final class StatTermUtil {

    /**
     * 연도 목록 얻기
     */
    public static List<Integer> createYearList() {
        return createYearList(Calendar.getInstance().get(Calendar.YEAR));    
    }
    public static List<Integer> createYearList(Integer year) {

        int maxYear = Calendar.getInstance().get(Calendar.YEAR);
        
        List<Integer> dataList = new ArrayList<Integer>();

        if (year >= maxYear) year = maxYear;
        else if (year+2 >= maxYear) year = maxYear;
        else year = year+2;

        for (int i=year ; i >= year-4 ; i--) {
            dataList.add(i);
        }
        
        return dataList;
    }
    
    /**
     * 월 목록 얻기
     */
    public static List<String> createMonthList() {
        return createMonthList(false);
    }
    public static List<String> createMonthList(boolean isAppendZero) {

        List<String> dataList = new ArrayList<String>();
        for (int i=1 ; i <= 12 ; i++) {
            dataList.add(String.valueOf(isAppendZero ? (i < 10 ? "0" + i : i) : i));
        }
        return dataList;
    }
    
    /**
     * 일 목록 얻기
     */
    public static List<Integer> createDayList(int year, int month) {

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month-1);
        
        int lastDay = calendar.getActualMaximum(Calendar.DATE);
        
        List<Integer> dataList = new ArrayList<Integer>();
        for (int i=1 ; i <= lastDay ; i++) {
            dataList.add(i);
        }
        return dataList;
    }
    

    private static String[] DOW_NMS = {"일", "월", "화", "수", "목", "금", "토"};
    
    /**
     * 요일 목록 얻기
     */
    public static List<BaseKeyValueBean> createDowList() {

        List<BaseKeyValueBean> dataList = new ArrayList<BaseKeyValueBean>();
        for (int i=1 ; i <= 7 ; i++) {
            dataList.add(
                new BaseKeyValueBean(String.valueOf(i), DOW_NMS[i-1]));
        }
        return dataList;
    }
}
