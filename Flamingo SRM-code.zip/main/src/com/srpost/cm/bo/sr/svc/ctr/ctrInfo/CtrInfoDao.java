package com.srpost.cm.bo.sr.svc.ctr.ctrInfo;


import java.util.List;


import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.svc.ctr.CtrBean;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 계약 DAO
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Repository
public class CtrInfoDao extends EgovAbstractMapper {
    
    public CtrBean svcCtrView(CtrBean bean) {
        
        return selectOne("_ctrInfo.svcCtrView", bean);
    }
    
    public List<CtrBean> svcCtrList(CtrBean bean) {
        
        return selectList("_ctrInfo.svcCtrList", bean);
    }

}
