package com.srpost.cm.bo.sr.srm.core.alim;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 알림 DAO
 *
 * @author  finkle
 * @date    2014-12-16
 * @since   2.0
 */
@Repository
public class VocAlimDao extends EgovAbstractMapper {

    public List<VocAlimBean> list(VocAlimBean bean) {
        
        return selectList("_vocAlim.list", bean);
    }
    
    public VocAlimBean view(VocAlimBean bean) {
        
        return selectOne("_vocAlim.view", bean);
    }
    
    public synchronized int insertAction(VocAlimBean bean) {

        return insert("_vocAlim.insert", bean);
    }
}
