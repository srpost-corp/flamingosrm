package com.srpost.cm.bo.sr.srm.core.score;

import com.srpost.salmon.bean.BaseBean;

@SuppressWarnings("serial")
public class VocScoreBean extends BaseBean {

    /** VOC_일련번호 */
    private Integer vocSeq;
    /** 정렬 순서 */
    private Integer orderNo;
    /** 만족도 점수 */
    private Integer score;
    /** 등록_일시 */
    private String regDt;
    /** 수정_일시 */
    private String modiDt;
    
    public Integer getVocSeq() {
        return vocSeq;
    }
    public void setVocSeq(Integer vocSeq) {
        this.vocSeq = vocSeq;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public Integer getScore() {
        return score;
    }
    public void setScore(Integer score) {
        this.score = score;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
    public String getModiDt() {
        return modiDt;
    }
    public void setModiDt(String modiDt) {
        this.modiDt = modiDt;
    }
}
