package com.srpost.cm.bo.sr.srm.core.tags;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 내부단 VOC TAG 정보 Bean
 *
 * @author  finkle
 * @date    2014-11-20
 * @since   2.0
 */
@Alias("vocTagsBean")
@SuppressWarnings("serial")
public class VocTagsBean extends BaseBean {
    
    /** VOC_일련번호 */
    private Integer vocSeq;
    /** 정렬_순서 */
    private Integer orderNo;
    /** 태그_명 */
    private String tagNm;
    
    public VocTagsBean() {        
    }
    public VocTagsBean(Integer vocSeq, String tagNm) {
        this.vocSeq = vocSeq;
        this.tagNm = tagNm;        
    }
    
    public Integer getVocSeq() {
        return vocSeq;
    }
    public void setVocSeq(Integer vocSeq) {
        this.vocSeq = vocSeq;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public String getTagNm() {
        return tagNm;
    }
    public void setTagNm(String tagNm) {
        this.tagNm = tagNm;
    }
}
