package com.srpost.cm.bo.sr.srm.core.trash;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.salmon.bean.BasePagerBean;


/**
 * 내부단 VOC 휴지통 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-12-12
 * @since   2.0
 */
public interface IVocTrashService {

    BasePagerBean list(VocListBean bean);
    
    List<Map<String, Object>> listExcel(VocListBean bean);

    VocTrashBean view(VocTrashBean bean);
    
    String restoreAction(VocBean bean) throws Exception;
    
    String deleteAction(VocBean bean) throws Exception;
}
