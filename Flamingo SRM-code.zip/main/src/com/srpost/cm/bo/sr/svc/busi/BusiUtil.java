package com.srpost.cm.bo.sr.svc.busi;

import java.util.Map;

import jodd.util.StringUtil;

/**
 * 사업자 정보 Util
 *
 * @author  Bella
 * @date    2017-04-18
 * @since   3.0
 */
public class BusiUtil {
    
    public static Map<String, Object> getParameterMap(BusiBean bean) {
        
        Map<String, Object> parameterMap = bean.createPagerMap();
        
        if ( StringUtil.isNotEmpty(bean.getUseYn()) ) {
            parameterMap.put("useYn", bean.getUseYn());
        }
        
        return parameterMap;
    }
    
}
