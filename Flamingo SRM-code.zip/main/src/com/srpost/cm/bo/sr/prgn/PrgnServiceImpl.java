package com.srpost.cm.bo.sr.prgn;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 모범답안 서비스 구현체
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   2.0
 */
@Service
public class PrgnServiceImpl extends EgovAbstractServiceImpl implements IPrgnService {

    @Resource
    PrgnDao dao;

    @Override
    public BasePagerBean list(PrgnBean bean) {
        
        return dao.list(bean);
    }
    
    @Override
    public List<Map<String, Object>> listExcel(PrgnBean bean) {
        
        return dao.listExcel(bean);
    }

    @Override
    public PrgnBean view(PrgnBean bean) {
        
        return dao.view(bean);
    }

    @Override
    public int insertAction(PrgnBean bean) {
        
        return dao.insertAction(bean);
    }

    @Override
    public int updateAction(PrgnBean bean) {
        
        return dao.updateAction(bean);
    }

    @Override
    public int deleteAction(PrgnBean bean) {
        
        return dao.deleteAction(bean);
    }
    
    @Override
    public List<PrgnBean> listAll(PrgnBean bean) {
        
        return dao.listAll(bean);
    }
    
    @Override
    public String viewOne(PrgnBean bean) {
        
        return dao.viewOne(bean);
    }
}
