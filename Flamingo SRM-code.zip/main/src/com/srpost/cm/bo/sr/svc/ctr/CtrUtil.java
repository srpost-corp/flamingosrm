package com.srpost.cm.bo.sr.svc.ctr;

import java.util.Map;

import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * 계약 정보 Util
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
public class CtrUtil {
    
    /** 서비스 유형 코드 */
    public static final String SVC_TYPE_SVC = "SVC";      // 서비스
    
    public static Map<String, Object> getParameterMap(CtrBean bean) {
        
        Map<String, Object> parameterMap = bean.createPagerMap();
        
        if ( StringUtil.isNotEmpty(bean.getCtrSeq()) ) {
            parameterMap.put("ctrSeq", bean.getCtrSeq());
        }
        if ( StringUtil.isNotEmpty(bean.getOrderNo()) ) {
            parameterMap.put("orderNo", bean.getOrderNo());
        }
        
        if ( StringUtil.isNotEmpty(bean.getPrjSeq()) ) {
            parameterMap.put("type", SVC_TYPE_SVC);
            parameterMap.put("prjSeq", bean.getPrjSeq());
        }
        if ( StringUtil.isNotEmpty(bean.getObjSeq()) ) {
            parameterMap.put("type", SVC_TYPE_SVC);
            parameterMap.put("objSeq", bean.getObjSeq());
        }
        if ( StringUtil.isNotEmpty(bean.getBusiSeq()) ) {
            parameterMap.put("type", SVC_TYPE_SVC);
            parameterMap.put("busiSeq", bean.getBusiSeq());
        }
        
        return parameterMap;
    }
    
    public static void setNotNullValue(CtrBean bean) {
        
        if ( StringUtil.isNotEmpty(bean.getStartDd()) ) {
            bean.setStartDd(DateTimeUtil.removeDash(bean.getStartDd()));
        }
        if ( StringUtil.isNotEmpty(bean.getEndDd()) ) {
            bean.setEndDd(DateTimeUtil.removeDash(bean.getEndDd()));
        }
    }

}
