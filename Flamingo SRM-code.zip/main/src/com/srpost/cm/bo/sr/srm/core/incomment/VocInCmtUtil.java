package com.srpost.cm.bo.sr.srm.core.incomment;

import javax.servlet.http.HttpServletRequest;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 VOC 내부의견글 Util
 *
 * @author  finkle
 * @date    2015-01-16
 * @since   3.0
 */
public final class VocInCmtUtil {

    public static void setNotNullValue(VocInCmtBean bean) {
    }
    
    /* 본인 작성 글 여부 확인 */
    public static boolean isOwner(HttpServletRequest request, String mgrId) {
        
        LoginBean loginBean = MgrUtil.getSession(request);
        if ( StringUtil.equals(loginBean.getMgrId(), mgrId) ) {
            return true;
        }
        return false;
    }
}
