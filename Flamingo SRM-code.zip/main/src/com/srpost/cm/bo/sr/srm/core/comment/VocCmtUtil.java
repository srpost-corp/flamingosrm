package com.srpost.cm.bo.sr.srm.core.comment;

import javax.servlet.http.HttpServletRequest;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 VOC 외부의견글 Util
 *
 * @author  finkle
 * @date    2015-01-23
 * @since   3.0
 */
public final class VocCmtUtil {

    public static void setNotNullValue(VocCmtBean bean) {
    }
    
    public static void setWriterlValue(VocCmtBean bean, HttpServletRequest request) {

        LoginBean loginBean = MgrUtil.getSession(request);
        bean.setMgrId(loginBean.getMgrId());
        bean.setMgrNm(loginBean.getMgrNm());
    }
    
    /* 본인 작성 글 여부 확인 */
    public static boolean isOwner(VocCmtBean bean, HttpServletRequest request) {
        
        LoginBean loginBean = MgrUtil.getSession(request);
        return StringUtil.equals(loginBean.getMgrId(), bean.getMgrId());
    }
}
