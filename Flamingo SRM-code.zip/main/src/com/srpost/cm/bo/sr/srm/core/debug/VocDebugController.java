package com.srpost.cm.bo.sr.srm.core.debug;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.opensymphony.workflow.loader.ActionDescriptor;
import com.opensymphony.workflow.loader.WorkflowDescriptor;
import com.opensymphony.workflow.spi.Step;
import com.srpost.cm.bo.sr.srm.core.IVocService;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.osworkflow.SalmonWorkflow;
import com.srpost.salmon.web.mvc.controller.BaseController;

import static com.srpost.salmon.constant.StringPool.Y;
import static com.srpost.salmon.constant.StringPool.ZERO;

/**
 * 내부단 VOC 디버그용 컨트롤러
 *
 * @author  finkle
 * @date    2014-12-04
 * @since   3.0
 */
@Controller
@SuppressWarnings("unchecked")
@RequestMapping(value="/bo/sr/srm/core/debug")
public class VocDebugController extends BaseController {

    @Resource
    SalmonWorkflow workflow;
    @Resource
    IVocService vocService;
    @Resource
    IVocDebugService service;
    
    /**
     * 디버그 상세정보
     */
    @RequestMapping(value="a_view.do", method=RequestMethod.GET)
    public void view(VocBean bean, HttpServletRequest request, ModelMap model) {
        
        VocBean dataBean = vocService.viewSimple(bean.getVocSeq());
        List<VocDivBean> divList = service.listDiv(bean.getVocSeq());

        model.addAttribute("dataBean", dataBean);
        model.addAttribute("divList", divList);
        model.addAttribute("entryList", service.listEntry(bean.getVocSeq()));
        if (StringUtil.equals(dataBean.getSancYn(), Y))
            model.addAttribute("sancList", service.listSanc(bean.getVocSeq()));

        long wfId = -1;        
        if (StringUtil.isNotEmpty(divList)) {
            wfId = divList.get(ZERO).getWfId(); 
        }
        
        if (wfId > ZERO) {
            WorkflowDescriptor wfDescriptor = 
                    workflow.getWorkflowDescriptor(workflow.getWorkflowName(wfId));
    
            model.addAttribute("actionList", getWorkflowActions(wfId, wfDescriptor));
            model.addAttribute("currenetStepList", getCurrentSteps(wfId, wfDescriptor));
            model.addAttribute("historyStepList", getHistorySteps(wfId, wfDescriptor));
        }
    }
    
    /**
     * WF 목록
     */
    @RequestMapping(value="a_wfList.do", method=RequestMethod.GET)
    public void wfList(@RequestParam(value="wfId") long wfId, 
            VocBean bean, HttpServletRequest request, ModelMap model) {

        if (wfId > ZERO) {
            WorkflowDescriptor wfDescriptor = 
                    workflow.getWorkflowDescriptor(workflow.getWorkflowName(wfId));
    
            model.addAttribute("actionList", getWorkflowActions(wfId, wfDescriptor));
            model.addAttribute("currenetStepList", getCurrentSteps(wfId, wfDescriptor));
            model.addAttribute("historyStepList", getHistorySteps(wfId, wfDescriptor));
        }
    }

    private List<Map<String, Object>> getWorkflowActions(Long wfId, WorkflowDescriptor wfDescriptor) {
        
        int[] actions = workflow.getAvailableActions(wfId, null);
        
        List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>(actions.length);

        for (int i=0 ; i < actions.length ; i++) {
            ActionDescriptor actDescriptor = wfDescriptor.getAction(actions[i]);
            
            Map<String, Object> dataMap = new HashMap<String, Object>();
            dataMap.put("id", actDescriptor.getId());
            dataMap.put("name", actDescriptor.getName());
            dataMap.put("view", actDescriptor.getView());
            
            dataList.add(dataMap);
        }
        
        return dataList;
    }
    
    
    private List<Map<String, Object>> getCurrentSteps(Long wfId, WorkflowDescriptor wfDescriptor) {

        return getInternalSteps(workflow.getCurrentSteps(wfId), wfDescriptor);
    }
    
    private List<Map<String, Object>> getHistorySteps(Long wfId, WorkflowDescriptor wfDescriptor) {

        return getInternalSteps(workflow.getHistorySteps(wfId), wfDescriptor);
    }
    
    @SuppressWarnings("rawtypes")
    private List<Map<String, Object>> getInternalSteps(List<Step> steps, WorkflowDescriptor wfDescriptor) {
        
        List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>(steps.size());
        
        for (Iterator iterator = steps.iterator(); iterator.hasNext();) {
            
            if (wfDescriptor == null) continue;
            
            Step step = (Step)iterator.next();
            ActionDescriptor action = wfDescriptor.getAction(step.getActionId());
            
            Map<String, Object> dataMap = new HashMap<String, Object>();
            dataMap.put("entryId", step.getEntryId());
            dataMap.put("id", step.getId());
            dataMap.put("stepName", wfDescriptor.getStep(step.getStepId()).getName());
            dataMap.put("stepId", step.getStepId());
            dataMap.put("actionName", action == null ? "NONE" : action.getName());
            dataMap.put("actionId", step.getActionId());
            dataMap.put("owner", step.getOwner());
            dataMap.put("startDt", DateTimeUtil.toDateFull(step.getStartDate()));
            dataMap.put("finishDt", DateTimeUtil.toDateFull(step.getFinishDate()));
            dataMap.put("status", step.getStatus());
            dataMap.put("caller", step.getCaller());
            
            StringBuilder builder = new StringBuilder();
            long[] prevIds = step.getPreviousStepIds();
            if (prevIds != null) {
                for (int i = 0; i < prevIds.length; i++) {
                    long prevId = prevIds[i];
                    builder.append(prevId + ", ");
                }
            } else {
                builder.append("N/A");
            }
            dataMap.put("prevIds", builder.toString());
            
            dataList.add(dataMap);
        }
        
        return dataList;
    }
}
