package com.srpost.cm.bo.sr.stat.d3;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;
import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 통계(D3) DAO
 *
 * @author  finkle
 * @date    2016-07-20
 * @since   2.0
 */
@Repository
public class D3StatDao extends EgovAbstractMapper {

    
    public List<D3StatResultBean> statList(StatTypeSearchBean bean) {
        
        Map<String, Object> parameterMap = D3StatUtil.getParameterMap(bean);

        return selectList("_statD3.statList", parameterMap);
    }
    
    public BasePagerBean list(D3StatParameterBean bean) {
        
        Map<String, Object> parameterMap = D3StatUtil.getPagerMap(bean);
        
        List<VocBean> dataList = selectList("_statD3.vocList", parameterMap);
        int totalCount = (Integer)selectOne("_statD3.vocListCount", parameterMap);

        return new BasePagerBean(dataList, totalCount, bean);
    }
}