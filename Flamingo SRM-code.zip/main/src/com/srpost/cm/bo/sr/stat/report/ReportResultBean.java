package com.srpost.cm.bo.sr.stat.report;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseListBean;

/**
 * 리포트 정보 Bean
 *
 * @author  finkle
 * @date    2014-11-20
 * @since   2.0
 */
@Alias("reportResultBean")
@SuppressWarnings("serial")
public class ReportResultBean extends BaseListBean {
    
    /** 항목_명 */
    private String labelNm;
    /** 항목_명2 */
    private String labelNm2;
    /** 전체 건수 */
    private Integer totCnt;
    /** 주간 건수 */
    private Integer weekCnt;
    /** 월간 건수 */
    private Integer monthCnt;
    /** 전 전주 건수 */
    private Integer prevWeekCnt;
    /** 전 전월 건수 */
    private Integer prevMonthCnt;
    
    
    public String getLabelNm() {
        return labelNm;
    }
    public void setLabelNm(String labelNm) {
        this.labelNm = labelNm;
    }
    public Integer getTotCnt() {
        return totCnt;
    }
    public void setTotCnt(Integer totCnt) {
        this.totCnt = totCnt;
    }
    public Integer getWeekCnt() {
        return weekCnt;
    }
    public void setWeekCnt(Integer weekCnt) {
        this.weekCnt = weekCnt;
    }
    public Integer getMonthCnt() {
        return monthCnt;
    }
    public void setMonthCnt(Integer monthCnt) {
        this.monthCnt = monthCnt;
    }
    public Integer getPrevWeekCnt() {
        return prevWeekCnt;
    }
    public void setPrevWeekCnt(Integer prevWeekCnt) {
        this.prevWeekCnt = prevWeekCnt;
    }
    public Integer getPrevMonthCnt() {
        return prevMonthCnt;
    }
    public void setPrevMonthCnt(Integer prevMonthCnt) {
        this.prevMonthCnt = prevMonthCnt;
    }
    public String getLabelNm2() {
        return labelNm2;
    }
    public void setLabelNm2(String labelNm2) {
        this.labelNm2 = labelNm2;
    }
}
