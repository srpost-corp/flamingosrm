package com.srpost.cm.bo.sr.srm.core;

import static com.srpost.salmon.constant.StringPool.MINUS_ONE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

import com.srpost.cm.bo.sr.srm.core.trash.VocTrashBean;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.crypto.SalmonCrypto;

/**
 * 내부단 VOC 엑셀변환 row handler
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   3.0
 */
public class VocExcelRowHandler implements ResultHandler {

	private List<Map<String, Object>> list;

    public VocExcelRowHandler(SalmonCrypto salmonCtypto) {
    	
    	this.list = new ArrayList<Map<String, Object>>();
    }
    
    @Override
    public void handleResult(ResultContext context) {
        
        Object resultObject = context.getResultObject();

        VocBean dataBean = (VocBean)resultObject;
        
    	Map<String, Object> dataMap = new HashMap<String, Object>();

    	dataMap.put( "writerNm", dataBean.getWriterNm() );
        dataMap.put( "mobile", dataBean.getMobile());
    	dataMap.put( "email", dataBean.getEmail());
    	
    	dataMap.put( "fromNm", dataBean.getFromNm() );
    	/* dataMap.put( "fromChnlNm", dataBean.getFromChnlNm() );
    	dataMap.put( "fromOrgNm", dataBean.getFromOrgNm() ); */
        dataMap.put( "ctgNm1", dataBean.getCtgNm1() );
        dataMap.put( "ctgNm2", dataBean.getCtgNm2() );
        dataMap.put( "ctgNm3", dataBean.getCtgNm3() );
    	
        dataMap.put( "title", dataBean.getTitle() );
        dataMap.put( "alertNms", VocUtil.getAlertNms(dataBean.getAlertCds()) );
        dataMap.put( "openYn", StringUtil.parseOpenYn(dataBean.getOpenYn()) );
        dataMap.put( "manyYn", StringUtil.parseYn(dataBean.getManyYn()) );
        dataMap.put( "rptYn", StringUtil.parseYn(dataBean.getRptYn()) );
        dataMap.put( "regDt", dataBean.getRegDt() );
        dataMap.put( "modiDt", dataBean.getModiDt() );
        
        dataMap.put( "vocNm", dataBean.getVocNm() );
        dataMap.put( "kindNm", dataBean.getKindNm() );
        dataMap.put( "typeNm", dataBean.getTypeNm() );
        dataMap.put("cmplnNm", dataBean.getCmplnNm());
        dataMap.put( "rcvNo", dataBean.getRcvNo() );
        dataMap.put( "rcvNm", dataBean.getRcvNm() );
        dataMap.put( "rcvDt", dataBean.getRcvDt() );
        dataMap.put( "lmtDt", dataBean.getLmtDt() );
        dataMap.put( "mgrStatusNm", dataBean.getMgrStatusNm() );
        
        dataMap.put( "endDt", dataBean.getEndDt() );
        dataMap.put( "endNm", dataBean.getEndNm() );
        dataMap.put( "divInfo", dataBean.getDivInfo() );
        dataMap.put( "mgrInfo", dataBean.getMgrInfo() );
        dataMap.put( "scoreAvg", dataBean.getScoreAvg() );
        dataMap.put( "vocMemo", dataBean.getVocMemo() );
        
        dataMap.put( "tags", dataBean.getTags() );
        
        if ( dataBean.getEndCnt() != MINUS_ONE ) {
            dataMap.put( "endCnt", dataBean.getEndCnt() + "분" );
        }
        
        if (resultObject instanceof VocTrashBean) {
            VocTrashBean trashBean = (VocTrashBean)resultObject;
            
            dataMap.put( "delNm", trashBean.getDelNm() );
            dataMap.put( "delDesc", trashBean.getDelDesc() );
            dataMap.put( "delDt", trashBean.getDelDt() );
        }
        
        list.add(dataMap);
    }
    
    public List<Map<String, Object>> getList() {
        
        return list;
    }
}