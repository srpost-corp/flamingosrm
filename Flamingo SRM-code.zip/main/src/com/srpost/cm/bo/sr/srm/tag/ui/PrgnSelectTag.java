package com.srpost.cm.bo.sr.srm.tag.ui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.jsp.JspWriter;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.tags.RequestContextAwareTag;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.prgn.IPrgnService;
import com.srpost.cm.bo.sr.prgn.PrgnBean;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.lang.UTF8Util;

import static com.srpost.salmon.constant.StringPool.N;
import static com.srpost.salmon.constant.StringPool.Y;

@SuppressWarnings("serial")
public class PrgnSelectTag extends RequestContextAwareTag {

	private static final int PRV_CUT_LENGTH = 70;
	private static final int PUB_CUT_LENGTH = 50;
	
	@Override
    protected int doStartTagInternal() throws Exception {
		
		JspWriter writer = pageContext.getOut();
		
		Map<String, List<PrgnBean>> prgnMap = getPrgnListMap();
		
		List<PrgnBean> prvList = prgnMap.get("PRV_LIST");
		List<PrgnBean> pubList = prgnMap.get("PUB_LIST");
		
		StringBuilder html = new StringBuilder();
		html.append("<select id=\"prgn\" class=\"smf-select\" onchange=\"VOC.changePrgn(this.value);\">\n");
		html.append("<option value=\"\">-- 모범답안을 선택하세요. --</option>\n");
		
		if (StringUtil.isNotEmpty(prvList)) {
    		html.append("<optgroup label=\"본인 모범답안\">\n");
    		for (PrgnBean bean : prvList) {
    			html.append("<option value=\"" + bean.getMgrId() + "|" + bean.getOrderNo() + "\">" +  
    					UTF8Util.fixLength(bean.getTitle(), PRV_CUT_LENGTH) + "</option>\n");
    		}
    		html.append("</optgroup>");
		}
		
		if (StringUtil.isNotEmpty(pubList)) {
    		html.append("<optgroup label=\"공용 모범답안\">\n");
    		for (PrgnBean bean : pubList) {
    			html.append("<option value=\"" + bean.getMgrId() + "|" + bean.getOrderNo() + "\">" +  
    			        UTF8Util.fixLength(bean.getTitle(), PUB_CUT_LENGTH) + " (" + bean.getMgrNm() + ")</option>\n");
    		}
    		html.append("</optgroup>\n");
		}
		
        html.append("</select>\n");
        
		writer.write( html.toString() );
 
        return SKIP_BODY;
	}
	
	private Map<String, List<PrgnBean>> getPrgnListMap() {
	    
	    WebApplicationContext ctx = getRequestContext().getWebApplicationContext();
	    
		LoginBean loginBean = MgrUtil.getSession(pageContext.getSession());

		IPrgnService service = (IPrgnService)ctx.getBean("prgnServiceImpl");

		Map<String, List<PrgnBean>> prgnMap = new HashMap<String, List<PrgnBean>>();
        
        PrgnBean bean = new PrgnBean();
		bean.setMgrId(loginBean.getMgrId());
		
        // 개인용 모범답안
        bean.setOpenYn(N);
        prgnMap.put("PRV_LIST", service.listAll(bean));
        
		// 타인 공개용 모범답안
		bean.setOpenYn(Y);
		prgnMap.put("PUB_LIST", service.listAll(bean));
        
        return prgnMap;
    }
}
