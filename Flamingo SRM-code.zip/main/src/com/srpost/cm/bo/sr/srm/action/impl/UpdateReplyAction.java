package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.cm.bo.sr.srm.core.log.VocUpdateReplyLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringDiffUtil;
import com.srpost.salmon.lang.StringDiffUtil.Diff;
import com.srpost.salmon.lang.StringUtil;

/**
 * UPDATE_REPLY : 답변내용 수정 - 접수자 (처리완료일 경우에만 가능함)
 *
 * @author  finkle
 * @date    2015-01-06
 * @since   3.0
 */
public class UpdateReplyAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());
        VocDivBean myDivBean = VocUtil.getMyVocDivBean(divList, ONE);

        // 변경내역이 없다면 리턴 !!
        if ( StringUtil.equals(orgBean.getReply(), vocBean.getReply()) ) {
            logger.info("VOC 답변내용이 수정되지 않음. 내역 반영 안함");
            return;
        }
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || 
                StringUtil.equals(orgBean.getDelYn(), Y) ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * VOC 수정
         */
        VocUtil.setNotNullValue(vocBean);

        int affected = update("_vocAction.updateVocForReply", vocBean);
        
        if (affected == ONE) {
            
            /*-------------------------
             * 로그 등록
             */            
            StringBuilder logContents = new StringBuilder(); 
            
            Integer newOrderNo = diffInsert(orgBean, vocBean);
            if ( StringUtil.isEmpty(newOrderNo) ) {
                logContents.append("<strong>답변내용 수정</strong>");
            }
            else {
                logContents.append("<strong>답변내용 수정</strong> ");
                logContents.append("<a href=\"#\" onclick=\"js_updateReplyLogPop('" + newOrderNo + "'); return false;\">수정내역 보기</a>");
            }
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 처리자, 고객
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            alimMap.addMgr((MgrBean)selectOne("_mgr.view", myDivBean.getMgrId()));
            alimMap.setMgrBean((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getWriterId()));

            executeAlim(alimMap);
        }
    }
    
    private Integer diffInsert(VocBean orgBean, VocBean vocBean) {
        
        // 답변 수정 DIFF 등록
        List<Diff> diffResult = new StringDiffUtil().diff_main(orgBean.getReply(), vocBean.getReply());
        
        StringBuilder diffBuffer = new StringBuilder(); 
        
        for (Diff diff : diffResult) {
            if ( StringUtil.isEmpty(diff.text) ) continue;
            
            if ( diff.operation.equals(StringDiffUtil.Operation.EQUAL) ) {
                diffBuffer.append("<span class='diff-EQUAL'>" + diff.text + "</span>");
            }
            else if ( diff.operation.equals(StringDiffUtil.Operation.DELETE) ) {
                if ( StringUtil.trim(diff.text).length() != 0 )
                    diffBuffer.append("<span class='diff-DELETE' title='제거됨'>" + diff.text + "</span>");
            }
            else if ( diff.operation.equals(StringDiffUtil.Operation.INSERT) ) {
                diffBuffer.append("<span class='diff-INSERT' title='추가됨'>" + diff.text + "</span>");
            }
            else {
                diffBuffer.append("<span class='diff-OTHER'>" + diff.text);
            }
        }
        
        VocUpdateReplyLogBean vocUpdateReplyLogBean = new VocUpdateReplyLogBean();
        vocUpdateReplyLogBean.setVocSeq(vocBean.getVocSeq());
        vocUpdateReplyLogBean.setReply(diffBuffer.toString());
        
        vocLogDao.insertUpdateReplyLog(vocUpdateReplyLogBean);
        
        return vocUpdateReplyLogBean.getOrderNo();
    }
}
