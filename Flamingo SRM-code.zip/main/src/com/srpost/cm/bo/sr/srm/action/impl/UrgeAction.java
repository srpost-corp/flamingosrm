package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrDao;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;

/**
 * URGE : 독촉 - 접수자
 *
 * @author  finkle
 * @date    2014-12-05
 * @since   3.0
 */
public class UrgeAction extends AbstractAction {

    @Resource
    MgrDao mgrDao;
    
    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();
        String reason = (String)parameterMap.get("reason");
        String[] urgeIds = null;
        List<String> urgeNms = new ArrayList<String>();
        Object oUrgeIds = parameterMap.get("urgeIds");
        if (oUrgeIds instanceof String) {
            urgeIds = new String[] { (String)oUrgeIds };
        }
        else {
            urgeIds = (String[])oUrgeIds;
        }
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null ||
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                !(StringUtil.equals(orgBean.getMgrStatusCd(), MS_DIVIDE) || StringUtil.equals(orgBean.getMgrStatusCd(), MS_ASSIGN)) ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * 대상자 독촉 알림
         */
        for (String urgeId : urgeIds) {
            if ( StringUtil.isEmpty(urgeId) ) continue;
            
            String[] urgeString = StringUtil.split(urgeId, PIPE); // deptCd|mgrId
            String deptCd = urgeString[0];
            String mgrId = urgeString[1];
            
            if ( StringUtil.isEmpty(mgrId) ) {
                
                // 분배자 목록 얻기
                MgrBean paramMgrBean = new MgrBean();
                paramMgrBean.setDeptCd(deptCd);
                paramMgrBean.setAuthCd(AUTH_DIVIDER);
                
                List<MgrBean> dividerList = selectList("_vocSupport.listMgr", paramMgrBean);
                for (MgrBean item : dividerList) {
                    urgeNms.add(item.getMgrNm());
                }
                
                alimMap.addAllMgr(dividerList);
            }
            else {
                MgrBean mgrBean = mgrDao.view(mgrId);
                
                urgeNms.add(mgrBean.getMgrNm());
                
                alimMap.addMgr(mgrBean);
            }
        }
        
        // TODO : 독촉횟수 반영
        
        int affected = ONE;
        
        if (affected == ONE) {
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder(); 
            logContents.append("<strong>처리독촉</strong> : ");
            logContents.append(urgeNms.toString());
            logContents.append("<br/>독촉사유 : " + reason);
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 독촉 대상자
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            
            //사유
            alimMap.setReason(reason);
            
            executeAlim(alimMap);
        }
    }
}
