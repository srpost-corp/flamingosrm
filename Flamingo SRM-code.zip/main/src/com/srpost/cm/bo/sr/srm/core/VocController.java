package com.srpost.cm.bo.sr.srm.core;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.opensymphony.workflow.loader.ActionDescriptor;
import com.opensymphony.workflow.loader.WorkflowDescriptor;
import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.ctg.IVocCtgService;
import com.srpost.salmon.bean.BaseFileBean;
import com.srpost.salmon.constant.Message;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.FileUtil;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.lang.WebUtil;
import com.srpost.salmon.spi.osworkflow.OsWorkflowBean;
import com.srpost.salmon.spi.osworkflow.SalmonWorkflow;
import com.srpost.salmon.web.mvc.controller.BaseController;

import static com.srpost.salmon.constant.StringPool.*;

/**
 * 내부단 VOC 컨트롤러
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
@Controller
@SuppressWarnings({ "rawtypes", "unchecked" })
@RequestMapping(value="/bo/sr/srm/core")
public class VocController extends BaseController {

    @Resource
    SalmonWorkflow workflow;
    @Resource
    IVocService service;
    @Resource
    IVocCtgService ctgService;
    
    /**
     * VOC 대시보드
     */
    @RequestMapping(value="dashboard.do", method=RequestMethod.GET)
    public String dashboard(ModelMap model) {
        
        return "/bo/sr/srm/dashboard";
    }
    
    
    /**
     * VOC 메인
     */
    @RequestMapping(value="{authCd}/index.do", method=RequestMethod.GET)
    public String index(@PathVariable("authCd") Integer authCd, VocListBean bean, ModelMap model) {
        
        if (authCd != AUTH_REGISTER && authCd != AUTH_SYSTEM && authCd != AUTH_RECEIVER && 
                authCd != AUTH_DIVIDER && authCd != AUTH_DEALER && authCd != AUTH_SANCER) {
        
            return alertAndBack(model, Message.fail(Message.BASE_AUTH_READ_FAIL_KEY));
        }
        
        model.addAttribute("pagerBean", service.list(bean));
        model.addAttribute("ctgListMap", ctgService.listByDepth());
        model.addAttribute("confList", VocUtil.getConfList());
        
        return baseUrl + "/index";
    }
    
    /**
     * VOC 메인 : GRID용
     */
    @RequestMapping(value="{authCd}/indexGrid.do", method=RequestMethod.GET)
    public String indexGrid(@PathVariable("authCd") Integer authCd, VocListBean bean, ModelMap model) {
        
        if (authCd != AUTH_SYSTEM && authCd != AUTH_RECEIVER && 
                authCd != AUTH_DIVIDER && authCd != AUTH_DEALER && authCd != AUTH_SANCER) {
        
            return alertAndBack(model, Message.fail(Message.BASE_AUTH_READ_FAIL_KEY));
        }
        
        model.addAttribute("ctgListMap", ctgService.listByDepth());
        model.addAttribute("confList", VocUtil.getConfList());
        
        return baseUrl + "/indexGrid";
    }
    
    /**
     * VOC 목록
     */
    @RequestMapping(value="{authCd}/j_list.do", method=RequestMethod.GET)
    public ModelAndView list(@PathVariable("authCd") Integer authCd, VocListBean bean, ModelMap model) {
        
        bean.setAuthCd(authCd);
        
        return responseJson(model, service.list(bean));
    }
    
    /**
     * VOC 등록 폼
     */
    @RequestMapping(value="form.do", method=RequestMethod.GET)
    public void form(VocBean bean, HttpServletRequest request, ModelMap model) {
        
        model.addAttribute("isReceiver", 
                MgrUtil.hasAuthCd(request, AUTH_RECEIVER));
        
        model.addAttribute("confList", VocUtil.getConfList());
        model.addAttribute("dataBean", bean);
        model.addAttribute("excludeFromCds", VocConstant.EXCLUDE_FROM_CDS);
        model.addAttribute("ctgListMap", ctgService.listByDepth());
    }
    
    /**
     * VOC 처리 액션
     */
    @RequestMapping(value="t_executeAction.do", method=RequestMethod.POST)
    public ModelAndView executeAction(VocBean bean, HttpServletRequest request, ModelMap model) {
        
        List<BaseFileBean> fileList = FileUtil.getUploadFile(request);
        
        // 전송된 첨부파일 정보를 고객단과 관리자단으로 분리
        if (StringUtil.isNotEmpty(fileList)) {

            List<BaseFileBean> userFileList = new ArrayList<BaseFileBean>();
            List<BaseFileBean> mgrFileList = new ArrayList<BaseFileBean>();
            
            for (BaseFileBean item : fileList) {
                if ( StringUtil.equals(item.getInputNm(), "files") ) {
                    mgrFileList.add(item);
                }
                else {
                    userFileList.add(item);
                }
            }
            bean.setUserFileList(userFileList);
            bean.setMgrFileList(mgrFileList);
        }
        
        try {
            String result = service.executeAction(bean);
            
            if ( !StringUtil.equals(result, Message.SUCCESS) ) {
                return responseText(model, result);
            }
        }
        catch (VocAlreadyExecuteException e) {
            return responseText(model, Message.fail("voc.already.execute.fail"));
        }
        catch (Exception e) {
            return responseText(model, Message.failMessage(e.toString()));
        }
        
        return responseText(model, Message.success("voc.action.success"));
    }

    /**
     * VOC 상세정보
     */
    @RequestMapping(value={"{authCd}/view.do", "{authCd}/*_view.do"}, method={RequestMethod.GET, RequestMethod.POST})
    public String view(@PathVariable("authCd") Integer authCd, VocBean bean, 
            HttpServletRequest request, HttpServletResponse response, ModelMap model) {

        VocBean dataBean = service.view(bean, VocUtil.needUpdateReadCnt(bean, request, response));
        
        if (dataBean == null) {
            return alertAndBack(model, "bbs.already.deleteted.fail");
        }
        
        model.addAttribute("dataBean", dataBean);
        model.addAttribute("confBean", VocUtil.getConfBean(dataBean.getVocCd()));
        
        LoginBean loginBean = MgrUtil.getSession(request);

        VocDivBean myDivBean = null;
        
        // 접수자, 결재자일 경우

        if (authCd == VocConstant.AUTH_RECEIVER || authCd == VocConstant.AUTH_SANCER) {
            myDivBean = VocUtil.getMyVocDivBean(dataBean.getDivList(), ONE);
        }
        else {
            myDivBean = VocUtil.getMyVocDivBean(dataBean.getDivList(), loginBean);
        }
        model.addAttribute("myDivBean", myDivBean);
        
        Map<String, Integer> countMyEntryMap = service.countMyEntryMap(
                new VocEntryBean(bean.getVocSeq(), loginBean.getMgrId(), EMPTY));

        Integer entryTotal = (Integer)countMyEntryMap.get("entryTotal");
        
        // ENTRY TOTAL 카운트가 존재할 경우에만 액션 버튼 설정
        if (entryTotal > ZERO && myDivBean != null) {
            
            // if (myDivBean.getWfId() > ZERO) {
            if (!StringUtil.equals(dataBean.getMgrStatusCd(), MS_END)) {
                Map transientVars = new HashMap();
                transientVars.put("isBtnCondition", true);
                transientVars.put("authCd", authCd);
                transientVars.put("loginBean", loginBean);
                transientVars.put("dataBean", dataBean);
                transientVars.put("myDivBean", myDivBean);
                transientVars.putAll(countMyEntryMap);
    
                int[] actions = workflow.getAvailableActions(myDivBean.getWfId(), transientVars);
                List<OsWorkflowBean> actionList = new ArrayList<OsWorkflowBean>(actions.length);
                WorkflowDescriptor wfDescriptor = workflow.getWorkflowDescriptor(workflow.getWorkflowName(myDivBean.getWfId()));
                
                for (int i=0 ; i < actions.length ; i++) {
                    ActionDescriptor actDescriptor = wfDescriptor.getAction(actions[i]);

                    actionList.add(
                        new OsWorkflowBean(actDescriptor.getId(), actDescriptor.getName(), actDescriptor.getView()));
                }
                
                // 접수자 && 복합 VOC일 경우 반송 시 재분배 버튼 표시
                if (authCd == VocConstant.AUTH_RECEIVER && StringUtil.equals(dataBean.getKindCd(), KND_COMPLEX)) {
                    boolean hasReDivideCount = VocUtil.hasReDivideCount(dataBean.getDivList());
                    if (hasReDivideCount && StringUtil.equals(loginBean.getMgrId(), dataBean.getRcvId())) {
                        ActionDescriptor actDescriptor = wfDescriptor.getAction(WF_REDIVIDE_ACTION_ID);
                        
                        actionList.add(
                            new OsWorkflowBean(actDescriptor.getId(), actDescriptor.getName(), actDescriptor.getView()));
                    }
                }
                
                // 협조부서 답변 완료 여부
                if ( StringUtil.equals(dataBean.getKindCd(), KND_COMPLEX) &&
                        (authCd == AUTH_DIVIDER || authCd == AUTH_DEALER) &&
                        StringUtil.equals(myDivBean.getMasterYn(), Y) ) {
                    
                    boolean isFinishSupportDeptReply = VocUtil.isFinishSupportDeptReply(dataBean.getDivList());
                    model.addAttribute("supportNotFinish", !isFinishSupportDeptReply);
                }
                
                model.addAttribute("actionList", actionList);
            }
        }
        
        return baseUrl + WebUtil.getFinalPath(request, true);
    }
    
    /**
     * 엑셀 변환 팝업창
     */
    @RequestMapping(value="{authCd}/p_excelForm.do", method=RequestMethod.GET)
    public String excelForm(@PathVariable("authCd") Integer authCd) {
        
        return baseUrl + "/p_excelForm";
    }
    
    /**
     * 엑셀 변환 액션
     */
    @RequestMapping(value="{authCd}/x_excelAction.do", method=RequestMethod.POST)
    public ModelAndView excelAction(@PathVariable("authCd") Integer authCd, 
            VocListBean bean, ModelMap model) {
        
        bean.setAuthCd(authCd);
        
        List<Map<String, Object>> dataList = service.listExcel(bean);

        return responseExcel(model, dataList, bean);
    }
}
