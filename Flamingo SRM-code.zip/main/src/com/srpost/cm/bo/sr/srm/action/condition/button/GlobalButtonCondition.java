package com.srpost.cm.bo.sr.srm.action.condition.button;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.opensymphony.module.propertyset.PropertySet;
import com.opensymphony.workflow.Condition;
/*
import com.opensymphony.workflow.config.Configuration;
import com.opensymphony.workflow.config.SpringConfiguration;
import com.opensymphony.workflow.loader.WorkflowDescriptor;
import com.opensymphony.workflow.spi.SimpleWorkflowEntry;
import com.opensymphony.workflow.spi.Step;
import com.opensymphony.workflow.spi.WorkflowEntry;
*/
import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.salmon.lang.StringUtil;

import static com.srpost.salmon.constant.StringPool.ZERO;
import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 전역 : 버튼 표시 여부 판단을 위한 Condition
 *
 * @author  finkle
 * @date    2014-12-08
 * @since   3.0
 */
@SuppressWarnings("rawtypes") 
@Component(value="BTN_globalCondition")
public class GlobalButtonCondition extends EgovAbstractMapper implements Condition {

    @Override
    public boolean passesCondition(Map transientVars, Map args, PropertySet ps) {
        
        /*--
        System.out.println("--------------------------------");
        System.out.println("transientVars :");
        System.out.println(transientVars);
        System.out.println("args :");
        System.out.println(args);
        System.out.println("ps :");
        System.out.println(ps);
        System.out.println("--------------------------------");
        --*/
        
        Boolean isBtnCondition = (Boolean)transientVars.get("isBtnCondition");
        
        // WF 액션실행일 경우 true
        if (isBtnCondition == null || !isBtnCondition) {
            
            return true;
        }
        // 버튼 표시 여부 판단
        else {
            Integer authCd = (Integer)transientVars.get("authCd");
            LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
            VocBean dataBean = (VocBean)transientVars.get("dataBean");
            VocDivBean myDivBean = (VocDivBean)transientVars.get("myDivBean");
            
            Integer entryActive = (Integer)transientVars.get("entryActive");
            // Integer entryInactive = (Integer)transientVars.get("entryInactive");
            // Integer entryTotal = (Integer)transientVars.get("entryTotal");
            
            String mgrStatusCd = dataBean.getMgrStatusCd();
            String actionCode = (String)args.get("action.code");
            
            if (StringUtil.equals(mgrStatusCd, MS_END)) {
                return false;
            }
            
            /*-------------------------------------------------------------------------
             * 접수자 : 접수자 스텝
             */
            if (authCd == AUTH_RECEIVER) {
                // 접수
                if (StringUtil.equals(actionCode, ACTION_RECEIVE)) {
                    
                    return entryActive > ZERO && StringUtil.equals(mgrStatusCd, MS_READY);
                }
                // 분배
                else if (StringUtil.equals(actionCode, ACTION_DIVIDE)) {
                    
                    return entryActive > ZERO && !StringUtil.equals(dataBean.getKindCd(), KND_COMPLEX);
                }
                // 처리자 직접지정
                else if (StringUtil.equals(actionCode, ACTION_DIRECT_ASSIGN)) {
                    
                    return entryActive > ZERO && !StringUtil.equals(dataBean.getKindCd(), KND_COMPLEX);
                }
                // 직접 처리
                else if (StringUtil.equals(actionCode, ACTION_DIRECT_DEAL)) {
                    
                    return entryActive > ZERO && !StringUtil.equals(dataBean.getKindCd(), KND_COMPLEX);
                }
                // 이첩
                else if (StringUtil.equals(actionCode, ACTION_TRANSFER)) {
                    
                    return entryActive > ZERO && StringUtil.equals(mgrStatusCd, MS_READY);
                }
                // 삭제
                else if (StringUtil.equals(actionCode, ACTION_TRASH)) {
                    
                    // 분배 후 반송 시 접수자가 삭제할 방법이 없으므로 접수상태에서도 삭제 가능하도록 수정함
                    if (entryActive > ZERO) {
                        return StringUtil.equals(mgrStatusCd, MS_READY) || StringUtil.equals(mgrStatusCd, MS_RECEIVE);
                    }
                    return false;
                }
                
                /*-------------------------------------------------------------------------
                 * 접수자 : 접수자/분배자/처리자 스텝 공용
                 */

                // 회수
                else if (StringUtil.equals(actionCode, ACTION_RECOVERY)) {

                    /*--
                    System.out.println("-------------- 회수 ------------------");
                    //Configuration configuration = (Configuration)transientVars.get("configuration");
                    List<Step> currentSteps = (List<Step>)transientVars.get("currentSteps");
                    WorkflowEntry entry = (WorkflowEntry)transientVars.get("entry");
                    //WorkflowDescriptor descriptor = (WorkflowDescriptor)transientVars.get("descriptor");
                    
                    System.out.println(currentSteps.size());
                    System.out.println(currentSteps.get(0));
                    System.out.println(entry.getWorkflowName()); // WF NAME : VOC
                    System.out.println(entry.getId());  // WF ENTRY ID
                    --*/

                    // 복합 VOC일 경우 모든 부서 반송시 처리상태가 접수로 변경되므로 접수일 때는 회수 가능함
                    if (StringUtil.equals(dataBean.getKindCd(), KND_COMPLEX)) {
                        return StringUtil.equals(loginBean.getMgrId(), dataBean.getRcvId()) && StringUtil.equals(mgrStatusCd, MS_RECEIVE);
                    }
                    // 일반 VOC일 경우 미접수, 접수 상태 모두 체크함
                    else {
                        if (StringUtil.equals(mgrStatusCd, MS_READY) || StringUtil.equals(mgrStatusCd, MS_RECEIVE)) {
                            return false;
                        }
                    }
                        
                    return StringUtil.equals(loginBean.getMgrId(), dataBean.getRcvId()) && !StringUtil.equals(mgrStatusCd, MS_END);
                }
                // 독촉
                else if (StringUtil.equals(actionCode, ACTION_URGE)) {
                    
                    if (StringUtil.equals(mgrStatusCd, MS_READY) || StringUtil.equals(mgrStatusCd, MS_RECEIVE)) {
                        return false;
                    }
                    
                    return StringUtil.equals(loginBean.getMgrId(), dataBean.getRcvId()) && !StringUtil.equals(mgrStatusCd, MS_END);
                }
                // 기한연장
                else if (StringUtil.equals(actionCode, ACTION_EXTENSION)) {
                    
                    if (StringUtil.equals(mgrStatusCd, MS_READY) || StringUtil.equals(mgrStatusCd, MS_RECEIVE)) {
                        return false;
                    }
                    
                    return StringUtil.equals(loginBean.getMgrId(), dataBean.getRcvId()) && !StringUtil.equals(mgrStatusCd, MS_END);
                }
                
                /*-------------------------------------------------------------------------
                 * 접수자 : 복합 VOC일 경우
                 * VocController에서 버튼 표시 수동 제어함
                 */
                
                // 재분배
                else if (StringUtil.equals(actionCode, ACTION_REDIVIDE)) {
                    
                    /*--
                    boolean hasReDivideCount = VocUtil.hasReDivideCount(dataBean.getDivList());

                    return entryActive > ZERO && hasReDivideCount && StringUtil.equals(dataBean.getKindCd(), KND_COMPLEX);
                    --*/
                    
                    return false;
                }
            }

            /*-------------------------------------------------------------------------
             * 분배자
             */
            else if (authCd == AUTH_DIVIDER || authCd == AUTH_DEALER) {
                
                if (authCd == AUTH_DIVIDER) {
                    // 처리자 지정
                    if (StringUtil.equals(actionCode, ACTION_ASSIGN)) {                        
                        return entryActive > ZERO;
                    }
                }
                
                // 처리 (*)
                if (StringUtil.equals(actionCode, ACTION_DEAL)) {
                    
                    // 복합 VOC일 경우
                    if (StringUtil.equals(dataBean.getKindCd(), KND_COMPLEX)) {
    
                        boolean iAmBelongToMasterDept = 
                                VocUtil.isBelongToMasterDept(dataBean.getDivList(), loginBean);
                        
                        if (iAmBelongToMasterDept) {
                            // 협조부서 답변이 모두 완료되었는지 체크
                            boolean isFinishSupportDeptReply = VocUtil.isFinishSupportDeptReply(dataBean.getDivList());
                        
                            return isFinishSupportDeptReply && entryActive > ZERO;
                        }
                        else {                    
                            return entryActive > ZERO;
                        }
                    }
                    
                    return entryActive > ZERO;
                }
                // 반송 (*)
                else if (StringUtil.equals(actionCode, ACTION_SEND_BACK)) {
                    
                    return entryActive > ZERO;
                }
                // 전달 (*)
                else if (StringUtil.equals(actionCode, ACTION_MOVE)) {
                    
                    return entryActive > ZERO;
                }
                // 기한연장 요청 (*) : 주무부서만 가능
                else if (StringUtil.equals(actionCode, ACTION_EXTENSION_REQ)) {
    
                    boolean iAmBelongToMasterDept = 
                            VocUtil.isBelongToMasterDept(dataBean.getDivList(), loginBean);
                    
                    return iAmBelongToMasterDept && entryActive > ZERO;
                }
                // 결재취소 (*) : 분배자/처리자
                else if (StringUtil.equals(actionCode, ACTION_SANC_CANCEL)) {
    
                    // 결재가 1번이라도 승인이 되었다면 결재취소 불가
                    if (VocUtil.isApproveOnceInSanc(dataBean.getSancList())) {
                        return false;
                    }
                    
                    VocEntryBean entryBean = new VocEntryBean();
                    entryBean.setVocSeq(dataBean.getVocSeq());
                    entryBean.setActivate(ACT_REPORTER);
                    entryBean.setAuthCd(AUTH_DEALER);
                    
                    String reporterId = selectOne("_vocSupport.viewMgrIdFromEntry", entryBean);
                    
                    if (StringUtil.isEmpty(reporterId)) {
                        entryBean.setAuthCd(AUTH_DIVIDER);
                        reporterId = selectOne("_vocSupport.viewMgrIdFromEntry", entryBean);
                    }
    
                    return StringUtil.equals(reporterId, loginBean.getMgrId()) && StringUtil.equals(mgrStatusCd, MS_SANC);
                }
                
                /*-------------------------------------------------------------------------
                 * 처리자 : 위 분배자의 처리, 반송, 전달, 기한연장 요청 공용
                 */
            }
            
            /*-------------------------------------------------------------------------
             * 결재자 : 결재자 스텝
             */
            else if (authCd == AUTH_SANCER) {

                // 결재승인
                if (StringUtil.equals(actionCode, ACTION_SANC_APPROVE)) {
                    
                    return entryActive > ZERO;
                }
                // 결재반려
                else if (StringUtil.equals(actionCode, ACTION_SANC_DENY)) {
                    
                    return entryActive > ZERO;
                }
            }
            
            return false;
        }
    }
}
