package com.srpost.cm.bo.sr.svc.ctr;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.srpost.cm.bo.sr.svc.busi.BusiBean;
import com.srpost.cm.bo.sr.svc.ctr.ctrModal.CtrMgrBean;
import com.srpost.cm.bo.sr.svc.obj.ObjBean;
import com.srpost.cm.bo.sr.svc.prj.PrjBean;
import com.srpost.salmon.bean.BaseListBean;

/**
 * 계약 정보 Bean
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Alias("ctrBean")
@SuppressWarnings("serial")
public class CtrBean extends BaseListBean {
    
    /** 계약_담당자_목록 */
    private List<CtrMgrBean> mgrList;
    /**  */
    private List<PrjBean> prjList;
    /**  */
    private List<ObjBean> objList;
    /**  */
    private List<BusiBean> busiList;
    
    /** 계약_일련번호 */
    private Integer ctrSeq;
    /** 정렬_순서 */
    private Integer orderNo;
    /** 계약_명 */
    private String ctrNm;
    /** 시작_일자 */
    private String startDd;
    /** 종료_일자 */
    private String endDd;
    /** 등록일 */
    private String regDt;
    /** 수정일 */
    private String modiDt;
    
    /** 진행_일수 */
    private Integer ingCnt;
    /** 일련번호 */
    private Integer seq;
    /** 담당자_ID */
    private String mgrId;
    /** 재계약 */
    private String reCtrYn;
    
    /** 프로젝트 일련번호 */
    private Integer prjSeq;
    /** 제품_일련번호 */
    private Integer objSeq;
    /** 사업자_일련번호 */
    private Integer busiSeq;
    
    /** 계약_일련번호_배열 */
    private Integer[] ctrSeqs;
    
    /** 담당자_배열 */
    private String[] mgrDatas;
    /** 프로젝트_배열 */
    private Integer[] prjDatas;
    /** 제품_배열 */
    private Integer [] objDatas;
    /** 사업자_배열 */
    private Integer[] busiDatas;
    
    public List<CtrMgrBean> getMgrList() {
        return mgrList;
    }
    public void setMgrList(List<CtrMgrBean> mgrList) {
        this.mgrList = mgrList;
    }
    public List<PrjBean> getPrjList() {
        return prjList;
    }
    public void setPrjList(List<PrjBean> prjList) {
        this.prjList = prjList;
    }
    public List<ObjBean> getObjList() {
        return objList;
    }
    public void setObjList(List<ObjBean> objList) {
        this.objList = objList;
    }
    public List<BusiBean> getBusiList() {
        return busiList;
    }
    public void setBusiList(List<BusiBean> busiList) {
        this.busiList = busiList;
    }
    public Integer getCtrSeq() {
        return ctrSeq;
    }
    public void setCtrSeq(Integer ctrSeq) {
        this.ctrSeq = ctrSeq;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public String getCtrNm() {
        return ctrNm;
    }
    public void setCtrNm(String ctrNm) {
        this.ctrNm = ctrNm;
    }
    public String getStartDd() {
        return startDd;
    }
    public void setStartDd(String startDd) {
        this.startDd = startDd;
    }
    public String getEndDd() {
        return endDd;
    }
    public void setEndDd(String endDd) {
        this.endDd = endDd;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
    public String getModiDt() {
        return modiDt;
    }
    public void setModiDt(String modiDt) {
        this.modiDt = modiDt;
    }
    public Integer getIngCnt() {
        return ingCnt;
    }
    public void setIngCnt(Integer ingCnt) {
        this.ingCnt = ingCnt;
    }
    public Integer getSeq() {
        return seq;
    }
    public void setSeq(Integer seq) {
        this.seq = seq;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getReCtrYn() {
        return reCtrYn;
    }
    public void setReCtrYn(String reCtrYn) {
        this.reCtrYn = reCtrYn;
    }
    public Integer getPrjSeq() {
        return prjSeq;
    }
    public void setPrjSeq(Integer prjSeq) {
        this.prjSeq = prjSeq;
    }
    public Integer getObjSeq() {
        return objSeq;
    }
    public void setObjSeq(Integer objSeq) {
        this.objSeq = objSeq;
    }
    public Integer getBusiSeq() {
        return busiSeq;
    }
    public void setBusiSeq(Integer busiSeq) {
        this.busiSeq = busiSeq;
    }
    public Integer[] getCtrSeqs() {
        return ctrSeqs;
    }
    public void setCtrSeqs(Integer[] ctrSeqs) {
        this.ctrSeqs = ctrSeqs;
    }
    public String[] getMgrDatas() {
        return mgrDatas;
    }
    public void setMgrDatas(String[] mgrDatas) {
        this.mgrDatas = mgrDatas;
    }
    public Integer[] getPrjDatas() {
        return prjDatas;
    }
    public void setPrjDatas(Integer[] prjDatas) {
        this.prjDatas = prjDatas;
    }
    public Integer[] getObjDatas() {
        return objDatas;
    }
    public void setObjDatas(Integer[] objDatas) {
        this.objDatas = objDatas;
    }
    public Integer[] getBusiDatas() {
        return busiDatas;
    }
    public void setBusiDatas(Integer[] busiDatas) {
        this.busiDatas = busiDatas;
    }
    
}
