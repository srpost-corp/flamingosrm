package com.srpost.cm.bo.sr.stat.report;

import java.util.List;

import com.srpost.salmon.bean.BaseListBean;
import com.srpost.salmon.bean.BasePagerBean;

/**
 * 리포트 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-12-18
 * @since   3.0
 */
public interface IReportService {
    
    /** 주요 이슈 카테고리 전체 */
    List<ReportResultBean> allCtgList();

    /** SR 이슈 태그 전체 */
    BasePagerBean allTagList(BaseListBean bean);
}
