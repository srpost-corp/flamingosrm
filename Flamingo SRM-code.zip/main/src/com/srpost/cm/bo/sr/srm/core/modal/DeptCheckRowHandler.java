package com.srpost.cm.bo.sr.srm.core.modal;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.ArrayList;
import java.util.List;

import jodd.util.ArraysUtil;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

import com.srpost.cm.bo.base.dept.DeptBean;
import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 부서 TREE Check 목록 row handler
 *
 * @author  finkle
 * @date    2014-11-26
 * @since   3.0
 * @deprecated  전체 부서목록 가져오는 것으로 변경, 2015-01-14
 */
public class DeptCheckRowHandler implements ResultHandler {

	private List<DeptBean> list;
	private String masterDeptCd;
	private String[] supportDeptCds;

    public DeptCheckRowHandler(String masterDeptCd, String supportDeptCds) {
    	
    	list = new ArrayList<DeptBean>();
    	this.masterDeptCd = masterDeptCd;
    	this.supportDeptCds = StringUtil.split(supportDeptCds, COMMA);
    }
    
    @Override
    public void handleResult(ResultContext context) {
        
        DeptBean dataBean = (DeptBean)context.getResultObject();
        
        if ( StringUtil.isNotEmpty(masterDeptCd) && StringUtil.equals(dataBean.getId(), masterDeptCd) ) {
            dataBean.setChecked(FALSE);
            dataBean.setDisabled(TRUE);
        }
        else if ( StringUtil.isNotEmpty(supportDeptCds) && ArraysUtil.contains(supportDeptCds, dataBean.getId()) ) {
            dataBean.setChecked(TRUE);
            dataBean.setDisabled(FALSE);
        }
        else {
            dataBean.setChecked(FALSE);
        }

        list.add(dataBean);
    }
    
    public List<DeptBean> getList() {
        
        return list;
    }
}