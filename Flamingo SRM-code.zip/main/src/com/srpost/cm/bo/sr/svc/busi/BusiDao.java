package com.srpost.cm.bo.sr.svc.busi;

import static com.srpost.salmon.constant.StringPool.ONE;
import static com.srpost.salmon.constant.StringPool.ZERO;

import java.lang.reflect.Array;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.bean.BasePagerBean;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.egov.ISalmonSeqGenerator;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 사업자 DAO
 *
 * @author  Bella
 * @date    2017-04-18
 * @since   3.0
 */
@Repository
public class BusiDao extends EgovAbstractMapper {
    
    @Resource(name = "busiSeqGenerator")
    ISalmonSeqGenerator seqGenerator;
    
    public BasePagerBean list(BusiBean bean) {
        
        Map<String, Object> parameterMap = BusiUtil.getParameterMap(bean);
        
        List<BusiBean> dataList = selectList("_busi.list", parameterMap);
        int totalCount = (Integer)selectOne("_busi.listCount", parameterMap);
        
        return new BasePagerBean(dataList, totalCount, bean);
    }
    
    public List<Map<String, Object>> listExcel(BusiBean bean) {
        
        Map<String, Object> parameterMap = BusiUtil.getParameterMap(bean);
        
        BusiExcelRowHandler rowHandler = new BusiExcelRowHandler();
        
        if ( StringUtil.equals(bean.getXlsScope(), BusiBean.SCOPE_TOTAL) ) {
            getSqlSession().select("_busi.listExcel", parameterMap, rowHandler);
        }
        else {
            getSqlSession().select("_busi.list", parameterMap, rowHandler);
        }
        
        List<Map<String, Object>> dataList = rowHandler.getList();
        
        return dataList;
    }
    
    public BusiBean view(BusiBean bean) {
        
        return selectOne("_busi.view", bean);
    }
    
    public synchronized int insertAction(BusiBean bean) {
        
        bean.setBusiSeq(seqGenerator.getNextInteger());
        
        return insert("_busi.insert", bean);
    }
    
    public int updateAction(BusiBean bean) {
        
        return update("_busi.update", bean);
    }
    
    public int deleteAction(BusiBean bean) {
        
        if ( StringUtil.isNotEmpty(bean.getBusiSeqs()) ) {
            
            int affected = delete("_busi.delete", bean);
            if ( affected == Array.getLength(bean.getBusiSeqs()) ) {
                return ONE;
            }
        }
        return ZERO;
    }
    
    public List<BusiBean> listAll() {
        
        return selectList("_busi.listAll");
    }

}
