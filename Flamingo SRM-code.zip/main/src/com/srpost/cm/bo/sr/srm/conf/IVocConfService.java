package com.srpost.cm.bo.sr.srm.conf;

import java.util.List;
import java.util.Map;

import com.srpost.salmon.bean.BasePagerBean;

/**
 * 내부단 VOC설정 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
public interface IVocConfService {

    BasePagerBean list(VocConfBean bean);
    
    List<Map<String, Object>> listExcel(VocConfBean bean);
    
    VocConfBean view(VocConfBean bean);
    
    int insertAction(VocConfBean bean, String[] mgrDatas);
    
    int updateAction(VocConfBean bean, String[] mgrDatas);
    
    int deleteAction(VocConfBean bean);
    
    List<VocConfBean> listCache();
}
