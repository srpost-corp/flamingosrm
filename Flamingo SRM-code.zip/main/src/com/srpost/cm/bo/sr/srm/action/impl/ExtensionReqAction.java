package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.extdt.VocExtDtBean;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * EXTENSION_REQ : 기한연장 요청 - 분배자/처리자 (주무부서만 가능)
 *
 * @author  finkle
 * @date    2014-12-05
 * @since   3.0
 */
public class ExtensionReqAction extends OffInsertAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();
        String orgLmtDt = (String)parameterMap.get("orgLmtDt"); // YYYY-MM-DD HH:MM:SS
        orgLmtDt = DateTimeUtil.toDigitString(orgLmtDt);
        String extensionDt = (String)parameterMap.get("extensionDt"); // YYYY-MM-DD
        String reason = (String)parameterMap.get("reason");
        
        String newLmtDt = StringUtil.remove(extensionDt, DASH) + orgLmtDt.substring(8);

        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();

        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || 
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                !(StringUtil.equals(orgBean.getMgrStatusCd(), MS_DIVIDE) || StringUtil.equals(orgBean.getMgrStatusCd(), MS_ASSIGN)) ||
                orgBean.getExtReqCnt() > 0 ||
                StringUtil.equals(orgBean.getSancYn(), Y) ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * EXT_DT 요청정보 등록
         */
        delete("_vocAction.deleteVocExtDt", vocBean.getVocSeq());
        
        VocExtDtBean extDtBean = new VocExtDtBean();
        extDtBean.setVocSeq(vocBean.getVocSeq());
        extDtBean.setMgrId(loginBean.getMgrId());
        extDtBean.setExtDt(newLmtDt);
        extDtBean.setExtReason(reason);
        
        int affected = insert("_vocAction.insertVocExtDt", extDtBean);

        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 수정
             */
            
            // 접수자 ENTRY 활성화 수정
            update("_vocAction.updateEntryForce", new VocEntryBean(
                    vocBean.getVocSeq(), orgBean.getRcvId(), AUTH_RECEIVER, ACT_ACTIVE));
            
            /*-------------------------
             * DIV 수정
             */
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setOrderNo(ONE);
            divBean.setExtReqDt(newLmtDt);
            
            update("_vocAction.updateVocDivForExtensionReq", divBean);
            
            /*-------------------------
             * 로그 등록
             */
            String fromLmtDt = (String)parameterMap.get("orgLmtDt");
            String toLmtDt = (String)parameterMap.get("extensionDt") + fromLmtDt.substring(10);
            
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>기한연장 요청</strong> : ");
            logContents.append(fromLmtDt + " &rarr; <span class='emphasis'>" + toLmtDt + "</span>");
            logContents.append("<br/>기한연장 사유 : " + reason);
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 접수자
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            alimMap.addMgr((MgrBean)selectOne("_mgr.view", orgBean.getRcvId()));
            
            //사유
            alimMap.setReason(reason);
            
            executeAlim(alimMap);
        }
    }
}
