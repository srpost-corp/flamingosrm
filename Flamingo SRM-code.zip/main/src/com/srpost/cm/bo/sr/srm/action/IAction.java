package com.srpost.cm.bo.sr.srm.action;

import com.srpost.cm.bo.sr.srm.core.VocBean;

/**
 * Action 인터페이스
 *
 * @author  finkle
 * @date    2014-11-27
 * @since   3.0
 */
public interface IAction {

    String execute(VocBean bean) throws Exception;
}
