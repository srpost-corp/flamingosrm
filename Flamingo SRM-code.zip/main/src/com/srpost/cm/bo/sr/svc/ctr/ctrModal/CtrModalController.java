package com.srpost.cm.bo.sr.svc.ctr.ctrModal;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 계약 모달 컨트롤러
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Controller
@RequestMapping(value="/bo/sr/svc/ctr/ctrModal")
public class CtrModalController extends BaseController {
    
    /**
     * 계약 모달 목록 팝업창
     */
    @RequestMapping(value="p_*List.do", method=RequestMethod.GET)
    public void svcModalList() {
    }
    
    /**
     * 계약 모달 팝업창
     */
    @RequestMapping(value="p_view.do", method=RequestMethod.GET)
    public void svcModalView() {
    }

}
