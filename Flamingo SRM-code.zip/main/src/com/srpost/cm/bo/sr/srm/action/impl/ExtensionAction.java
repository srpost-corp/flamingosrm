package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.extdt.VocExtDtBean;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * EXTENSION : 기한연장 - 접수자
 *
 * @author  finkle
 * @date    2014-12-09
 * @since   3.0
 */
public class ExtensionAction extends OffInsertAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();
        String orgLmtDt = (String)parameterMap.get("orgLmtDt"); // YYYY-MM-DD HH:MM:SS
        orgLmtDt = DateTimeUtil.toDigitString(orgLmtDt);
        
        String extensionDt = (String)parameterMap.get("extensionDt"); // YYYY-MM-DD
        String reason = (String)parameterMap.get("reason");
        
        String newLmtDt = StringUtil.remove(extensionDt, DASH) + orgLmtDt.substring(8);

        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();

        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || 
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                (StringUtil.equals(MS_END, orgBean.getMgrStatusCd())) ) {
            throw new VocAlreadyExecuteException();
        }
                
        /*-------------------------
         * VOC 수정
         */
        vocBean.setLmtDt(newLmtDt);
        
        int affected = update("_vocAction.updateVocForExtension", vocBean);
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 수정
             */
            // 재분배 버튼이 비활성화일 때 행위자 ENTRY 비활성화
            boolean reDivideBtn = false;
            if ( StringUtil.equals(orgBean.getKindCd(), KND_COMPLEX) ) {
                boolean hasReDivideCount = VocUtil.hasReDivideCount(divList);
                if ( hasReDivideCount && StringUtil.equals(loginBean.getMgrId(), orgBean.getRcvId()) ) {
                    reDivideBtn = true;
                }
            }
            if ( !reDivideBtn ) {
                update("_vocAction.updateEntryForce", new VocEntryBean(
                    vocBean.getVocSeq(), loginBean.getMgrId(), AUTH_RECEIVER, ACT_WORKER));             
            }
            
            // 기한연장 요청정보 삭제 전 정보 설정 
            VocExtDtBean extDtBean = (VocExtDtBean)selectOne("_vocSupport.viewExtDt", vocBean.getVocSeq());
            
            // 기한연장 요청정보 삭제
            delete("_vocAction.deleteVocExtDt", vocBean.getVocSeq());
            
            /*-------------------------
             * DIV 수정
             */
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setOrderNo(ONE);
            
            update("_vocAction.updateVocDivForExtension", divBean); 
            
            /*-------------------------
             * 로그 등록
             */
            String fromLmtDt = (String)parameterMap.get("orgLmtDt");
            String toLmtDt = (String)parameterMap.get("extensionDt") + fromLmtDt.substring(10);
            
            StringBuilder logContents = new StringBuilder();
            if (extDtBean != null) {
                logContents.append("<strong>기한연장 승인</strong> : ");
                logContents.append("<span class='emphasis'>" + toLmtDt + "</span>");
                logContents.append("<br/>승인 사유 : " + reason);
            }
            else {
                logContents.append("<strong>직접 기한연장</strong> : ");
                logContents.append("<span class='emphasis'>" + toLmtDt + "</span>");
                logContents.append("<br/>연장 사유 : " + reason);
            }

            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 기한연장 요청자, 고객
             */            
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            if (extDtBean != null) {
                alimMap.addMgr((MgrBean)selectOne("_mgr.view", extDtBean.getMgrId()));
            }
            alimMap.setMgrBean((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getWriterId()));
            
            //사유
            alimMap.setReason(reason);
            
            executeAlim(alimMap);
        }
    }
}
