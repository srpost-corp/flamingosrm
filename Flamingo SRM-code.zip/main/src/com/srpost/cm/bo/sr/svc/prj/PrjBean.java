package com.srpost.cm.bo.sr.svc.prj;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseListBean;

/**
 * 프로젝트 정보 Bean
 *
 * @author  Bella
 * @date    2017-04-18
 * @since   3.0
 */
@Alias("prjBean")
@SuppressWarnings("serial")
public class PrjBean extends BaseListBean {
    
    /** 사업_일련번호 */
    private Integer prjSeq;
    /** 사업_명 */
    private String prjNm;
    /** 사업자_번호 */
    private String prjContents;
    /** 시작_일자 */
    private String startDd;
    /** 종료_일자 */
    private String endDd;
    /** 오픈_일자 */
    private String openDd;
    /** 사용_여부 */
    private String useYn;
    /** 등록일 */
    private String regDt;
    /** 수정일 */
    private String modiDt;
    
    /** 진행_일수 */
    private Integer ingCnt;
    
    /** 계약_일련번호 */
    private String ctrSeq;
    /** 정렬_순서 */
    private String orderNo;
    
    /** 프로젝트_일련번호_배열 */
    private Integer[] prjSeqs;
    
    public Integer getPrjSeq() {
        return prjSeq;
    }
    public void setPrjSeq(Integer prjSeq) {
        this.prjSeq = prjSeq;
    }
    public String getPrjNm() {
        return prjNm;
    }
    public void setPrjNm(String prjNm) {
        this.prjNm = prjNm;
    }
    public String getPrjContents() {
        return prjContents;
    }
    public void setPrjContents(String prjContents) {
        this.prjContents = prjContents;
    }
    public String getStartDd() {
        return startDd;
    }
    public void setStartDd(String startDd) {
        this.startDd = startDd;
    }
    public String getEndDd() {
        return endDd;
    }
    public void setEndDd(String endDd) {
        this.endDd = endDd;
    }
    public String getOpenDd() {
        return openDd;
    }
    public void setOpenDd(String openDd) {
        this.openDd = openDd;
    }
    public String getUseYn() {
        return useYn;
    }
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
    public String getModiDt() {
        return modiDt;
    }
    public void setModiDt(String modiDt) {
        this.modiDt = modiDt;
    }
    public Integer getIngCnt() {
        return ingCnt;
    }
    public void setIngCnt(Integer ingCnt) {
        this.ingCnt = ingCnt;
    }
    public String getCtrSeq() {
        return ctrSeq;
    }
    public void setCtrSeq(String ctrSeq) {
        this.ctrSeq = ctrSeq;
    }
    public String getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    public Integer[] getPrjSeqs() {
        return prjSeqs;
    }
    public void setPrjSeqs(Integer[] prjSeqs) {
        this.prjSeqs = prjSeqs;
    }
    
}
