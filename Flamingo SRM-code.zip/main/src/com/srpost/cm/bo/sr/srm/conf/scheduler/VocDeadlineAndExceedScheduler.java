package com.srpost.cm.bo.sr.srm.conf.scheduler;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.sr.srm.conf.VocConfBean;
import com.srpost.cm.bo.sr.srm.conf.VocReceiverBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.cm.bo.sr.srm.core.VocDao;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimHandler;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.scheduelr.BaseScheduler;

import static com.srpost.salmon.constant.StringPool.MINUS_ONE;
import static com.srpost.salmon.constant.StringPool.PIPE;
import static com.srpost.salmon.constant.StringPool.Y;

/**
 * 알림이 스케줄러 (이메일, SMS, MeerKat)
 * - 기한임박, 기한초과 알림정보 발송
 * 
 * @author  finkle
 * @date    2014-11-21
 * @since   2.0
 */
public class VocDeadlineAndExceedScheduler extends BaseScheduler {

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    @Resource
    VocAlimHandler vocAlimHandler;
	@Resource
	IVocDeadlineAndExceedDao daeDao;
    @Resource
    VocDao vocDao;


	public void doSchedule() {

        if ( isExcludeServer() ) return;

        VocAlimMap alimMap = new VocAlimMap();
        
	    List<Integer> deadlineVocList = new ArrayList<Integer>();
	    List<Integer> exceedVocList = new ArrayList<Integer>();
	    
	    List<VocConfBean> confList = VocUtil.getConfList();
	    for (VocConfBean item : confList) {
	        
	        int deadlineCnt = item.getDeadlineCnt();
	        if (StringUtil.equals(item.getDeadlineYn(), Y) && deadlineCnt > MINUS_ONE) {
	            // '0'이면 당일 처리대상 건에 대해 발송, '1'이면 1일전 자료에 대해 발송
	            deadlineVocList.add(item.getVocCd());
	        }
	        
	        int exceedCnt = item.getExceedCnt();
            if (StringUtil.equals(item.getExceedYn(), Y) && exceedCnt > MINUS_ONE) {
                // '0'이면 기한 초과 시 즉시 발송
                exceedVocList.add(item.getVocCd());
            }
	    }

	    Integer[] deadlineVocs = deadlineVocList.toArray(new Integer[deadlineVocList.size()]);
        Integer[] exceedVocs = exceedVocList.toArray(new Integer[exceedVocList.size()]);
        

	    if ( StringUtil.isNotEmpty(deadlineVocs) ) {
	        
	        List<VocBean> deadlineList = daeDao.deadlineList(deadlineVocs);
	        
	        if ( StringUtil.isNotEmpty(deadlineList) ) {
	            
	            logger.info("--------------------------------------------");
	            logger.info("기한임박 대상자 알림 발송 시작 : 대상 VOC {}건", deadlineList.size());

	            int alimSum = 0;
	            
    	        for (VocBean item : deadlineList) {
    	            
    	            alimMap.setActionCd(VocConstant.__ACTION_DEADLINE__);
                    alimMap.setVocBean(vocDao, item.getVocSeq());
                    
                    int mgrLength = addMgr(item, alimMap);
                    
                    vocAlimHandler.execute(alimMap);
                    
                    logger.info("VOC [{}] : {}명 발송 완료", item.getVocSeq(), mgrLength);
                    
                    alimSum += mgrLength;
    	        }
    	        
                logger.info("기한임박 대상자 알림 등록 종료 : 전체 발송  {}명", alimSum);
                logger.info("--------------------------------------------");
	        }
	    }
        

	    if ( StringUtil.isNotEmpty(exceedVocs) ) {
	        List<VocBean> exceedList = daeDao.exceedList(exceedVocs);
	        
	        if ( StringUtil.isNotEmpty(exceedList) ) {

                logger.info("--------------------------------------------");
                logger.info("기한초과 대상자 알림 발송 시작 : 대상 VOC {}건", exceedList.size());

                int alimSum = 0;
                
                for (VocBean item : exceedList) {
                    
                    alimMap.setActionCd(VocConstant.__ACTION_EXCEEDE__);
                    alimMap.setVocBean(vocDao, item.getVocSeq());
                    
                    int mgrLength = addMgr(item, alimMap);
                    
                    vocAlimHandler.execute(alimMap);
                    
                    logger.info("VOC [{}] : {}명 발송 완료", item.getVocSeq(), mgrLength);
                    
                    alimSum += mgrLength;
                }
                
                logger.info("기한초과 대상자 알림 등록 종료 : 전체 발송  {}명", alimSum);
                logger.info("--------------------------------------------");
	        }
	    }
	}
	
	
	private int addMgr(VocBean bean, VocAlimMap alimMap) {
	    
	    int addedMgrLength = 0;
	    
	    if (StringUtil.equals(bean.getMgrStatusCd(), MS_READY)) {
            
            VocConfBean confBean = VocUtil.getConfBean(bean.getVocCd());

            List<VocReceiverBean> receiverList = confBean.getReceiverList();
            
            for (VocReceiverBean receiverBean : receiverList) {
                alimMap.addMgr((MgrBean)selectOne("_mgr.view", receiverBean.getMgrId()));
                addedMgrLength++;
            }
        }
        else if (StringUtil.equals(bean.getMgrStatusCd(), MS_RECEIVE)) {
            
            alimMap.addMgr((MgrBean)selectOne("_mgr.view", bean.getRcvId()));
            addedMgrLength++;
        }
        else if (StringUtil.equals(bean.getMgrStatusCd(), MS_DIVIDE) ||
                StringUtil.equals(bean.getMgrStatusCd(), MS_ASSIGN)) 
        {
            String[] mgrIds = StringUtil.split(bean.getRegId(), PIPE);
            if (StringUtil.isNotEmpty(mgrIds)) {
                for (String mgrId : mgrIds) {
                    alimMap.addMgr((MgrBean)selectOne("_mgr.view", mgrId));
                    addedMgrLength++;
                }
            }
        }
        else if (StringUtil.equals(bean.getMgrStatusCd(), MS_SANC)) {
            
            alimMap.addMgr((MgrBean)selectOne("_mgr.view", bean.getReporterId()));
            addedMgrLength++;
        }
	    
	    return addedMgrLength;
	}
}
