package com.srpost.cm.bo.sr.srm.supporter;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.Calendar;

import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * VOC 처리소요기간 계산기
 *
 * @author  finkle
 * @date    2014-12-30
 * @since   3.0
 */
public class EncCntCalculator extends LmtDtCalculator {

    public EncCntCalculator() {
        super();
    }

    /**
     * 처리 소요시간 계산 (minutes)
     */
    public long calculateEndCnt(String divDt, String endDt) {        
        return calculateEndCnt(divDt, endDt, false);
    }
    public long calculateEndCnt(String divDt, String endDt, boolean isRound) {

        if (StringUtil.isEmpty(divDt) || StringUtil.isEmpty(endDt))
            return MINUS_ONE;
        
        divDt = DateTimeUtil.toDigitString(divDt);
        endDt = DateTimeUtil.toDigitString(endDt);
        
        if (divDt.length() != 14 || endDt.length() != 14)
            return MINUS_ONE;
        
        Calendar start = DateTimeUtil.toCalendar(divDt);
        Calendar end = DateTimeUtil.toCalendar(endDt);

        // 분배일자와 종료일자가 동일한 경우
        if (start.get(Calendar.YEAR) == end.get(Calendar.YEAR)
                && start.get(Calendar.MONTH) == end.get(Calendar.MONTH)
                && start.get(Calendar.DATE) == end.get(Calendar.DATE)
                && start.get(Calendar.HOUR_OF_DAY) == end.get(Calendar.HOUR_OF_DAY)
                && start.get(Calendar.MINUTE) == end.get(Calendar.MINUTE)) {
            return ZERO;
        }
        
        int holidayCnt = ZERO;
        
        Calendar tempStart = (Calendar)start.clone();
        
        // 공휴일 체크
        if (IS_HOLIDAY_FOR_END_CNT) {
            while (!tempStart.after(end)) {
                if (isHoliday(tempStart, false)) {
                    holidayCnt++;
                    
                    /**
                     * @TODO : ↓↓↓휴일을 잊은 열정적인 담당자들을 위해.. (필요할까나..?)↓↓↓
                     * 
                     * 분배일 또는 종료일이 휴일일 경우 처리소요시간 포함
                     */
                    /*
                    if (IS_HOLIDAY_PROC_FOR_END_CNT) {
                        if (tempStart.get(Calendar.YEAR) == start.get(Calendar.YEAR)
                                && tempStart.get(Calendar.MONTH) == start.get(Calendar.MONTH)
                                && tempStart.get(Calendar.DATE) == start.get(Calendar.DATE)) {
                            holidayCnt--;
                        }
                        else if (tempStart.get(Calendar.YEAR) == end.get(Calendar.YEAR)
                                    && tempStart.get(Calendar.MONTH) == end.get(Calendar.MONTH)
                                    && tempStart.get(Calendar.DATE) == end.get(Calendar.DATE)) {
                            holidayCnt--;
                        }
                    }
                    */
                }
                
                tempStart.add(Calendar.DATE, 1);
            }
        }
        
        double holidayMin = holidayCnt * MINUTES * HOURS;
        double elapsedMinutes = 
                (end.getTimeInMillis() - start.getTimeInMillis()) / (MILLISECONDS * SECONDS) - holidayMin;

        return (long)(isRound ? Math.round(elapsedMinutes) : elapsedMinutes);
    }
}
