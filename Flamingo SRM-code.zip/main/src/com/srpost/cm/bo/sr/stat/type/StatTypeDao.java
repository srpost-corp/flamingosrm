package com.srpost.cm.bo.sr.stat.type;

import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.lang.StringUtil;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 통계(유형별) DAO
 *
 * @author  finkle
 * @date    2014-12-29
 * @since   2.0
 */
@Repository
public class StatTypeDao extends EgovAbstractMapper {

    public Map<String, Map<String, Object>> statMap(StatTypeSearchBean bean) {
        
        Map<String, Object> parameterMap = StatTypeUtil.getParameterMap(bean);

        if ( StringUtil.equals(bean.getStatCd(), StatTypeUtil.STAT_SCORE) ) {
            return selectMap("_statType.statScoreMap", parameterMap, "LABEL");
        }
        else if ( StringUtil.equals(bean.getStatCd(), StatTypeUtil.STAT_DEAL_AVG) ) {
            return selectMap("_statType.statDealAvgMap", parameterMap, "LABEL");
        }
        else {
            return selectMap("_statType.statCodeMap", parameterMap, "LABEL");
        }
    }
}
