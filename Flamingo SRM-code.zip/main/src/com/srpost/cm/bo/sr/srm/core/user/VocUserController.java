package com.srpost.cm.bo.sr.srm.core.user;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.srpost.cm.bo.base.mgr.IMgrService;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 내부단 VOC 고객정보 컨트롤러
 *
 * @author  finkle
 * @date    2015-09-03
 * @since   3.0
 */
@Controller
@RequestMapping(value="/bo/sr/srm/core/user")
public class VocUserController extends BaseController {

    @Resource
    IMgrService mgrService;
    @Resource
    IVocUserService service;
    
    /**
     * 신청인 상세정보 및 VOC 목록
     */
    @RequestMapping(value="a_view.do", method=RequestMethod.GET)
    public void view(MgrBean bean, HttpServletRequest request, ModelMap model) {

        model.addAttribute("dataBean", mgrService.view(bean));
        model.addAttribute("pagerBean", service.list(bean));
    }
    
    /**
     * 신청 VOC 목록
     */
    @RequestMapping(value="a_list.do", method=RequestMethod.POST)
    public void list(MgrBean bean, ModelMap model) {
        
        model.addAttribute("dataBean", mgrService.view(bean));
        model.addAttribute("pagerBean", service.list(bean));
    }
}
