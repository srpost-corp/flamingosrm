package com.srpost.cm.bo.sr.srm.core.log;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 로그 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-01
 * @since   2.0
 */
@Service
public class VocLogServiceImpl extends EgovAbstractServiceImpl implements IVocLogService {

    @Resource
    VocLogDao dao;

    @Override
    public List<VocLogBean> list(VocLogBean bean) {
        
        return dao.list(bean);
    }
    
    @Override
    public int insertAction(VocLogBean bean) {
        
        return dao.insertAction(bean);
    }
    
    @Override
    public String viewUpdateReplyLog(Integer vocSeq, Integer orderNo) {
        
        return dao.viewUpdateReplyLog(vocSeq, orderNo);
    }

    @Override
    public int insertUpdateReplyLog(VocUpdateReplyLogBean bean) {
        
        return dao.insertUpdateReplyLog(bean);
    }
}
