package com.srpost.cm.bo.sr.srm.core;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.sr.srm.action.ActionFactory;
import com.srpost.cm.bo.sr.srm.action.IAction;
import com.srpost.salmon.bean.BasePagerBean;
import com.srpost.salmon.constant.Message;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 서비스 구현체
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
@Service
public class VocServiceImpl extends EgovAbstractServiceImpl implements IVocService {

    @Resource
    VocDao dao;
    @Resource
    ActionFactory factory;

    @Override
    public BasePagerBean list(VocListBean bean) {
        
        return dao.list(bean);
    }
    
    @Override
    public List<Map<String, Object>> listExcel(VocListBean bean) {
        
        return dao.listExcel(bean);
    }

    @Override
    public VocBean view(VocBean bean, boolean needUpdateReadCnt) {
        
        return dao.view(bean, needUpdateReadCnt);
    }
    
    @Override
    public VocBean viewSimple(Integer vocSeq) {
        
        return dao.viewSimple(vocSeq);
    }

    @Override
    public String executeAction(VocBean bean) throws Exception {
        
        IAction action = factory.get(bean.getAction());
        if (action == null) {
            return Message.fail("voc.action.notfound.fail", new String[]{ bean.getAction() });
        }
        
        return action.execute(bean);
    }
    
    @Override
    public Map<String, Integer> countMyEntryMap(VocEntryBean bean) {
        
        return dao.countMyEntryMap(bean);
    }
}
