package com.srpost.cm.bo.sr.srm.core.comment;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 외부의견글 서비스 구현체
 *
 * @author  finkle
 * @date    2015-01-23
 * @since   2.0
 */
@Service
public class VocCmtServiceImpl extends EgovAbstractServiceImpl implements IVocCmtService {

    @Resource
    VocCmtDao dao;

    @Override
    public List<VocCmtBean> list(VocCmtBean bean) {

        return dao.list(bean);
    }

    @Override
    public VocCmtBean view(VocCmtBean bean) {

        return dao.view(bean);
    }

    @Override
    public int insertAction(VocCmtBean bean) {

        return dao.insertAction(bean);
    }

    @Override
    public int updateAction(VocCmtBean bean) {

        return dao.updateAction(bean);
    }

    @Override
    public int replyAction(VocCmtBean bean) {

        return dao.replyAction(bean);
    }

    @Override
    public int deleteAction(VocCmtBean bean) {

        return dao.deleteAction(bean);
    }

    
}
