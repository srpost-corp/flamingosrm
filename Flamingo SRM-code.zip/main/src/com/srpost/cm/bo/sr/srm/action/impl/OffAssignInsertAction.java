package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.conf.VocConfBean;
import com.srpost.cm.bo.sr.srm.conf.VocReceiverBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.cm.bo.sr.srm.supporter.LmtDtCalculator;
import com.srpost.salmon.lang.DateTimeUtil;

import static com.srpost.salmon.constant.StringPool.EMPTY;
import static com.srpost.salmon.constant.StringPool.ONE;
import static com.srpost.salmon.constant.StringPool.Y;

import jodd.util.StringUtil;

/**
 * OFF_ASSIGN_INSERT : 오프라인 등록 (처리자 지정) - 접수자만 가능
 *
 * @author  finkle
 * @date    2014-12-04
 * @since   3.0
 */
public class OffAssignInsertAction extends OffInsertAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();
        String assignId = (String)parameterMap.get("assignId");
        String assignNm = (String)parameterMap.get("assignNm");
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        String today = (String)transientVars.get("today");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        LmtDtCalculator lmtDtCalculator = new LmtDtCalculator(vocBean);

        /*-------------------------
         * VOC 등록
         */
        VocConfBean confBean = VocUtil.getConfBean(vocBean.getVocCd());

        VocUtil.setNotNullValue(vocBean);
        
        vocBean.setVocSeq(vocSeqGenerator.getNextInteger());
        vocBean.setWriterId(loginBean.getMgrId());
        vocBean.setRegId(loginBean.getMgrId());
        vocBean.setUserFileSeq(fileDao.insertAction(vocBean.getUserFileList()));
        //vocBean.setMgrFileSeq(fileDao.insertAction(vocBean.getMgrFileList()));
        vocBean.setUserStatusCd(US_DEALING);
        vocBean.setMgrStatusCd(MS_ASSIGN);
        vocBean.setKindCd(KND_NORMAL);
        if (!StringUtil.equals(vocBean.getTypeCd(), TYPE_CMPLN_CD)) {
            vocBean.setCmplnCd(EMPTY);
        }
        
        vocBean.setRcvNo(rcvNoGenerator.create(vocBean.getVocSeq()));
        
        VocReceiverBean mReceiverBean = confBean.getMasterReceiver();
        vocBean.setRcvId(mReceiverBean != null ? mReceiverBean.getMgrId() : EMPTY);
        
        vocBean.setRegDt(today);
        vocBean.setRcvDt(today);
        vocBean.setDivDt(today);
        vocBean.setAsnDt(today);
        vocBean.setLmtDt(lmtDtCalculator.getLmtDt());

        int affected = insert("_voc.insert", vocBean);
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 등록
             */

            // 접수자 ENTRY 비활성화 등록
            List<VocReceiverBean> receiverList = confBean.getReceiverList();
            for (VocReceiverBean receiverBean : receiverList) {
                
                if (StringUtil.equals(receiverBean.getMgrId(), loginBean.getMgrId())) {
                    insert("_vocAction.insertEntry", new VocEntryBean(
                        vocBean.getVocSeq(), receiverBean.getMgrId(), AUTH_RECEIVER, ACT_WORKER));
                    
                    // 등록자가 접수자일 경우 접수자 정보 수정
                    vocBean.setRcvId(loginBean.getMgrId());
                    update("_vocAction.updateRcvIdForOffInsert", vocBean);
                }
                else {
                    insert("_vocAction.insertEntry", new VocEntryBean(
                        vocBean.getVocSeq(), receiverBean.getMgrId(), AUTH_RECEIVER, ACT_INACTIVE));
                }
            }
            
            // 분배자 ENTRY 비활성화 등록
            MgrBean paramMgrBean = new MgrBean();
            paramMgrBean.setConnId(assignId);
            paramMgrBean.setAuthCd(AUTH_DIVIDER);
            
            List<MgrBean> dividerList = selectList("_vocSupport.listMgr", paramMgrBean);
            
            int index = ONE;
            
            for (MgrBean dividerBean : dividerList) {
                // 첫번째 분배자 ENTRY 연관화 등록
                // 등록 시 처리자 지정이므로 반송에 대비해 최소 분배자 1명은 연관화 해야함
                if (index == ONE)
                    insert("_vocAction.insertEntry", new VocEntryBean(
                        vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_WORKER));
                // 잔여 분배자 ENTRY 비활성화 등록
                else
                    insert("_vocAction.insertEntry", new VocEntryBean(
                        vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_INACTIVE));
                index++;
            }
            
            // 처리자 ENTRY 활성화 등록
            insert("_vocAction.insertEntry", new VocEntryBean(
                vocBean.getVocSeq(), assignId, AUTH_DEALER, ACT_ACTIVE));
            
            /*-------------------------
             * DIV 등록
             */
            transientVars.put("mgrStatusCd", MS_ASSIGN);
            
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setWfId(createtWorkflow(transientVars));
            divBean.setMasterYn(Y);
            divBean.setDeptCd((String)selectOne("_vocSupport.viewDeptCdByMgrId", assignId));
            divBean.setDivDt(today);
            divBean.setAsnDt(today);
            divBean.setMgrId(assignId);
            divBean.setMgrStatusCd(vocBean.getMgrStatusCd());
            divBean.setEndCnt(-1L);
            
            insert("_vocAction.insertDiv", divBean);
            
            /*-------------------------
             * 태그 등록
             */
            vocTagsDao.insertAction(vocBean.getVocSeq(), 
                    StringUtil.split(vocBean.getTags(), ","));
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>오프라인 등록</strong> : 일반 VOC");
            logContents.append("<br/>처리자 : " + assignNm + "");
            logContents.append("<br/>처리기한 : <span title='" + lmtDtCalculator.getLmtDtLog() + "'>");
            logContents.append(DateTimeUtil.toDateFull(vocBean.getLmtDt()) + "</span>");
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());

            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 지정 처리자, 고객
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            alimMap.addMgr((MgrBean)selectOne("_mgr.view", assignId));
            alimMap.setMgrBean((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getWriterId()));
            
            executeAlim(alimMap);
        }
    }
}
