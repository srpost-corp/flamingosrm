package com.srpost.cm.bo.sr.srm.action.condition.step;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.opensymphony.module.propertyset.PropertySet;
import com.opensymphony.workflow.Condition;

/**
 * 처리 : 완료 또는 결재자 스텝 이동 여부 판단 Condition
 *
 * @author  finkle
 * @date    2014-12-09
 * @since   3.0
 */
@SuppressWarnings("rawtypes")
@Component(value="STEP_dealCondition")
public class DealCondition implements Condition {

    public boolean passesCondition(Map transientVars, Map args, PropertySet ps) {
        
        return (Boolean)transientVars.get("isSanction");
    }
}
