package com.srpost.cm.bo.sr.srm.tag.ui;

import static com.srpost.salmon.constant.StringPool.*;

import java.io.IOException;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

public class LmtDtTag extends SimpleTagSupport {

	private String lmtDt;

	public void doTag() throws JspException, IOException {
		
		JspWriter writer = getJspContext().getOut();
		
		if (StringUtil.isEmpty(lmtDt)) {
			writer.write("<span class=\"gray\">해당없음</span>"); return;
		}

        lmtDt = DateTimeUtil.toDigitString(lmtDt);
		
		if (lmtDt.length() != 14) {
			writer.write("<div class=\"gray\">" + lmtDt + "</div>"); return;
		}
		
		String html = "";

        Date now = new Date();
		Date target = DateTimeUtil.toCalendar(lmtDt).getTime();
		
		String cssClass = "";
		boolean isExceed = now.getTime() > target.getTime();
		
        long diff = Math.abs(now.getTime() - target.getTime());
        
        if ( diff / ONE_YEAR > ZERO ) {
        	html = diff / ONE_YEAR + "년";
        }
        else if ( diff / ONE_MONTH > ZERO ) {
        	html = diff / ONE_MONTH + "월";
        }
        else if ( diff / ONE_WEEK > ZERO ) {
        	html = diff / ONE_WEEK + "주";
        }
        else if ( diff / ONE_DAY > ZERO ) {
        	long diffDay = diff / ONE_DAY;
        	if (diffDay == 1) cssClass = "lmtDt-1day";
        	else if (diffDay == 2) cssClass = "lmtDt-2day";
        	else if (diffDay == 3) cssClass = "lmtDt-3day";
        	
        	html = diffDay + "일";
        	
            long diffHour = (diff / ONE_HOUR) - (diffDay * (long)HOURS);
            if (diffHour > ZERO) html += " " + diffHour + "시간";
        }
        else if ( diff / ONE_HOUR > ZERO ) {
        	cssClass = "lmtDt-hour";
        	
        	long diffHour = diff / ONE_HOUR;
        	html = diffHour + "시간";
            
            long diffMinute = (diff / ONE_MINUTE) - (diffHour * (long)MINUTES);
            if (diffMinute > ZERO) html += " " + diffMinute + "분";
        }
        else if ( diff / ONE_MINUTE > ZERO ) {
        	cssClass = "lmtDt-minute";
        	html = diff / ONE_MINUTE + "분";
        }
        /*--
        else if ( diff / ONE_SECOND > ZERO ) {
        	cssClass = "emergency-0";
        	html = diff / ONE_SECOND + "초";
        } --*/
        else {
        	html = "N/A";
        }
        
        if (isExceed) cssClass = "exceed";
        	
        html += isExceed ? " 지남" : " 남음";
        
        html = "<span class=\"" + cssClass + "\" title=\"" +
                DateTimeUtil.toDateFull(lmtDt) + "\">" + html + "</span>";

        writer.write(html);
	}
	

	public String getLmtDt() {
    	return lmtDt;
    }
	public void setLmtDt(String lmtDt) {
    	this.lmtDt = lmtDt;
    }
}
