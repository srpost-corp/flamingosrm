package com.srpost.cm.bo.sr.srm.action.condition.step;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.opensymphony.module.propertyset.PropertySet;
import com.opensymphony.workflow.Condition;

/**
 * 반송 : 접수자 또는 분배자 스텝 이동 여부 판단 Condition
 *
 * @author  finkle
 * @date    2014-12-05
 * @since   3.0
 */
@SuppressWarnings("rawtypes")
@Component(value="STEP_sendBackCondition")
public class SendBackCondition implements Condition {

    public boolean passesCondition(Map transientVars, Map args, PropertySet ps) {
        
        return (Boolean)transientVars.get("toReceiver");
    }
}
