package com.srpost.cm.bo.sr.srm.core.score;

import java.util.List;

import com.srpost.cm.bo.sr.srm.core.VocBean;

public interface IVocScoreService {
    
    List<VocScoreBean> list(VocBean vocBean);
}
