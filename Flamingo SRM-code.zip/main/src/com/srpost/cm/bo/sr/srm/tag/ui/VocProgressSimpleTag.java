package com.srpost.cm.bo.sr.srm.tag.ui;

import java.io.IOException;
import java.text.MessageFormat;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocConstant;

import jodd.util.ArraysUtil;

/**
 * VOC 진행현황 UI taglib
 *
 * @author  finkle
 * @date    2014-12-02
 * @since   2.0
 */
public class VocProgressSimpleTag extends SimpleTagSupport {

    private final String[] ARR_NO_RECEIVE = { VocConstant.MS_READY };
    private final String[] ARR_RECEIVE = { VocConstant.MS_RECEIVE, /* VocConstant.MSC_REDIVIDE, VocConstant.MSC_RECALL */ };
    private final String[] ARR_DIVIDE = { VocConstant.MS_DIVIDE, /* VocConstant.MSC_REASSIGN */ };
    private final String[] ARR_ASSIGN = { VocConstant.MS_ASSIGN };
    private final String[] ARR_SANC = { VocConstant.MS_SANC, /* VocConstant.MSC_SANC_DENY */ };
    private final String[] ARR_END = { VocConstant.MS_END };
    
    private final String PROGRESS_HTML = 
            "<div class=\"voc-progress-box\">\n" +
            "<table>\n" +
            "<tr>\n" +
            "    <td class=\"{0}\">미접수</td>\n" +
            "    <td class=\"divider\"></td>\n" +
            "    <td class=\"{1}\">접수</td>\n" +
            "    <td class=\"divider\"></td>\n" +
            "    <td class=\"{2}\">분배</td>\n" +
            "    <td class=\"divider\"></td>\n" +
            "    <td class=\"{3}\">처리자 지정</td>\n" +
            "    <td class=\"divider\"></td>\n" +
            "    <td class=\"{4}\">결재</td>\n" +
            "    <td class=\"divider\"></td>\n" +
            "    <td class=\"{5}\">처리완료</td>\n" +
            "</tr>\n" +
            "</table>\n" +
            "</div>\n";

    private VocBean vocBean;
    
    public void doTag() throws JspException, IOException {

        JspWriter writer = getJspContext().getOut();

        writer.write(createHtml());
    }
    
    private String createHtml() {
        
        String mgrStatusCd = vocBean.getMgrStatusCd();
        
        String[] images = null;

        if (ArraysUtil.contains(ARR_NO_RECEIVE, mgrStatusCd)) {
            images = new String[] {
                "yellow", "gray", "gray", "gray", "gray", "gray"
            };
        }
        else if (ArraysUtil.contains(ARR_RECEIVE, mgrStatusCd)) {
            images = new String[] { 
                "blue", "yellow", "gray", "gray", "gray", "gray"
            };
        }
        else if (ArraysUtil.contains(ARR_DIVIDE, mgrStatusCd)) {
            images = new String[] { 
                "blue", "blue", "yellow", "gray", "gray", "gray"
            };
        }
        else if (ArraysUtil.contains(ARR_ASSIGN, mgrStatusCd)) {
            images = new String[] { 
                "blue", "blue", "blue", "yellow", "gray", "gray"
            };
        }
        else if (ArraysUtil.contains(ARR_SANC, mgrStatusCd)) {
            images = new String[] { 
                "blue", "blue", "blue", "blue", "yellow", "gray"                    
            };
        }
        else if (ArraysUtil.contains(ARR_END, mgrStatusCd)) {
            images = new String[] { 
                "blue", "blue", "blue", "blue", "blue", "yellow"
            };
        }
        else {
            images = new String[] { 
                "gray", "gray", "gray", "gray", "gray", "gray"
            };
        }
        
        return new MessageFormat(PROGRESS_HTML).format(images);
    }
    
    
    public void setVocBean(VocBean vocBean) {
        this.vocBean = vocBean;
    }
}
