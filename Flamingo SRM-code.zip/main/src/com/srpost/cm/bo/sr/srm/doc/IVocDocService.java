package com.srpost.cm.bo.sr.srm.doc;

import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.salmon.bean.BasePagerBean;

/**
 * 내부단 VOC 처리대장 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-12-19
 * @since   2.0
 */
public interface IVocDocService {

    BasePagerBean list(VocListBean bean);
}
