package com.srpost.cm.bo.sr.search;

import static com.srpost.salmon.spi.fts.SearchEngineConstant.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.srpost.salmon.constant.Constant;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.fts.SearchEngineDB;
import com.srpost.salmon.spi.fts.bean.SearchBaseBean;
import com.srpost.salmon.web.mvc.controller.BaseController;

import iBoxDB.LocalServer.DB;
import iBoxDB.fulltext.KeyWordE;
import iBoxDB.fulltext.KeyWordN;

/**
 * 검색 컨트롤러
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/search")
public class SearchController extends BaseController {

    @Resource
    SearchEngineDB searchEngineDB;
    
    @Resource
    ISearchService service;
    
    private final int SHORT_SIZE = 6;
    
    /**
     * 검색 결과 메인
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index(@RequestParam(value="k",required=false) String keyword, ModelMap model) {
        
        // 자주 찾는 검색어 등록
        if (StringUtil.isNotEmpty(keyword)) {
            service.insertAction(keyword);
        }
        
        model.addAttribute("favoliteList", service.favoliteList());
    }

    /**
     * 검색 결과 목록
     */
    @RequestMapping(value="a_list.do", method=RequestMethod.GET)
    public void view(@RequestParam(value="k",required=false) String keyword, 
            @RequestParam(value="t",required=false) String table, 
            @RequestParam(value="p",required=false, defaultValue="0") long startNum, 
            HttpServletRequest request, ModelMap model) {

        if (StringUtil.isEmpty(keyword))
            return;
        
        if (StringUtil.length(keyword) < 2)
            return;
        
        if (startNum <= 0)
            startNum = Long.MAX_VALUE;
        
        if (StringUtil.isEmpty(table)) {
            
            model.addAttribute("vocList", searchEngineDB.search(VOC, keyword, startNum, SHORT_SIZE));
            model.addAttribute("faqList", searchEngineDB.search(FAQ, keyword, startNum, SHORT_SIZE));
            model.addAttribute("bbsList", searchEngineDB.search(BBS, keyword, startNum, SHORT_SIZE));
        }
        else {
            model.addAttribute("dataList", searchEngineDB.search(table, keyword, startNum, Constant.RPP_CNT));
        }
    }
    
    /**
     * 인덱싱 현황 메인
     */
    @RequestMapping(value="manage/index.do", method=RequestMethod.GET)
    public void mngIndex(ModelMap model) {
        
        List<SearchDatabaseBean> dataList = new ArrayList<SearchDatabaseBean>();
        
        int tableSize = TABLES.length;
        for (int i=0 ; i < tableSize ; i++) {
            String table = TABLES[i];
            DB.AutoBox autoBox = searchEngineDB.getAutoBoxMap().get(table);
            
            String[] subTables = {table, "/E", "/N"};
            int subTableSize = subTables.length;
            
            List<Map<String, Object>> tableList = new ArrayList<Map<String,Object>>(subTableSize);
            for (int j=0 ; j < subTableSize ; j++) {
                Map<String, Object> subMap = new HashMap<String, Object>();
                subMap.put("table", table);
                subMap.put("subTable", subTables[j]);
                subMap.put("count", autoBox.cube().selectCount("from " + subTables[j]));
                
                tableList.add(subMap);
            }

            List<Map<String, Object>> schemaList = new ArrayList<Map<String,Object>>(subTableSize);
            Map<String, Object> schemaMap = autoBox.getDatabase().getSchemata();
            for (Map.Entry<String, Object> entry : schemaMap.entrySet()) {

                Map<String, Object> subMap = new HashMap<String, Object>();
                subMap.put("key", entry.getKey());
                subMap.put("value", entry.getValue());
                
                schemaList.add(subMap);
            }
            
            SearchDatabaseBean sdBean = new SearchDatabaseBean();
            sdBean.setDbName(table);
            sdBean.setAddress(autoBox.getDatabase().localAddress());
            sdBean.setTableList(tableList);
            sdBean.setSchemaList(schemaList);
            
            dataList.add(sdBean);
        }
        
        model.addAttribute("dataList", dataList);
    }
    
    /**
     * 인덱싱 현황 목록
     */
    @RequestMapping(value="manage/a_list.do", method=RequestMethod.POST)
    public void mngView(
            @RequestParam(value="d",required=false,defaultValue="VOC") String db,
            @RequestParam(value="t",required=false,defaultValue="VOC") String table,
            HttpServletRequest request, ModelMap model) {

        List<Object> dataList = new ArrayList<Object>();
        
        DB.AutoBox autoBox = searchEngineDB.getAutoBoxMap().get(db);
        
        if (StringUtil.equals(table, "/E")) {
            for (KeyWordE item : autoBox.select(KeyWordE.class, "from /E limit 0, 50")) {
                dataList.add(item);
            }
        }
        else if (StringUtil.equals(table, "/N")) {
            for (KeyWordN item : autoBox.select(KeyWordN.class, "from /N limit 0, 50")) {
                dataList.add(item);
            }
        }
        else {
            for (SearchBaseBean item : autoBox.select(SearchBaseBean.class, "from " + table + " limit 0, 50")) {
                dataList.add(item);
            }
        }
        
        model.addAttribute("dataList", dataList);
    }
}
