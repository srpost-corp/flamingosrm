package com.srpost.cm.bo.sr.srm.core.modal;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.base.dept.DeptBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 모달창 서비스 구현체
 *
 * @author  finkle
 * @date    2014-11-26
 * @since   3.0
 */
@Service
public class VocModalServiceImpl extends EgovAbstractServiceImpl implements IVocModalService {

    @Resource
    VocModalDao dao;

    @Override
    public List<DeptBean> listDept(String highDeptCd, Integer authCd,
            String deptCds) {
        
        return dao.listDept(highDeptCd, authCd, deptCds);
    }
    
    @Override
    public List<DeptBean> listDeptCheck(String highDeptCd, Integer authCd,
            String masterDeptCd, String supportDeptCds) {
        
        return dao.listDeptCheck(highDeptCd, authCd, masterDeptCd, supportDeptCds);
    }
    
    @Override
    public String listDeptAllJSON(Integer authCd) {
        
        return dao.listDeptAllJSON(authCd);
    }
    
    @Override
    public List<MgrBean> listDealer(MgrBean bean) {
        
        return dao.listDealer(bean);
    }
    
    @Override
    public List<VocDivBean> listDiv(Map<String, Object> parameterMap) {
        
        return dao.listDiv(parameterMap);
    }
    
    @Override
    public List<VocSancBean> listSanc(Map<String, Object> parameterMap) {
        
        return dao.listSanc(parameterMap);
    }
    
    @Override
    public List<String> listMySancStore(String mgrId) {
        
        return dao.listMySancStore(mgrId);
    }
    
    @Override
    public int deleteSancLineAction(String mgrId, String sancLine) {
        
        return dao.deleteSancLineAction(mgrId, sancLine);
    }
    
    @Override
    public VocLogBean viewExtReqLog(Integer vocSeq) {
        
        return dao.viewExtReqLog(vocSeq);
    }
}
