package com.srpost.cm.bo.sr.stat.d3;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseListBean;

/**
 * 내부단 VOC 통계(D3) 파라메타 Bean
 *
 * @author  finkle
 * @date    2016-07-20
 * @since   2.0
 */
@Alias("d3StatParameterBean")
@SuppressWarnings("serial")
public class D3StatParameterBean extends BaseListBean {

    private Integer vocCd;
    
    private String year;
    private String hour;
    private String quarter;
    private String dow;
    
    private String kindCd;
    private String fromCd;
    private String typeCd;
    private String endCd;
    
    
    public String getYear() {
        return year;
    }
    public String getHour() {
        return hour;
    }
    public String getQuarter() {
        return quarter;
    }
    public String getDow() {
        return dow;
    }
    public String getKindCd() {
        return kindCd;
    }
    public String getFromCd() {
        return fromCd;
    }
    public String getTypeCd() {
        return typeCd;
    }
    public String getEndCd() {
        return endCd;
    }
    public void setYear(String year) {
        this.year = year;
    }
    public void setHour(String hour) {
        this.hour = hour;
    }
    public void setQuarter(String quarter) {
        this.quarter = quarter;
    }
    public void setDow(String dow) {
        this.dow = dow;
    }
    public void setKindCd(String kindCd) {
        this.kindCd = kindCd;
    }
    public void setFromCd(String fromCd) {
        this.fromCd = fromCd;
    }
    public void setTypeCd(String typeCd) {
        this.typeCd = typeCd;
    }
    public void setEndCd(String endCd) {
        this.endCd = endCd;
    }
    public Integer getVocCd() {
        return vocCd;
    }
    public void setVocCd(Integer vocCd) {
        this.vocCd = vocCd;
    }
}