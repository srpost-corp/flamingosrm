package com.srpost.cm.bo.sr.srm.core.trash;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.lang.WebUtil;

/**
 * 내부단 VOC 휴지통 Util
 *
 * @author  finkle
 * @date    2014-12-15
 * @since   3.0
 */
public class VocTrashUtil {

    public static Map<String, Object> getParameterMap(VocListBean bean) {
        
        Map<String, Object> parameterMap = bean.createPagerMap();
        
        VocUtil.setCommonParameterMap(bean, parameterMap);

        if ( StringUtil.isNotEmpty(bean.getDelCd()) )
            parameterMap.put("delCd", bean.getDelCd());
        
        parameterMap.put("delYn", Y);
        
        LoginBean loginBean = MgrUtil.getSession(WebUtil.getCurrentRequest());
        parameterMap.put("scrapId", loginBean.getMgrId());
 
        return parameterMap;
    }
}
