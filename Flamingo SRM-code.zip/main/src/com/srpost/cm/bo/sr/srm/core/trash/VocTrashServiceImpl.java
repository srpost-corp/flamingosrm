package com.srpost.cm.bo.sr.srm.core.trash;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.sr.srm.core.IVocService;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 휴지통 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-12
 * @since   2.0
 */
@Service
public class VocTrashServiceImpl extends EgovAbstractServiceImpl implements IVocTrashService {

    @Resource
    VocTrashDao dao;
    @Resource
    IVocService vocService;
    
    @Override
    public BasePagerBean list(VocListBean bean) {
        
        return dao.list(bean);
    }
    
    @Override
    public List<Map<String, Object>> listExcel(VocListBean bean) {
        
        return dao.listExcel(bean);
    }

    @Override
    public VocTrashBean view(VocTrashBean bean) {
        
        return dao.view(bean);
    }
    
    @Override
    public String restoreAction(VocBean bean) throws Exception {
        
        bean.setAction(VocConstant.ACTION_RESTORE);
        
        return vocService.executeAction(bean);
    }
    
    @Override
    public String deleteAction(VocBean bean) throws Exception {
        
        bean.setAction(VocConstant.ACTION_FORCE_DELETE);
        
        return vocService.executeAction(bean);
    }
}
