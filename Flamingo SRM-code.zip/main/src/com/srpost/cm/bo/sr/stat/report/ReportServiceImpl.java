package com.srpost.cm.bo.sr.stat.report;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.salmon.bean.BaseListBean;
import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 리포트 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-18
 * @since   3.0
 */
@Service
public class ReportServiceImpl extends EgovAbstractServiceImpl implements IReportService{

    @Resource
    ReportDao dao;

    @Override
    public List<ReportResultBean> allCtgList() {

        return dao.allCtgList();
    }
    
    @Override
    public BasePagerBean allTagList(BaseListBean bean) {

        return dao.allTagList(bean);
    }

}
