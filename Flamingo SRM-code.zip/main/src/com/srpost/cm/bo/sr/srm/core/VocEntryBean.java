package com.srpost.cm.bo.sr.srm.core;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 내부단 VOC ENTRY 정보 Bean
 *
 * @author  finkle
 * @date    2014-11-27
 * @since   3.0
 */
@Alias("vocEntryBean")
@SuppressWarnings("serial")
public class VocEntryBean extends BaseBean {

    /** VOC_일련번호 */
    private Integer vocSeq;
    /** 부서_코드 */
    private String deptCd;
    /** 직원_ID */
    private String mgrId;
    /** 권한_코드 */
    private Integer authCd;
    /** 활성값 */
    private String activate;
    
    public VocEntryBean() {
    }
    public VocEntryBean(Integer vocSeq, String mgrId, String activate) {
        this(vocSeq, mgrId, null, activate);
    }
    public VocEntryBean(Integer vocSeq, String mgrId, Integer authCd, String activate) {
        this.vocSeq = vocSeq;
        this.mgrId = mgrId;
        this.authCd = authCd;
        this.activate = activate;
    }
    
    public Integer getVocSeq() {
        return vocSeq;
    }
    public void setVocSeq(Integer vocSeq) {
        this.vocSeq = vocSeq;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getActivate() {
        return activate;
    }
    public void setActivate(String activate) {
        this.activate = activate;
    }
    public String getDeptCd() {
        return deptCd;
    }
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }
    public Integer getAuthCd() {
        return authCd;
    }
    public void setAuthCd(Integer authCd) {
        this.authCd = authCd;
    }
}
