package com.srpost.cm.bo.sr.srm.core.score;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.srm.core.VocBean;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository
public class VocScoreDao extends EgovAbstractMapper {

    
    public List<VocScoreBean> list(VocBean vocBean) {
        
        List<VocScoreBean> list = selectList("_vocScore.list", vocBean);
        
        return list;
    }
}
