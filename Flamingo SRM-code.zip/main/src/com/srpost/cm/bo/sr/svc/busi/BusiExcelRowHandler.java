package com.srpost.cm.bo.sr.svc.busi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

/**
 * 사업자 엑셀변환 row handler
 *
 * @author  Bella
 * @date    2017-04-18
 * @since   3.0
 */
public class BusiExcelRowHandler implements ResultHandler {
    
    private List<Map<String, Object>> list;
    
    public BusiExcelRowHandler() {
        
        list = new ArrayList<Map<String,Object>>();
    }
    
    @Override
    public void handleResult(ResultContext context) {
        
        BusiBean dataBean = (BusiBean)context.getResultObject();
        
        Map<String, Object> dataMap = new HashMap<String, Object>();
        
        dataMap.put("busiSeq", dataBean.getBusiSeq());
        dataMap.put("busiNm", dataBean.getBusiNm());
        dataMap.put("busiNo", dataBean.getBusiNo());
        dataMap.put("chiefNm", dataBean.getChiefNm());
        dataMap.put("telNum", dataBean.getTelNum());
        dataMap.put("regDt", dataBean.getRegDt());
        dataMap.put("modiDt", dataBean.getModiDt());
        
        list.add(dataMap);
    }
    
    public List<Map<String, Object>> getList() {
        
        return list;
    }

}
