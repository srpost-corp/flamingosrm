package com.srpost.cm.bo.sr.stat.type;

import java.util.Map;


/**
 * 내부단 VOC 통계(유형별) 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-12-29
 * @since   2.0
 */
public interface IStatTypeService {

    Map<String, Map<String, Object>> statMap(StatTypeSearchBean bean);
}
