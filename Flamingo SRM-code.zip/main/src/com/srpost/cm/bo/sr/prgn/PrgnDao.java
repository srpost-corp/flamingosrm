package com.srpost.cm.bo.sr.prgn;

import static com.srpost.salmon.constant.StringPool.*;

import java.lang.reflect.Array;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.bean.BasePagerBean;
import com.srpost.salmon.lang.StringUtil;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 모범답안 DAO
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   2.0
 */
@Repository
public class PrgnDao extends EgovAbstractMapper {

    public BasePagerBean list(PrgnBean bean) {
        
        Map<String, Object> parameterMap = PrgnUtil.getParameterMap(bean);

        List<PrgnBean> dataList = selectList("_prgn.list", parameterMap);
        int totalCount = (Integer)selectOne("_prgn.listCount", parameterMap);

        return new BasePagerBean(dataList, totalCount, bean);
    }
    
    public List<Map<String, Object>> listExcel(PrgnBean bean) {
    	
        Map<String, Object> parameterMap = PrgnUtil.getParameterMap(bean);
    	
        PrgnExcelRowHandler rowHandler = new PrgnExcelRowHandler();
        
    	if ( StringUtil.equals(bean.getXlsScope(), PrgnBean.SCOPE_TOTAL)) {
    		getSqlSession().select("_prgn.listExcel", parameterMap, rowHandler);
    	}
    	else {
    	    getSqlSession().select("_prgn.list", parameterMap, rowHandler);
    	}
    	
    	return rowHandler.getList();
    }
    
    public PrgnBean view(PrgnBean bean) {
        
        PrgnBean dataBean = (PrgnBean)selectOne("_prgn.view", bean);
        if (dataBean != null) {
        }
        return dataBean;
    }
    
    public int insertAction(PrgnBean bean) {
        
        PrgnUtil.setNotNullValue(bean);
        PrgnUtil.setMgrId(bean);
        
        int affected = insert("_prgn.insert", bean);
        if (affected == ONE) {

        }
        return affected;
    }

    public int updateAction(PrgnBean bean) {
        
        PrgnUtil.setNotNullValue(bean);
        PrgnUtil.setMgrId(bean);

        int affected = update("_prgn.update", bean);
        if (affected == ONE) {

        }
        return affected;
    }    

    public int deleteAction(PrgnBean bean) {

        PrgnUtil.setMgrId(bean);
        
        if (StringUtil.isNotEmpty(bean.getOrderNos())) {

            int affected = delete("_prgn.delete", bean);
            if (affected == Array.getLength(bean.getOrderNos())) {
                return ONE;
            }
        }
        return ZERO;
    }
    
    public List<PrgnBean> listAll(PrgnBean bean) {
        
        return selectList("_prgn.listAll", bean);
    }
    
    public String viewOne(PrgnBean bean) {
        
        return selectOne("_prgn.viewOne", bean);
    }
}
