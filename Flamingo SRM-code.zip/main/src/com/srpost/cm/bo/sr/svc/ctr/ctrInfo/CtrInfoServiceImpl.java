package com.srpost.cm.bo.sr.svc.ctr.ctrInfo;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.sr.svc.ctr.CtrBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 계약 서비스 구현체
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Service
public class CtrInfoServiceImpl extends EgovAbstractServiceImpl implements ICtrInfoService {

    @Resource
    CtrInfoDao dao;

    @Override
    public CtrBean svcCtrView(CtrBean bean) {
        
        return dao.svcCtrView(bean);
    }
    
    @Override
    public List<CtrBean> svcCtrList(CtrBean bean) {
        
        return dao.svcCtrList(bean);
    }

}
