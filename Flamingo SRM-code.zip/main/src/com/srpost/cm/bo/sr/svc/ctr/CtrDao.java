package com.srpost.cm.bo.sr.svc.ctr;

import static com.srpost.salmon.constant.StringPool.ONE;
import static com.srpost.salmon.constant.StringPool.ZERO;
import static com.srpost.salmon.constant.StringPool.Y;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.svc.ctr.ctrModal.CtrModalDao;
import com.srpost.salmon.bean.BasePagerBean;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.egov.ISalmonSeqGenerator;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 계약 DAO
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Repository
public class CtrDao extends EgovAbstractMapper {
    
    @Resource(name = "ctrSeqGenerator")
    ISalmonSeqGenerator seqGenerator;
    @Resource
    CtrModalDao ctrModalDao;
    
    public BasePagerBean list(CtrBean bean) {
        
        Map<String, Object> parameterMap = CtrUtil.getParameterMap(bean);
        
        List<CtrBean> dataList = selectList("_ctr.list", parameterMap);
        int totalCount = (Integer)selectOne("_ctr.listCount", parameterMap);
        
        return new BasePagerBean(dataList, totalCount, bean);
    }
    
    public List<Map<String, Object>> listExcel(CtrBean bean) {
        
        Map<String, Object> parameterMap = CtrUtil.getParameterMap(bean);
        
        CtrExcelRowHandler rowHandler = new CtrExcelRowHandler();
        
        if ( StringUtil.equals(bean.getXlsScope(), CtrBean.SCOPE_TOTAL) ) {
            getSqlSession().select("_ctr.listExcel", parameterMap, rowHandler);
        }
        else {
            getSqlSession().select("_ctr.list", parameterMap, rowHandler);
        }
        
        List<Map<String, Object>> dataList = rowHandler.getList();
        
        return dataList;
    }
    
    public CtrBean view(CtrBean bean) {
        
        return selectOne("_ctr.view", bean);
    }
    
    public synchronized int insertAction(CtrBean bean) {
        
        CtrUtil.setNotNullValue(bean);
        if ( !StringUtil.equals(bean.getReCtrYn(), Y) )
            bean.setCtrSeq(seqGenerator.getNextInteger());
        
        int affected = insert("_ctr.insert", bean);
        
        if ( affected == ONE ) {
            ctrModalDao.insertCtrModalAction(bean);
        }
        
        return affected;
    }
    
    public int updateAction(CtrBean bean) {
        
        CtrUtil.setNotNullValue(bean);
        
        int affected = update("_ctr.update", bean);
        
        if ( affected == ONE ) {
            ctrModalDao.insertCtrModalAction(bean);
        }
        
        return affected;
    }
    
    public int deleteAction(CtrBean bean) {
        
        if ( StringUtil.isNotEmpty(bean.getCtrSeqs()) ) {
            
            int affected = delete("_ctr.delete", bean);
            if ( affected > ZERO ) {
                return ONE;
            }
        }
        return ZERO;
    }
    
    public List<CtrBean> svcCtrListAll(CtrBean bean) {
        
        Map<String, Object> parameterMap = CtrUtil.getParameterMap(bean);
        
        return selectList("_ctr.listExcel", parameterMap);
    }

}
