package com.srpost.cm.bo.sr.prgn;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.lang.WebUtil;

/**
 * 내부단 모범답안 Util
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   3.0
 */
public final class PrgnUtil {

    public static Map<String, Object> getParameterMap(PrgnBean bean) {
        
        Map<String, Object> parameterMap = bean.createPagerMap();

        if ( StringUtil.isNotEmpty(bean.getOpenYn()) )
            parameterMap.put("openYn", bean.getOpenYn());
        
        if ( StringUtil.isEmpty(bean.getOpenYn()) || StringUtil.equals(bean.getOpenYn(), N)) {
            LoginBean loginBean = MgrUtil.getSession(WebUtil.getCurrentRequest());
            parameterMap.put("mgrId", loginBean.getMgrId());
        }
        
        return parameterMap;
    }
    
    public static void setNotNullValue(PrgnBean bean) {
        
        if (StringUtil.isEmpty(bean.getOpenYn()))
            bean.setOpenYn(N);
    }
    
    public static void setMgrId(PrgnBean bean) {

        LoginBean loginBean = MgrUtil.getSession(WebUtil.getCurrentRequest());
        bean.setMgrId(loginBean.getMgrId());
    }
}
