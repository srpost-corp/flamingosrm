package com.srpost.cm.bo.sr.srm.core.scrap;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.core.IVocService;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.ctg.IVocCtgService;
import com.srpost.salmon.constant.Message;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 내부단 VOC 스크랩 컨트롤러
 *
 * @author  finkle
 * @date    2014-12-12
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/srm/core/scrap")
public class VocScrapController extends BaseController {
    
    @Resource
    IVocScrapService service;
    @Resource
    IVocService vocService;
    @Resource
    IVocCtgService ctgService;
    
    /**
     * VOC 스크랩 메인
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index(VocListBean bean, HttpServletRequest request, ModelMap model) {
        
        bean.setScrapId(MgrUtil.getSession(request).getMgrId());
        
        model.addAttribute("pagerBean", service.list(bean));
        model.addAttribute("confList", VocUtil.getConfList());
        model.addAttribute("ctgListMap", ctgService.listByDepth());
    }
    
    /**
     * VOC 스크랩 메인 : GRID용
     */
    @RequestMapping(value="indexGrid.do", method=RequestMethod.GET)
    public void index() {
    }
    
    /**
     * VOC 스크랩 목록
     */
    @RequestMapping(value="j_list.do", method=RequestMethod.GET)
    public ModelAndView list(VocListBean bean, HttpServletRequest request, ModelMap model) {

        bean.setScrapId(MgrUtil.getSession(request).getMgrId());
        
        return responseJson(model, service.list(bean));
    }
    
    /**
     * VOC 스크랩 상세정보
     */
    @RequestMapping(value={"view.do", "*_view.do"}, method={RequestMethod.GET, RequestMethod.POST})
    public void view(VocBean bean, HttpServletRequest request, ModelMap model) {

        VocBean dataBean = vocService.view(bean, false);
        
        model.addAttribute("confBean", VocUtil.getConfBean(dataBean.getVocCd()));
        model.addAttribute("dataBean", dataBean);
    }

    /**
     * VOC 스크랩 액션
     */
    @RequestMapping(value="t_scrapAction.do", method=RequestMethod.POST)
    public ModelAndView scrapAction(
            @RequestParam(value="vocSeq") int vocSeq,
            HttpServletRequest request, ModelMap model) {

        LoginBean loginBean = MgrUtil.getSession(request);
        
        int affected = service.insertScrapAction(vocSeq, loginBean.getMgrId());
        if (affected == MINUS_ONE) {
            return responseText(model, Message.fail("voc.scrap.duplicate.fail"));
        }
        else if (affected == ONE) {
            return responseText(model, Message.success("voc.scrap.success"));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
    
    /**
     * VOC 스크랩 삭제 액션
     */
    @RequestMapping(value="t_unScrapAction.do", method=RequestMethod.POST)
    public ModelAndView unScrapAction(
            @RequestParam(value="vocSeq") int vocSeq,
            HttpServletRequest request, ModelMap model) {

        LoginBean loginBean = MgrUtil.getSession(request);
        
        int affected = service.deleteScrapAction(vocSeq, loginBean.getMgrId());
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_DELETE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
    
    /**
     * 엑셀 변환 팝업창
     */
    @RequestMapping(value="p_excelForm.do", method=RequestMethod.GET)
    public void excelForm() {
    }
    
    /**
     * 엑셀 변환 액션
     */
    @RequestMapping(value="x_excelAction.do", method=RequestMethod.POST)
    public ModelAndView excelAction(VocListBean bean, HttpServletRequest request, ModelMap model) {

        bean.setScrapId(MgrUtil.getSession(request).getMgrId());
        
    	List<Map<String, Object>> dataList = service.listExcel(bean);

        return responseExcel(model, dataList, bean);
    }
}
