package com.srpost.cm.bo.sr.srm.core.incomment;

import java.util.List;

/**
 * 내부단 VOC 내부의견글 서비스 인터페이스
 *
 * @author  finkle
 * @date    2015-01-16
 * @since   2.0
 */
public interface IVocInCmtService {

    List<VocInCmtBean> list(VocInCmtBean bean);
    
    VocInCmtBean view(VocInCmtBean bean);

    int insertAction(VocInCmtBean bean);

    int updateAction(VocInCmtBean bean);

    int replyAction(VocInCmtBean bean);

    int deleteAction(VocInCmtBean bean);
}
