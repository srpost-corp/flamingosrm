package com.srpost.cm.bo.sr.srm.core;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.conf.VocConfBean;
import com.srpost.cm.bo.sr.srm.conf.VocConfCache;
import com.srpost.salmon.cache.Cache;
import com.srpost.salmon.constant.Constant;
import com.srpost.salmon.lang.CookieUtil;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.lang.UTF8Util;
import com.srpost.salmon.lang.WebUtil;

import static com.srpost.salmon.constant.StringPool.*;

/**
 * 내부단 VOC Util
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   3.0
 */
public class VocUtil {

    public static Map<String, Object> getParameterMap(VocListBean bean) {
        
        Map<String, Object> parameterMap = bean.createPagerMap();
        
        setCommonParameterMap(bean, parameterMap);
        
        LoginBean loginBean = MgrUtil.getSession(WebUtil.getCurrentRequest());
        parameterMap.put("scrapId", loginBean.getMgrId());
        
        if (StringUtil.isEmpty(bean.getType())) {
            if (StringUtil.isNotEmpty(bean.getAuthCd())) {
                bean.setType(
                    bean.getAuthCd() == VocConstant.AUTH_SYSTEM || bean.getAuthCd() == VocConstant.AUTH_REGISTER ? 
                            VocConstant.LIST_MNG_ALL : VocConstant.LIST_TYPE_MY_ING);
            }
        }
        
        if ( StringUtil.isNotEmpty(bean.getType()) ) {

            if (bean.getAuthCd() == VocConstant.AUTH_SYSTEM || bean.getAuthCd() == VocConstant.AUTH_REGISTER) {

                if (StringUtil.equals(bean.getType(), VocConstant.LIST_MNG_ALL)) {
                    
                }
                else if (StringUtil.equals(bean.getType(), VocConstant.LIST_MNG_END)) {
                    parameterMap.put("endMsCd", VocConstant.MS_END);
                }
                else if (StringUtil.equals(bean.getType(), VocConstant.LIST_MNG_READY)) {
                    parameterMap.put("endMsCdForReady", VocConstant.MS_READY);
                }
                else {
                    parameterMap.put("readyMsCdForIng", VocConstant.MS_READY);
                    parameterMap.put("endMsCdForIng", VocConstant.MS_END);
                }
                
                if (bean.getAuthCd() == VocConstant.AUTH_REGISTER) {
                    parameterMap.put("writerId", loginBean.getMgrId());
                }
            }
            else {
                parameterMap.put("mgrId", loginBean.getMgrId());
                parameterMap.put("authCd", bean.getAuthCd());
                
                if (StringUtil.equals(bean.getType(), VocConstant.LIST_TYPE_MY_ING)) {
                    parameterMap.put("active", VocConstant.ACT_ACTIVE);
                }
                else {
                    parameterMap.put("active", VocConstant.ACT_INACTIVE);
                }
            }
        }
        
        return parameterMap;
    }
    
    public static void setCommonParameterMap(VocListBean bean, Map<String, Object> parameterMap) {
        
        if ( StringUtil.isNotEmpty(bean.getVocCd()) )
            parameterMap.put("vocCd", bean.getVocCd());
        if ( StringUtil.isNotEmpty(bean.getKindCd()) )
            parameterMap.put("kindCd", bean.getKindCd());
        if ( StringUtil.isNotEmpty(bean.getTypeCd()) )
            parameterMap.put("typeCd", bean.getTypeCd());
        if ( StringUtil.isNotEmpty(bean.getFromCd()) )
            parameterMap.put("fromCd", bean.getFromCd());
        if ( StringUtil.isNotEmpty(bean.getFromChnlCd()) )
            parameterMap.put("fromChnlCd", bean.getFromChnlCd());
        if ( StringUtil.isNotEmpty(bean.getFromOrgCd()) )
            parameterMap.put("fromOrgCd", bean.getFromOrgCd());
        if ( StringUtil.isNotEmpty(bean.getEndCd()) )
            parameterMap.put("endCd", bean.getEndCd());
        if ( StringUtil.isNotEmpty(bean.getDeptCd()) )
            parameterMap.put("deptCd", bean.getDeptCd());   
        if ( StringUtil.isNotEmpty(bean.getOpenYn()) )
            parameterMap.put("openYn", bean.getOpenYn());
        if ( StringUtil.isNotEmpty(bean.getManyYn()) )
            parameterMap.put("manyYn", bean.getManyYn());
        if ( StringUtil.isNotEmpty(bean.getRptYn()) )
            parameterMap.put("rptYn", bean.getRptYn());
        if ( StringUtil.isNotEmpty(bean.getMgrStatusCd()) )
            parameterMap.put("mgrStatusCd", bean.getMgrStatusCd());
        if ( StringUtil.isNotEmpty(bean.getUserStatusCd()) )
            parameterMap.put("userStatusCd", bean.getUserStatusCd());
        if ( StringUtil.isNotEmpty(bean.getCtgCd1()) )
            parameterMap.put("ctgCd1", bean.getCtgCd1());
        if ( StringUtil.isNotEmpty(bean.getCtgCd2()) )
            parameterMap.put("ctgCd2", bean.getCtgCd2());
        if ( StringUtil.isNotEmpty(bean.getCtgCd3()) )
            parameterMap.put("ctgCd3", bean.getCtgCd3());
    }
    
    public static void setNotNullValue(VocBean bean) {

        if (StringUtil.isNotEmpty(bean.getQuestion())) {            
            bean.setSummary( 
                UTF8Util.fixLength(StringUtil.cleanHTML(bean.getQuestion()), 190) );
        }
        
        if (StringUtil.isEmpty(bean.getOpenYn()))
            bean.setOpenYn(N);
        if (StringUtil.isEmpty(bean.getManyYn()))
            bean.setManyYn(N);
        if (StringUtil.isEmpty(bean.getRptYn()))
            bean.setRptYn(N);
        if (StringUtil.isEmpty(bean.getLmtDt()))
            bean.setLmtDt(null);
        
        if (StringUtil.isNotEmpty(bean.getFromCd())) {
            if (!StringUtil.equals(bean.getFromCd(), VocConstant.FROM_OFF_VOC_CD)) {
                bean.setFromChnlCd(EMPTY);
            }
            if (!StringUtil.equals(bean.getFromChnlCd(), VocConstant.FROM_CHNL_ORG_CD)) {
                bean.setFromOrgCd(EMPTY);
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    public static List<VocConfBean> getConfList() {
        
        return (List<VocConfBean>)Cache.get(VocConfCache.LIST_KEY);
    }

    public static VocConfBean getConfBean(Integer vocCd) {
        
        return (VocConfBean)Cache.get(VocConfCache.VIEW_KEY + vocCd);
    }
    
    public static boolean needUpdateReadCnt(
            VocBean bean, HttpServletRequest request, HttpServletResponse response) {

        String key = "VOC" + UNDERSCORE + bean.getVocSeq();
        
        String value = CookieUtil.getCookie(request, key);
        if (!StringUtil.equals(value, Y)) {
            CookieUtil.setCookie(response, key, Y, Constant.READ_CNT_MINUTES);
            return true;
        }
        return false;
    }
    
    /* 내가 주무부서에 속해 있는지 확인 */
    public static boolean isBelongToMasterDept(List<VocDivBean> divList, LoginBean loginBean) {

        if (StringUtil.isEmpty(divList)) return false;
        
        for (VocDivBean item : divList) {
            if (StringUtil.equals(item.getMasterYn(), Y)) {
                if (StringUtil.equals(loginBean.getDeptCd(), item.getDeptCd())) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /* 접수자에게 반송건이 있는지 확인 (For 재분배 버튼 표시) */
    public static boolean hasReDivideCount(List<VocDivBean> divList) {
        
        if (StringUtil.isEmpty(divList)) return false;
        
        int reDivideCount = ZERO;
        for (VocDivBean item : divList) {
            if (StringUtil.equals(item.getMgrStatusCd(), MS_RECEIVE) &&
                    StringUtil.isNotEmpty(item.getSnbkReqDt())) {
                reDivideCount++;
            }
        }
        return reDivideCount > ZERO;
    }
    
    /* 내가 속한 VocDivBean 획득 */
    public static VocDivBean getMyVocDivBean(List<VocDivBean> divList, LoginBean loginBean) {
        
        if (StringUtil.isEmpty(divList)) return null;
        
        for (VocDivBean item : divList) {
            if (StringUtil.equals(loginBean.getDeptCd(), item.getDeptCd())) {
                return item;
            }
        }
        return null;
    }
    
    /* 특정 orderNo에 대한 VocDivBean 획득 */
    public static VocDivBean getMyVocDivBean(List<VocDivBean> divList, Integer orderNo) {
        
        if (StringUtil.isEmpty(divList)) return null;
        
        for (VocDivBean item : divList) {
            if (orderNo == ONE) {
                if (StringUtil.equals(item.getMasterYn(), Y)) {
                    return item;
                }
            }
            else {
                if (orderNo == item.getOrderNo()) {
                    return item;
                }
            }
        }
        return null;
    }
    
    /* 특정 부서코드에 대한 VocDivBean 획득 */
    public static VocDivBean getMyVocDivBean(List<VocDivBean> divList, String deptCd) {
        
        if (StringUtil.isEmpty(divList)) return null;
        
        for (VocDivBean item : divList) {
            if (StringUtil.equals(deptCd, item.getDeptCd())) {
                return item;
            }
        }
        return null;
    }
    
    /* 협조부서 답변이 모두 완료되었는지 확인 */
    public static boolean isFinishSupportDeptReply(List<VocDivBean> divList) {
        
        if (StringUtil.isEmpty(divList)) return false;
        
        for (VocDivBean item : divList) {
            if (StringUtil.equals(item.getMasterYn(), Y)) {
                continue;
            }
            if (!StringUtil.equals(item.getMgrStatusCd(), MS_END)) {
                return false;
            }
        }
        return true;
    }
    
    /* 내 부서 제외하고 관련부서의 처리상태가 지정한 처리상태인지 확인 */
    public static boolean isAllSameStatus(List<VocDivBean> divList, LoginBean loginBean, String mgrStatusCd) {
        
        if (StringUtil.isEmpty(divList)) return true;
        
        // 일반 VOC일 경우
        if (divList.size() == ONE) return true;
        
        for (VocDivBean item : divList) {
            if (StringUtil.equals(loginBean.getDeptCd(), item.getDeptCd())) {
                continue;
            }
            if (!StringUtil.equals(item.getMgrStatusCd(), mgrStatusCd)) {
                return false;
            }
        }
        return true;
    }
    
    /* 결재가 1번이라도 승인되었는지 확인 */
    public static boolean isApproveOnceInSanc(List<VocSancBean> sancList) {
        
        if (StringUtil.isEmpty(sancList)) return false;
        
        for (VocSancBean item : sancList) {
            if (StringUtil.equals(item.getStatusNm(), VocConstant.SANC_APPROVE)) {
                return true;
            }
        }
        return false;
    }
    
    /* 결재자인지 확인 */
    public static boolean isSancer(List<VocSancBean> sancList, String mgrId) {
        
        if (StringUtil.isEmpty(sancList)) return false;
        
        for (VocSancBean item : sancList) {
            
            if ( StringUtil.equals(item.getStatusNm(), VocConstant.SANC_APPROVE) ) {
                continue;
            }
            else  if ( StringUtil.equals(item.getStatusNm(), VocConstant.SANC_DENY) ) {
                return false;
            }
            else if ( StringUtil.equals(item.getStatusNm(), VocConstant.SANC_READY) ) {
                
                if ( StringUtil.equals(item.getMgrId(), mgrId) ) {
                    return true;
                }
                return false;
            }
            else {
                return false;
            }
        }
        return false;
    }
    
    /* 회신유형 */
    public static String getAlertNms(String alertCds) {
        
        if (StringUtil.isEmpty(alertCds)) return EMPTY;

        String[] arrayCds = StringUtil.split(alertCds, COMMA);
        String[] arrayNms = new String[arrayCds.length];
        
        int size = arrayCds.length;
        for (int i=0 ; i < size ; i++) {
            if (StringUtil.equals(arrayCds[i], Constant.ALIM_EMAIL))
                arrayNms[i] = "이메일";
            else if (StringUtil.equals(arrayCds[i], Constant.ALIM_MOBILE))
                arrayNms[i] = "휴대폰";
            else if (StringUtil.equals(arrayCds[i], Constant.ALIM_DOC))
                arrayNms[i] = "우편(서신)";
            else if (StringUtil.equals(arrayCds[i], Constant.ALIM_OTHERS))
                arrayNms[i] = "기타";
            else
                arrayNms[i] = EMPTY;
        }
        
        return StringUtil.join(arrayNms, COMMA);
    }
}
