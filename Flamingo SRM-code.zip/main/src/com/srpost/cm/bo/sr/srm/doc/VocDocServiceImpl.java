package com.srpost.cm.bo.sr.srm.doc;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 처리대장 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-19
 * @since   2.0
 */
@Service
public class VocDocServiceImpl extends EgovAbstractServiceImpl implements IVocDocService {

    @Resource
    VocDocDao dao;

    @Override
    public BasePagerBean list(VocListBean bean) {
        
        return dao.list(bean);
    }
}
