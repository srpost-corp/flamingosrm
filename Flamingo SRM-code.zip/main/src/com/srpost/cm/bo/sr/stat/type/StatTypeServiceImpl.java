package com.srpost.cm.bo.sr.stat.type;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 통계(유형별) 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-29
 * @since   2.0
 */
@Service
public class StatTypeServiceImpl extends EgovAbstractServiceImpl implements IStatTypeService {

    @Resource
    StatTypeDao dao;
    
    @Override
    public Map<String, Map<String, Object>> statMap(StatTypeSearchBean bean) {

        return dao.statMap(bean);
    }
}
