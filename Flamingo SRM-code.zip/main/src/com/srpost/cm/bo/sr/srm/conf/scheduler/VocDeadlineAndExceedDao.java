package com.srpost.cm.bo.sr.srm.conf.scheduler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocConstant;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository
public class VocDeadlineAndExceedDao extends EgovAbstractMapper implements IVocDeadlineAndExceedDao {

    /* 기한임박 대상 VOC 로드 */
    public List<VocBean> deadlineList(Integer[] deadlineVocs) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("endMsCd", VocConstant.MS_END);
        parameterMap.put("vocs", deadlineVocs);
        
        return selectList("_dlaex.deadlineList", parameterMap);
    }
    
    /* 기한초과 대상 VOC 로드 */
    public List<VocBean> exceedList(Integer[] exceedVocs) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("endMsCd", VocConstant.MS_END);
        parameterMap.put("vocs", exceedVocs);
        
        return selectList("_dlaex.exceedList", parameterMap);
    }
}
