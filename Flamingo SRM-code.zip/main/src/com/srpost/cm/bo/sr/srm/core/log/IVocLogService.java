package com.srpost.cm.bo.sr.srm.core.log;

import java.util.List;

/**
 * 내부단 VOC 로그 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-12-01
 * @since   2.0
 */
public interface IVocLogService {

    List<VocLogBean> list(VocLogBean bean);
    
    int insertAction(VocLogBean bean);
    
    String viewUpdateReplyLog(Integer vocSeq, Integer orderNo);
    
    int insertUpdateReplyLog(VocUpdateReplyLogBean bean);
}
