package com.srpost.cm.bo.sr.stat.d3;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;
import com.srpost.cm.bo.sr.stat.type.StatTypeUtil;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 내부단 VOC 통계(D3) 컨트롤러
 *
 * @author  finkle
 * @date    2014-12-24
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/stat/d3")
public class D3StatController extends BaseController {

    @Resource
    ID3StatService service;
    
    /**
     * 통계 메인
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index(ModelMap model) {
        
        model.addAttribute("vocList", VocUtil.getConfList());
        
        String termDts[] = StatTypeUtil.getTermMonth();
        if ( StringUtil.isNotEmpty(termDts) ) {
            model.addAttribute("startDd", DateTimeUtil.appendDash(termDts[0]));
            model.addAttribute("endDd", DateTimeUtil.appendDash(termDts[1]));
        }
    }
    
    /**
     * 특정 연도에 해당하는 통계자료 추출
     */
    @RequestMapping(value="j_stat.do", method=RequestMethod.GET)
    public ModelAndView statData(StatTypeSearchBean bean, ModelMap model) {

        return responseJson(model, service.statList(bean));
    }
    
    
    /**
     * 조건식에 해당하는 RAW 자료 얻기 (팝업)
     */
    @RequestMapping(value="p_list.do", method=RequestMethod.GET)
    public void list(D3StatParameterBean bean , ModelMap model) {
        
        model.addAttribute("pager", service.list(bean));
    }
}
