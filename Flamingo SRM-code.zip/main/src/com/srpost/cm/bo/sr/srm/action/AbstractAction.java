package com.srpost.cm.bo.sr.srm.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opensymphony.workflow.WorkflowException;
import com.srpost.cm.bo.base.file.FileDao;
import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.conf.VocConfBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDao;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimHandler;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogDao;
import com.srpost.cm.bo.sr.srm.supporter.IVocRcvNoGenerator;
import com.srpost.salmon.constant.Constant;
import com.srpost.salmon.constant.Message;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.WebUtil;
import com.srpost.salmon.spi.egov.ISalmonSeqGenerator;
import com.srpost.salmon.spi.osworkflow.SalmonWorkflow;

import static com.srpost.salmon.constant.StringPool.EMPTY;
import static com.srpost.salmon.constant.StringPool.ONE;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 추상 Action 클래스 : Strategy 패턴
 *
 * @author  finkle
 * @date    2014-11-27
 * @since   3.0
 */
@SuppressWarnings("unchecked")
public abstract class AbstractAction extends EgovAbstractMapper implements IAction {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    protected IVocRcvNoGenerator rcvNoGenerator;
    @Resource(name = "vocSeqGenerator")
    protected ISalmonSeqGenerator vocSeqGenerator;
    @Resource
    protected FileDao fileDao;
    @Resource
    protected VocDao vocDao;
    @Resource
    protected VocLogDao vocLogDao;
    
    @Resource
    private SalmonWorkflow workflow;
    @Resource
    private VocAlimHandler vocAlimHandler;

    /**
     * 액션 실행
     */
    public String execute(VocBean bean) throws Exception {

        Map<String, Object> transientVars = new HashMap<String, Object>();
        
        transientVars.put("loginBean", MgrUtil.getSession(getRequest()));
        transientVars.put("vocBean", bean);
        transientVars.put("today", DateTimeUtil.getToday());
        
        executeInternal(transientVars);
        
        return Message.SUCCESS;
    }
    
    protected abstract void executeInternal(Map<String, Object> transientVars) throws Exception;

    
    /**
     * HttpServletRequest 파라메타 맵 얻기
     */
    protected Map<String, Object> getParameterMap() {        

        return (Map<String, Object>)getRequest().getAttribute(Constant.GLOBAL_PRAM_MAP_KEY);
    }
    
    /**
     * HttpServletRequest 얻기
     */
    protected HttpServletRequest getRequest() {
        return WebUtil.getCurrentRequest();
    }
    
    /**
     * 특정 VOC에 대한 DIV 목록 획득
     */
    protected List<VocDivBean> getDivList(Integer vocSeq) {
        
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("vocSeq", vocSeq);
        
        return selectList("_vocSupport.listDiv", paramMap);
    }
    
    /**
     * 알림 메시지 전송
     */
    protected void executeAlim(VocAlimMap alimMap) {

        vocAlimHandler.execute(alimMap);
    }
    
    /**
     * Workflow 생성
     */
    protected long createtWorkflow(Map<String, Object> transientVars) throws WorkflowException {
        return createtWorkflow(transientVars, false);
    }
    protected long createtWorkflow(Map<String, Object> transientVars, boolean isComplex) throws WorkflowException {

        Object loginInfo = transientVars.get("loginBean");
        
        LoginBean loginBean = (LoginBean)loginInfo;
        String loginId = loginBean.getMgrId();
        
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        VocConfBean confBean = VocUtil.getConfBean(vocBean.getVocCd());
        
        workflow.setCaller(loginId);
        
        return workflow.initialize(confBean.getWfName() + (isComplex ? "_COMPLEX" : EMPTY), ONE, transientVars);
    }
    
    /**
     * Workflow 실행
     */
    protected void executeWorkflow(Map<String, Object> transientVars, long wfId) throws WorkflowException {
        
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        workflow.setCaller(loginBean.getMgrId());
        workflow.doAction(wfId, vocBean.getActionId(), transientVars);
    }
}
