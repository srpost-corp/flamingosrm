package com.srpost.cm.bo.sr.srm.core.user;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 고객정보 DAO
 *
 * @author  finkle
 * @date    2015-09-03
 * @since   3.0
 */
@Repository
public class VocUserDao extends EgovAbstractMapper {

    public BasePagerBean list(MgrBean bean) {
        
        Map<String, Object> parameterMap = bean.createPagerMap();
        parameterMap.put("writerId", bean.getMgrId());
        parameterMap.put("endMgrStatusCd", VocConstant.MS_END);
        
        List<VocBean> dataList = selectList("_vocUser.list", parameterMap);
        int totalCount = (Integer)selectOne("_vocUser.listCount", parameterMap);

        return new BasePagerBean(dataList, totalCount, bean);
    }
}
