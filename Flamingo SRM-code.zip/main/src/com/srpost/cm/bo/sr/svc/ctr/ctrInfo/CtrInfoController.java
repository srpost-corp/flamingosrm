package com.srpost.cm.bo.sr.svc.ctr.ctrInfo;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.cm.bo.sr.svc.ctr.CtrBean;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 계약 컨트롤러
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Controller
@RequestMapping(value="/bo/sr/svc/ctr/ctrInfo")
public class CtrInfoController extends BaseController {
    
    @Resource
    ICtrInfoService service;
    
    /**
     * 프로젝트, 제품, 사업자 상세정보의 계약 상세정보
     */
    @RequestMapping(value="a_svcCtrView.do", method=RequestMethod.POST)
    public void svcCtrView(CtrBean bean, ModelMap model) {
        
        model.addAttribute("dataBean", service.svcCtrView(bean));
    }
    
    /**
     * 프로젝트, 제품, 사업자 상세정보의 계약 목록
     */
    @RequestMapping(value="a_svcCtrList.do", method=RequestMethod.POST)
    public void svcCtrList(CtrBean bean, ModelMap model) {
        
    }
    
    /**
     * 프로젝트, 제품, 사업자 상세정보의 계약 목록
     */
    @RequestMapping(value="j_list.do", method={RequestMethod.GET, RequestMethod.POST})
    public ModelAndView list(CtrBean bean, ModelMap model) {
        
        return responseJson(model, service.svcCtrList(bean));
    }

}
