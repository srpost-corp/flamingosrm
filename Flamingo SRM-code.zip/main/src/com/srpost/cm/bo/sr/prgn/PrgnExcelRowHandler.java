package com.srpost.cm.bo.sr.prgn;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 모범답안 엑셀변환 row handler
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   3.0
 */
public class PrgnExcelRowHandler implements ResultHandler {

	private List<Map<String, Object>> list;

    public PrgnExcelRowHandler() {
    	
    	list = new ArrayList<Map<String, Object>>();
    }
    
    @Override
    public void handleResult(ResultContext context) {
        
    	PrgnBean dataBean = (PrgnBean)context.getResultObject();

    	Map<String, Object> dataMap = new HashMap<String, Object>();

        dataMap.put( "mgrNm", dataBean.getMgrNm() );
        dataMap.put( "title", dataBean.getTitle() );
        dataMap.put( "openYn", StringUtil.parsePublicYn(dataBean.getOpenYn()) );
        dataMap.put( "regDt", dataBean.getRegDt() );
        dataMap.put( "modiDt", dataBean.getModiDt() );

        list.add(dataMap);
    }
    
    public List<Map<String, Object>> getList() {
        
        return list;
    }
}