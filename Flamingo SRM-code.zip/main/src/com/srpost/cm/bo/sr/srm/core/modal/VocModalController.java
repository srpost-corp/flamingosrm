package com.srpost.cm.bo.sr.srm.core.modal;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.IMgrService;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.core.IVocService;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.IVocAlimService;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimBean;
import com.srpost.cm.bo.sr.srm.core.log.IVocLogService;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.cm.bo.sr.srm.core.score.IVocScoreService;
import com.srpost.cm.bo.sr.srm.ctg.IVocCtgService;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 내부단 VOC 모달창 컨트롤러
 *
 * @author  finkle
 * @date    2014-11-26
 * @since   3.0
 */
@Controller
@RequestMapping(value="/bo/sr/srm/core/modal")
public class VocModalController extends BaseController {

    @Resource
    IVocModalService service;
    @Resource
    IVocService vocService;
    @Resource
    IVocCtgService ctgService;
    @Resource
    IVocScoreService vocScoreService;
    @Resource
    IVocLogService vocLogService;
    @Resource
    IVocAlimService vocAlimService;
    @Resource
    IMgrService mgrService;
    
    /**
     * VOC 공통 팝업창
     * - 고객검색/주무부서/협조부서/처리자 직접지정
     * - 알림상세/내용인쇄
     */
    @RequestMapping(value="p_*.do", method=RequestMethod.GET)
    public void index(ModelMap model) {
    }
    
    /**
     * 부서 TREE 목록
     */
    @RequestMapping(value="j_listDept.do", method=RequestMethod.GET)
    public ModelAndView listDept(
            @RequestParam(value="highDeptCd") String highDeptCd,
            @RequestParam(value="authCd") Integer authCd, 
            @RequestParam(value="deptCds") String deptCds, ModelMap model) {

        return responseJson(model, service.listDept(highDeptCd, authCd, deptCds));
    }
    
    /**
     * 부서 TREE 목록 (복합 VOC)
     * @deprecated JR_listDeptAll.do로 대체함 2015-01-14
     */
    @RequestMapping(value="j_listDeptCheck.do", method=RequestMethod.GET)
    public ModelAndView listDeptCheck(
            @RequestParam(value="highDeptCd") String highDeptCd,
            @RequestParam(value="authCd") Integer authCd,
            @RequestParam(value="masterDeptCd") String masterDeptCd, 
            @RequestParam(value="supportDeptCds") String supportDeptCds,
            ModelMap model) {

        return responseJson(model, 
                service.listDeptCheck(highDeptCd, authCd, masterDeptCd, supportDeptCds));
    }
    
    /**
     * 부서 TREE 목록 ALL (for 부서 재분배)
     */
    @RequestMapping(value="j_listDeptAll.do", method=RequestMethod.GET)
    public ModelAndView listDeptAll(
            @RequestParam(value="authCd") Integer authCd, ModelMap model) {

        return responseJson(model, service.listDeptAllJSON(authCd), true);
    }
    
    /**
     * VOC 처리 이력 팝업창
     */
    @RequestMapping(value="p_logList.do", method=RequestMethod.GET)
    public void logList(VocLogBean bean, ModelMap model) {
        
        model.addAttribute("dataList", vocLogService.list(bean));
    }
    
    /**
     * VOC 내용 인쇄 팝업창 (인쇄 액션)
     */
    @RequestMapping(value="p_printView.do", method=RequestMethod.GET)
    public void printView(VocBean bean, VocListBean listBean, HttpServletRequest request, ModelMap model) {
        
        // columnsCd + "|" + columnsNm
        String columns = listBean.getXlsColumns();
        if ( StringUtil.isEmpty(columns) ) {
            // throw new Exception("Print information is not passed.");
        }
        String[] items = StringUtil.split(columns, PIPE);
        if ( StringUtil.isEmpty(items) ) {
            // throw new Exception("Print information is incorrect.");
        }
        
        VocBean dataBean = vocService.view(bean, false);
        model.addAttribute("dataBean", dataBean);
        
        String[] rowKeys = StringUtil.split(items[0], COMMA);
        String[] headerNames = StringUtil.split(items[1], COMMA);
        int headerLength = headerNames.length;
        
        for (int i=0 ; i < headerLength ; i++) {
            if (StringUtil.equals(rowKeys[i], "userInfo")) {

                model.addAttribute("mgrBean", mgrService.view(dataBean.getWriterId()));
            }
            else if (StringUtil.equals(rowKeys[i], "logInfo")) {
                
                VocLogBean logBean = new VocLogBean();
                logBean.setVocSeq(bean.getVocSeq());
                
                model.addAttribute("logList", vocLogService.list(logBean));
            }
            
            model.addAttribute(rowKeys[i], Y);
        }
    }


    /**
     * VOC 알림 이력 팝업창
     */
    @RequestMapping(value="p_alimList.do", method=RequestMethod.GET)
    public void alimList(VocAlimBean bean, ModelMap model) {
        
        model.addAttribute("dataList", vocAlimService.list(bean));
    }
    
    /**
     * VOC 알림 이력 메일 상세 보기 팝업창
     */
    @RequestMapping(value="x_emailView.do", method=RequestMethod.GET)
    public void emailView(VocAlimBean bean, ModelMap model) {
        
        model.addAttribute("dataBean", vocAlimService.view(bean));
    }
    
    
    /**
     * VOC 답변 수정 폼 팝업창
     */
    @RequestMapping(value="p_updateReplyForm.do", method=RequestMethod.GET)
    public void updateReplyForm(
            @RequestParam(value="vocSeq") int vocSeq, ModelMap model) {
        
        model.addAttribute("dataBean", vocService.viewSimple(vocSeq));
    }
    
    /**
     * VOC 답변 수정 이력 팝업창 (link with 처리 이력 팝업창)
     */
    @RequestMapping(value="p_updateReplyLog.do", method=RequestMethod.GET)
    public void updateReplyLog(
            @RequestParam(value="vocSeq") int vocSeq,
            @RequestParam(value="orderNo") int orderNo, ModelMap model) {
        
        model.addAttribute("dataBean", vocLogService.viewUpdateReplyLog(vocSeq, orderNo));
    }
    
    /**
     * VOC 만족도 상세 팝업창
     */
    @RequestMapping(value={"p_scoreView.do", "p_scoreForm.do"}, method=RequestMethod.GET)
    public void scoreView(VocBean bean, ModelMap model) {
        
        model.addAttribute("dataBean", vocService.viewSimple(bean.getVocSeq()));
        model.addAttribute("dataList", vocScoreService.list(bean));
    }
    
    /*-------------------------- Action popup --------------------------------------------*/
    
    
    /**
     * VOC 공통 팝업창 (VOC 액션)
     */
    @RequestMapping(value="/action/p_*.do", method=RequestMethod.GET)
    public void actionPop(VocBean bean, ModelMap model) {
        
        setCommonAttribute(bean.getVocSeq(), bean.getActionId(), model);
    }
    
    /**
     * VOC 처리자지정 팝업창 (VOC 액션)
     */
    @RequestMapping(value="/action/p_assignForm.do", method=RequestMethod.GET)
    public void assignPop(VocBean bean, HttpServletRequest request, ModelMap model) {
        
        VocBean dataBean = vocService.view(bean, false);
        if (dataBean != null) {
            dataBean.setActionId(bean.getActionId());
            
            if (StringUtil.isEmpty(dataBean.getCmplnCd())) {
                dataBean.setCmplnCd(VocConstant.DEF_CMPLN_CD);
            }
            
            // 소속부서 내 처리자 목록 설정
            LoginBean loginBean = MgrUtil.getSession(request);
            
            MgrBean mgrBean = new MgrBean();
            mgrBean.setMgrId(loginBean.getMgrId());
            mgrBean.setDeptCd(loginBean.getDeptCd());
            mgrBean.setAuthCd(VocConstant.AUTH_DEALER);
            
            model.addAttribute("dealerList", service.listDealer(mgrBean));
            
            VocDivBean myDivBean = VocUtil.getMyVocDivBean(dataBean.getDivList(), loginBean);
            if ( StringUtil.isEmpty(myDivBean) ) {
                myDivBean = dataBean.getDivList().get(ZERO);
            }
            model.addAttribute("myDivBean", myDivBean);
        }
        
        model.addAttribute("dataBean", dataBean);
        model.addAttribute("ctgListMap", ctgService.listByDepth());
    }
    
    /**
     * VOC 반송 팝업창 (VOC 액션)
     */
    @RequestMapping(value="/action/p_sendBackForm.do", method=RequestMethod.GET)
    public void sendBackPop(VocBean bean, HttpServletRequest request, ModelMap model) {
        
        VocBean dataBean = vocService.view(bean, false);
        LoginBean loginBean = MgrUtil.getSession(request);
        if (dataBean != null) {
            dataBean.setActionId(bean.getActionId());
            
            if (StringUtil.isEmpty(dataBean.getCmplnCd())) {
                dataBean.setCmplnCd(VocConstant.DEF_CMPLN_CD);
            }
            
            if ( StringUtil.isNotEmpty(dataBean.getDivList()) ) {
                
                VocDivBean vocDivBean = VocUtil.getMyVocDivBean(dataBean.getDivList(), loginBean);
                
                if ( StringUtil.isNotEmpty(vocDivBean) ) {
                    
                    String mgrStatusCd = vocDivBean.getMgrStatusCd();
                    
                    if (StringUtil.equals(mgrStatusCd, VocConstant.MS_DIVIDE)) {
                        
                        model.addAttribute("iAmDivider", true);
                        model.addAttribute("iAmDealer", false);
                    }
                    else if (StringUtil.equals(mgrStatusCd, VocConstant.MS_ASSIGN)) {
                        
                        model.addAttribute("iAmDivider", false);
                        model.addAttribute("iAmDealer", true);
                    }
                }
                else {
                    model.addAttribute("iAmDivider", true);
                    model.addAttribute("iAmDealer", false);
                }
                
                VocDivBean myDivBean = VocUtil.getMyVocDivBean(dataBean.getDivList(), loginBean);
                if ( StringUtil.isEmpty(myDivBean) ) {
                    myDivBean = dataBean.getDivList().get(ZERO);
                }
                model.addAttribute("myDivBean", myDivBean);
            }
        }
        
        model.addAttribute("dataBean", dataBean);
    }
    
    /**
     * VOC 처리독촉 팝업창 (VOC 액션)
     */
    @RequestMapping(value="/action/p_urgeForm.do", method=RequestMethod.GET)
    public void urgePop(VocBean bean, HttpServletRequest request, ModelMap model) {
        
        setCommonAttribute(bean.getVocSeq(), bean.getActionId(), model);
        
        // 독촉대상 부서 | 처리자 목록 설정
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("vocSeq", bean.getVocSeq());

        model.addAttribute("divList", service.listDiv(parameterMap));
    }
    
    /**
     * VOC 전달, 재분배, 기한연장 팝업창 (VOC 액션)
     */
    @RequestMapping(value={"/action/p_moveForm.do", "/action/p_reDivideForm.do", 
            "/action/p_extensionForm.do", "/action/p_extensionReqForm.do"}, method=RequestMethod.GET)
    public void movePop(VocBean bean, HttpServletRequest request, ModelMap model) {

        VocBean dataBean = vocService.view(bean, false);
        
        if (dataBean != null) {
            dataBean.setActionId(bean.getActionId());
            model.addAttribute("dataBean", dataBean);
            
            LoginBean loginBean = MgrUtil.getSession(request);
            VocDivBean myDivBean = VocUtil.getMyVocDivBean(dataBean.getDivList(), loginBean);
            if ( StringUtil.isEmpty(myDivBean) ) {
                myDivBean = dataBean.getDivList().get(ZERO);
            }
            model.addAttribute("myDivBean", myDivBean);
        }
        
        if (request.getRequestURI().indexOf("PR_extensionForm.do") != -1) {
            model.addAttribute("extLogBean", service.viewExtReqLog(bean.getVocSeq()));
        }
    }
    
    /**
     * VOC 처리 팝업창 (VOC 액션)
     */
    @RequestMapping(value="/action/p_dealForm.do", method=RequestMethod.GET)
    public void dealPop(VocBean bean, HttpServletRequest request, ModelMap model) {

        LoginBean loginBean = MgrUtil.getSession(request);
        
        VocBean dataBean = vocService.view(bean, false);
        
        if (dataBean != null) {
            dataBean.setActionId(bean.getActionId());
            
            if (StringUtil.isEmpty(dataBean.getCmplnCd())) {
                dataBean.setCmplnCd(VocConstant.DEF_CMPLN_CD);
            }
            
            boolean iAmBelongToMasterDept = 
                    VocUtil.isBelongToMasterDept(dataBean.getDivList(), loginBean);
            
            model.addAttribute("iAmBelongToMasterDept", iAmBelongToMasterDept);
            
            VocDivBean myDivBean = VocUtil.getMyVocDivBean(dataBean.getDivList(), loginBean);
            if ( StringUtil.isEmpty(myDivBean) ) {
                myDivBean = dataBean.getDivList().get(ZERO);
            }
            model.addAttribute("myDivBean", myDivBean);
        }
        
        model.addAttribute("dataBean", dataBean);
        model.addAttribute("ctgListMap", ctgService.listByDepth());
        
        // 결재선 목록 설정
        model.addAttribute("sancStoreList", service.listMySancStore(loginBean.getMgrId()));
    }
    
    /**
     * VOC 결재 팝업창 (VOC 액션) - 승인/반려/취소
     */
    @RequestMapping(value="/action/p_sanc*.do", method=RequestMethod.GET)
    public void sancPop(VocBean bean, HttpServletRequest request, ModelMap model) {
        
        setCommonAttribute(bean.getVocSeq(), bean.getActionId(), model);
        
        // 결재 목록 설정
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("vocSeq", bean.getVocSeq());
        
        List<VocSancBean> vocSancList = service.listSanc(parameterMap);
        model.addAttribute("sancList", vocSancList);
        
        // 결재가 1번이라도 승인이 되었는지 여부 (boolean)
        model.addAttribute("isApproveOnceInSanc", VocUtil.isApproveOnceInSanc(vocSancList));
        
        // 결재자인지 여부 (boolean)
        LoginBean loginBean = MgrUtil.getSession(request);
        model.addAttribute("isSancer", VocUtil.isSancer(vocSancList, loginBean.getMgrId()));
    }
    
    private void setCommonAttribute(int vocSeq, int actionId, ModelMap model) {
        
        VocBean dataBean = vocService.viewSimple(vocSeq);
        if (dataBean != null) {
            dataBean.setActionId(actionId);
            
            if (StringUtil.isEmpty(dataBean.getCmplnCd())) {
                dataBean.setCmplnCd(VocConstant.DEF_CMPLN_CD);
            }
            
            model.addAttribute("confBean", VocUtil.getConfBean(dataBean.getVocCd()));
        }
        
        model.addAttribute("dataBean", dataBean);
        model.addAttribute("confList", VocUtil.getConfList());
        model.addAttribute("ctgListMap", ctgService.listByDepth());
    }
    

    
    /**
     * VOC 처리 팝업창 : 최근 사용한 결재선 삭제 (VOC 액션)
     */
    @RequestMapping(value="/action/a_deleteSancLineAndReload.do", method=RequestMethod.POST)
    public void deleteSancLineAndReload(
            @RequestParam(value="sancLine") String sancLine, 
            HttpServletRequest request, ModelMap model) {
        
        // 결재선 목록 설정
        LoginBean loginBean = MgrUtil.getSession(request);
        
        service.deleteSancLineAction(loginBean.getMgrId(), sancLine);

        model.addAttribute("sancStoreList", service.listMySancStore(loginBean.getMgrId()));
    }
}
