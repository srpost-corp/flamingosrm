package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.conf.VocConfBean;
import com.srpost.cm.bo.sr.srm.conf.VocReceiverBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;

/**
 * TRANSFER : 이첩 - 접수자
 *
 * @author  finkle
 * @date    2014-12-03
 * @since   3.0
 */
public class TransferAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();
        String reason = (String)parameterMap.get("reason");
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());
        VocDivBean myDivBean = VocUtil.getMyVocDivBean(divList, ONE);

        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || divList.size() == 0 || 
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                (!StringUtil.equals(MS_READY, orgBean.getMgrStatusCd())) ||
                orgBean.getVocCd() == vocBean.getVocCd() ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * 워크플로우 실행
         */
        executeWorkflow(transientVars, myDivBean.getWfId());
        
        /*-------------------------
         * VOC 수정
         */
        vocBean.setUserStatusCd(US_READY);
        vocBean.setMgrStatusCd(MS_READY);
        
        int affected = update("_vocAction.updateVocForTransfer", vocBean);
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 삭제
             */
            delete("_vocAction.deleteAllEntry", vocBean.getVocSeq());
            
            /*-------------------------
             * ENTRY 등록
             */
            
            // 이첩대상 접수자 ENTRY 활성화 등록
            VocConfBean confBean = VocUtil.getConfBean(vocBean.getVocCd());

            List<VocReceiverBean> receiverList = confBean.getReceiverList();
            for (VocReceiverBean receiverBean : receiverList) {
                
                insert("_vocAction.insertEntry", new VocEntryBean(
                    vocBean.getVocSeq(), receiverBean.getMgrId(), AUTH_RECEIVER, ACT_ACTIVE));
                
                alimMap.addMgr((MgrBean)selectOne("_mgr.view", receiverBean.getMgrId()));
            }
            
            /*-------------------------
             * DIV 수정
             */
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setOrderNo(myDivBean.getOrderNo());
            divBean.setMgrStatusCd(vocBean.getMgrStatusCd());
            
            insert("_vocAction.updateDivForTransfer", divBean);
            
            /*-------------------------
             * 로그 등록
             */
            VocBean dataBean = vocDao.viewSimple(vocBean.getVocSeq());
            
            StringBuilder logContents = new StringBuilder(); 
            logContents.append("<strong>이첩</strong> : ");
            logContents.append(orgBean.getVocNm() + " &rarr; <span class='emphasis'>" + dataBean.getVocNm() + "</span>");
            logContents.append("<br/>이첩사유 : " + reason);
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 접수자, 고객
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            alimMap.setMgrBean((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getWriterId()));
            
            //사유
            alimMap.setReason(reason);
            
            executeAlim(alimMap);
        }
    }
}
