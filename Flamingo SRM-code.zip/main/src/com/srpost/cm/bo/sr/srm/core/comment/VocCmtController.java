package com.srpost.cm.bo.sr.srm.core.comment;

import static com.srpost.salmon.constant.StringPool.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.salmon.constant.Message;
import com.srpost.salmon.lang.FileUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 외부단 VOC 외부의견글 컨트롤러
 *
 * @author  finkle
 * @date    2015-01-23
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/srm/core/comment")
public class VocCmtController extends BaseController {

    @Resource
    IVocCmtService service;
    
    /**
     * VOC 외부의견글 목록 조회
     */
    @RequestMapping(value="a_list.do", method=RequestMethod.GET)
    public void list(VocCmtBean bean, ModelMap model) {

        model.addAttribute("dataList", service.list(bean));
    }

    /**
     * VOC 외부의견글 등록 액션
     */
    @RequestMapping(value="t_insertAction.do", method=RequestMethod.POST)
    public ModelAndView insertAction(VocCmtBean bean, HttpServletRequest request, ModelMap model) {

        VocCmtUtil.setWriterlValue(bean, request);
        bean.setFileList(FileUtil.getUploadFile(request));
        
    	int affected = service.insertAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_INSERT_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }

    /**
     * VOC 외부의견글 수정, 답변 폼
     */
    @RequestMapping(value={"p_updateForm.do", "p_replyForm.do"}, method=RequestMethod.GET)
    public void updateForm(VocCmtBean bean, ModelMap model) {

        model.addAttribute("dataBean", service.view(bean));
    }
    
    /**
     * VOC 외부의견글 수정 액션
     */
    @RequestMapping(value="t_updateAction.do", method=RequestMethod.POST)
    public ModelAndView updateAction(VocCmtBean bean, HttpServletRequest request, ModelMap model) {

    	VocCmtBean dataBean = service.view(bean);
    	
    	if ( !VocCmtUtil.isOwner(dataBean, request) ) 
            return responseText(model, Message.fail(Message.BASE_AUTH_CRUD_FAIL_KEY));
    	
        bean.setFileList(FileUtil.getUploadFile(request));
        
    	int affected = service.updateAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_UPDATE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
    
    /**
     * VOC 외부의견글 답변 액션
     */
    @RequestMapping(value="t_replyAction.do", method=RequestMethod.POST)
    public ModelAndView replyAction(VocCmtBean bean, HttpServletRequest request, ModelMap model) {

        VocCmtUtil.setWriterlValue(bean, request);
        bean.setFileList(FileUtil.getUploadFile(request));
        
    	int affected = service.replyAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_INSERT_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }

    /**
     * VOC 외부의견글 삭제 액션
     */
    @RequestMapping(value="t_deleteAction.do", method=RequestMethod.POST)
    public ModelAndView deleteAction(VocCmtBean bean, HttpServletRequest request, ModelMap model) {

    	VocCmtBean dataBean = service.view(bean);

    	if ( !VocCmtUtil.isOwner(dataBean, request) ) 
    		return responseText(model, Message.fail(Message.BASE_AUTH_CRUD_FAIL_KEY));
    	
    	int affected = service.deleteAction(bean);
    	if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_DELETE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
}
