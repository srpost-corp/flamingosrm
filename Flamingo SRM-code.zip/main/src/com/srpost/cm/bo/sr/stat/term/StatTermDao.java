package com.srpost.cm.bo.sr.stat.term;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 통계(기간별) DAO
 *
 * @author  finkle
 * @date    2014-12-24
 * @since   2.0
 */
@Repository
public class StatTermDao extends EgovAbstractMapper {

    public List<Map<String, Object>> year(Integer vocCd, Integer year) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("vocCd", vocCd);
        parameterMap.put("year", year);
        
        return selectList("_statTerm.year", parameterMap);
    }

    public List<Map<String, Object>> month(Integer vocCd, String startDd, String endDd) {

        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("vocCd", vocCd);
        parameterMap.put("startDd", startDd);
        parameterMap.put("endDd", endDd);
        
        return selectList("_statTerm.month", parameterMap);
    }

    public List<Map<String, Object>> day(Integer vocCd, String startMonth) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("vocCd", vocCd);
        parameterMap.put("startMonth", startMonth);
        
        return selectList("_statTerm.day", parameterMap);
    }

    public List<Map<String, Object>> dow(Integer vocCd, String startDd, String endDd) {

        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("vocCd", vocCd);
        parameterMap.put("startDd", startDd);
        parameterMap.put("endDd", endDd);

        return selectList("_statTerm.dow", parameterMap);
    }
}
