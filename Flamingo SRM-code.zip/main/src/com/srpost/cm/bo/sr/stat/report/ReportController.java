package com.srpost.cm.bo.sr.stat.report;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.srpost.salmon.bean.BaseListBean;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 리포트 컨트롤러
 *
 * @author  finkle
 * @date    2014-10-22
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/stat/report")
public class ReportController extends BaseController {
    
    @Resource
    IReportService service;
    
    /**
     * 익스플로러 : 주요 이슈 카테고리 (더보기)
     */
    @RequestMapping(value="allCtgList.do", method=RequestMethod.GET)
    public void allCtgList(ModelMap model) {
        
        model.addAttribute("dataList", service.allCtgList());
    }
    
    /**
     * 익스플로러 : SR 이슈 태그 (더보기)
     */
    @RequestMapping(value="allTagList.do", method=RequestMethod.GET)
    public void allTagList(BaseListBean bean, ModelMap model) {
        
        bean.setRowPerPage(20);
        
        model.addAttribute("pagerBean", service.allTagList(bean));
    }
}
