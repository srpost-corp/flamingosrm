package com.srpost.cm.bo.sr.srm.conf;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseListBean;
import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 VOC설정 정보 Bean
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
@Alias("vocConfBean")
@SuppressWarnings("serial")
public class VocConfBean extends BaseListBean {

    List<VocReceiverBean> receiverList;
    
    /** VOC_코드 */
    private Integer vocCd;
    /** VOC_이름 */
    private String vocNm;
    /** 처리기한 (일) */
    private Integer dealDayCnt = 7;
    /** 워크플로우 이름 */
    private String wfName;
    /** 시간포함 여부 */
    private String timeYn = "N";
    /** 공개 여부 */
    private String openYn = "Y";
    /** 전용 여부 : 담당부서만 조회 가능 여부 (감사실 민원 등) */
    private String privateYn = "N";
    /** 의견글 여부 */
    private String cmtYn = "N";
    /** 내부_의견글 여부 */
    private String inCmtYn = "N";
    /** 기한임박 사용여부 */
    private String deadlineYn = "Y";
    /** 기한임박 알림일 */
    private Integer deadlineCnt = 1;
    /** 기한초과 사용여부 */
    private String exceedYn = "Y";
    /** 기한초과 알림일 */
    private Integer exceedCnt = 0;
    /** 사용_여부 */
    private String useYn = "Y";
    /** 등록일 */
    private String regDt;
    /** 등록일 */
    private String modiDt;
    
    /** VOC_코드 배열 */
    private Integer[] vocCds;

    
    public Integer getVocCd() {
        return vocCd;
    }
    public void setVocCd(Integer vocCd) {
        this.vocCd = vocCd;
    }
    public String getVocNm() {
        return vocNm;
    }
    public void setVocNm(String vocNm) {
        this.vocNm = vocNm;
    }
    public Integer getDealDayCnt() {
        return dealDayCnt;
    }
    public void setDealDayCnt(Integer dealDayCnt) {
        this.dealDayCnt = dealDayCnt;
    }
    public String getTimeYn() {
        return timeYn;
    }
    public void setTimeYn(String timeYn) {
        this.timeYn = timeYn;
    }
    public String getOpenYn() {
        return openYn;
    }
    public void setOpenYn(String openYn) {
        this.openYn = openYn;
    }
    public String getPrivateYn() {
        return privateYn;
    }
    public void setPrivateYn(String privateYn) {
        this.privateYn = privateYn;
    }
    public String getCmtYn() {
        return cmtYn;
    }
    public void setCmtYn(String cmtYn) {
        this.cmtYn = cmtYn;
    }
    public String getInCmtYn() {
        return inCmtYn;
    }
    public void setInCmtYn(String inCmtYn) {
        this.inCmtYn = inCmtYn;
    }
    public Integer getDeadlineCnt() {
        return deadlineCnt;
    }
    public void setDeadlineCnt(Integer deadlineCnt) {
        this.deadlineCnt = deadlineCnt;
    }
    public Integer getExceedCnt() {
        return exceedCnt;
    }
    public void setExceedCnt(Integer exceedCnt) {
        this.exceedCnt = exceedCnt;
    }
    public String getUseYn() {
        return useYn;
    }
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
    public String getModiDt() {
        return modiDt;
    }
    public void setModiDt(String modiDt) {
        this.modiDt = modiDt;
    }
    public Integer[] getVocCds() {
        return vocCds;
    }
    public void setVocCds(Integer[] vocCds) {
        this.vocCds = vocCds;
    }
    public String getDeadlineYn() {
        return deadlineYn;
    }
    public void setDeadlineYn(String deadlineYn) {
        this.deadlineYn = deadlineYn;
    }
    public String getExceedYn() {
        return exceedYn;
    }
    public void setExceedYn(String exceedYn) {
        this.exceedYn = exceedYn;
    }
    public String getWfName() {
        return wfName;
    }
    public void setWfName(String wfName) {
        this.wfName = wfName;
    }
    public List<VocReceiverBean> getReceiverList() {
        return receiverList;
    }
    public void setReceiverList(List<VocReceiverBean> receiverList) {
        this.receiverList = receiverList;
    }
    public VocReceiverBean getMasterReceiver() {
        
        if (StringUtil.isNotEmpty(receiverList) && receiverList.size() > ZERO)
            return receiverList.get(ZERO);
        else
            return null;
    }
}
