package com.srpost.cm.bo.sr.srm.core.alim;

import javax.annotation.Resource;

import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.srpost.cm.bo.sr.tpl.ITplService;
import com.srpost.cm.bo.sr.tpl.TplUtil;
import com.srpost.salmon.constant.Constant;

import static com.srpost.salmon.constant.Constant.ENCODING;

import jodd.util.StringUtil;

/**
 * VOC 알림 메시지 Parser
 *
 * @author  finkle
 * @date    2015-01-30
 * @since   3.0
 */
public class VocAlimMessageParser {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Resource
    VelocityEngine velocityEngine;
    @Resource
    ITplService tplService;

    private final String TEMPLATE_NAME = "/template.html";
    private final String USER_TEMPLATE_NAME = "/templateUser.html";
    
    private String templatePath;
    

    public String getTitle(String kindCd, String alertCd, String actionCd) {
        
        return tplService.viewOne(kindCd, alertCd, actionCd);
    }
    
    public String getContents(String kindCd, VocAlimMap alimMap) {
        
        if (StringUtil.equals(kindCd, TplUtil.KIND_MGR))
            return VelocityEngineUtils.mergeTemplateIntoString(
                    velocityEngine, templatePath + TEMPLATE_NAME, ENCODING, alimMap);
        else
            return VelocityEngineUtils.mergeTemplateIntoString(
                    velocityEngine, templatePath + USER_TEMPLATE_NAME, ENCODING, alimMap);
    }
    
    public void extraValuables(VocAlimMap alimMap) {

        alimMap.put("hostUrl", Constant.HOST_URL);
        alimMap.put("systemNm", Constant.SYSTEM_NM);
        alimMap.put("clientNm", Constant.CLIENT_NM);
        alimMap.put("address", Constant.CLIENT_ADDRESS);

        alimMap.put("actionCd", alimMap.getActionCd());
        alimMap.put("dataBean", alimMap.getVocBean());
        alimMap.put("divBean", alimMap.getDivBean());
        alimMap.put("mgrBean", alimMap.getMgrBean());
        alimMap.put("reason", alimMap.getReason());
    }
    
    
    public void setTemplatePath(String templatePath) {
        this.templatePath = templatePath;
    }
}
