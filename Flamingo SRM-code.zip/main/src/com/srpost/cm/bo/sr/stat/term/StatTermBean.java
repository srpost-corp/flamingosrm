package com.srpost.cm.bo.sr.stat.term;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.srpost.salmon.bean.BaseBean;

/**
 * 내부단 VOC 통계(기간별) 정보 Bean
 *
 * @author  finkle
 * @date    2014-12-24
 * @since   2.0
 */
@SuppressWarnings("serial")
public class StatTermBean extends BaseBean {

    private List<Map<String, Object>> items;
    /** 전체 값 */
    private int total = 0;
    /** 최대 값 */
    private int max = 0;
    /** 최대 값 라벨 */
    private String maxLabel = EMPTY;
    
    public StatTermBean() {
        items = new ArrayList<Map<String, Object>>();
    }
    
    
    public void addElement(Map<String, Object> item) {
        
        items.add(item);
    }

    public void addElement(int idx, Map<String, Object> item) { 
        
        items.remove(idx);
        items.add(idx, item);
    }

    public Map<String, Object> get(int idx) {
        
        return items.get(idx);
    }

    public void setBean(int val, String label) {
        
        total += val;
        
        if ( val > max ) {
            max = val;
            maxLabel = label;
        }        
    }

    public List<Map<String, Object>> getItems() {
        return items;
    }

    public int getSize() {
        return items.size();
    }
    
    public int getTotal() {
        return total == 0 ? 0 : total;
    }

    public int getMax() {
        return max == 0 ? 0 : max;
    }

    public String getMaxLabel() {
        return maxLabel;
    }

    public int getAverage() {
       
        int tt = getSize();

        if (tt == 0) 
            return 0;
        else 
            return (int)(Math.round(total/tt));
    }

	public int getMaxRatio() {
		
		return total == 0 ? 0 : (int)(((float)max/(float)total)*100);
	}
}
