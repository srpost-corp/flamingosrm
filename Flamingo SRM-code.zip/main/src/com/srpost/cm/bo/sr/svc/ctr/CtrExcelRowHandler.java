package com.srpost.cm.bo.sr.svc.ctr;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

/**
 * 계약 엑셀변환 row handler
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
public class CtrExcelRowHandler implements ResultHandler {
    
private List<Map<String, Object>> list;
    
    public CtrExcelRowHandler() {
        
        list = new ArrayList<Map<String,Object>>();
    }
    
    @Override
    public void handleResult(ResultContext context) {
        
        CtrBean dataBean = (CtrBean)context.getResultObject();
        
        Map<String, Object> dataMap = new HashMap<String, Object>();
        
        dataMap.put("ctrSeq", dataBean.getCtrSeq());
        dataMap.put("ctrNm", dataBean.getCtrNm());
        dataMap.put("startDd", dataBean.getStartDd());
        dataMap.put("endDd", dataBean.getEndDd());
        dataMap.put("regDt", dataBean.getRegDt());
        dataMap.put("modiDt", dataBean.getModiDt());
        
        list.add(dataMap);
        
    }
    
    public List<Map<String, Object>> getList() {
        
        return list;
    }

}
