package com.srpost.cm.bo.sr.srm.core.scrap;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 스크랩 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-12
 * @since   2.0
 */
@Service
public class VocScrapServiceImpl extends EgovAbstractServiceImpl implements IVocScrapService {

    @Resource
    VocScrapDao dao;

    @Override
    public BasePagerBean list(VocListBean bean) {
        
        return dao.list(bean);
    }
    
    @Override
    public List<Map<String, Object>> listExcel(VocListBean bean) {
        
        return dao.listExcel(bean);
    }
    
    @Override
    public int insertScrapAction(Integer vocSeq, String mgrId) {
        
        return dao.insertScrapAction(vocSeq, mgrId);
    }
    
    @Override
    public int deleteScrapAction(Integer vocSeq, String mgrId) {
        
        return dao.deleteScrapAction(vocSeq, mgrId);
    }
    
    @Override
    public List<VocBean> listForDashboard(VocListBean bean) {
        
        return dao.listForDashboard(bean);
    }
}
