package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * SEND_BACK : 반송 - 분배자/처리자
 *
 * @author  finkle
 * @date    2014-12-05
 * @since   3.0
 */
public class SendBackAction extends OffInsertAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();
        String target = (String)parameterMap.get("target"); // receiver|divider
        String reason = (String)parameterMap.get("reason");
        boolean toReceiver = StringUtil.equals(target, "receiver");
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        String today = (String)transientVars.get("today");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());
        VocDivBean myDivBean = VocUtil.getMyVocDivBean(divList, loginBean);
        boolean isComplex = StringUtil.equals(orgBean.getKindCd(), KND_COMPLEX);

        int affected = ONE;
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || divList.size() == 0 || StringUtil.isEmpty(myDivBean) || 
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                !(StringUtil.equals(myDivBean.getMgrStatusCd(), MS_DIVIDE) || StringUtil.equals(myDivBean.getMgrStatusCd(), MS_ASSIGN)) ||
                (StringUtil.isNotEmpty(myDivBean.getDeptCd()) && !StringUtil.equals(myDivBean.getDeptCd(), loginBean.getDeptCd())) ||
                (StringUtil.isNotEmpty(myDivBean.getMgrId()) && !StringUtil.equals(myDivBean.getMgrId(), loginBean.getMgrId())) ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * 워크플로우 실행
         */
        transientVars.put("toReceiver", toReceiver);
        executeWorkflow(transientVars, myDivBean.getWfId());

        /*-------------------------
         * VOC 수정
         */
        boolean isAllSameStatus = true;

        // 복합 VOC
        if (isComplex) {

            if (toReceiver) {
                // 관련부서의 모든 상태가 접수일 경우에만 VOC 수정
                // 모든 협조부서가 접수자에게 반송한 경우에 해당
                isAllSameStatus = VocUtil.isAllSameStatus(divList, loginBean, MS_RECEIVE);
            }
            else {
                // 관련부서의 모든 상태가 분배일 경우에만 VOC 수정
                isAllSameStatus = VocUtil.isAllSameStatus(divList, loginBean, MS_DIVIDE);
            }
        }
        
        if (isAllSameStatus) {
            vocBean.setMgrStatusCd(toReceiver ? MS_RECEIVE : MS_DIVIDE);

            if (toReceiver) 
                affected = insert("_vocAction.updateVocForSendBackToReceiver", vocBean);
            else
                affected = insert("_vocAction.updateVocForSendBackToDivider", vocBean);
        }
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 수정
             */
            if (toReceiver) {
                // 기존 부서에 속한 분배, 처리자 ENTRY 모두 삭제
                VocEntryBean entryBean = new VocEntryBean();
                entryBean.setVocSeq(vocBean.getVocSeq());
                entryBean.setDeptCd(loginBean.getDeptCd());
                entryBean.setAuthCd(AUTH_DIVIDER);                    
                delete("_vocAction.deleteEntry", entryBean);
                
                entryBean.setAuthCd(AUTH_DEALER);                    
                delete("_vocAction.deleteEntry", entryBean);
                
                // 접수자 ENTRY 활성화 수정
                update("_vocAction.insertEntry", new VocEntryBean(
                        vocBean.getVocSeq(), orgBean.getRcvId(), AUTH_RECEIVER, ACT_ACTIVE));
            }
            else {
                // 처리자 ENTRY 삭제
                VocEntryBean entryBean = new VocEntryBean();
                entryBean.setVocSeq(vocBean.getVocSeq());
                entryBean.setMgrId(loginBean.getMgrId());
                entryBean.setAuthCd(AUTH_DEALER);
                
                delete("_vocAction.deleteEntry", entryBean);
                
                /*--
                // 전체 분배자 ENTRY 활성화 수정
                MgrBean paramMgrBean = new MgrBean();
                paramMgrBean.setDeptCd(loginBean.getDeptCd());
                paramMgrBean.setAuthCd(AUTH_DIVIDER);
                
                List<MgrBean> dividerList = selectList("_vocSupport.listMgr", paramMgrBean);
                for (MgrBean dividerBean : dividerList) {
                    update("_vocAction.updateEntry", new VocEntryBean(
                            vocBean.getVocSeq(), dividerBean.getMgrId(), ACTIVE));
                }
                --*/
                
                // 연관화된 분배자 ENTRY 활성화 수정
                entryBean = new VocEntryBean();
                entryBean.setVocSeq(vocBean.getVocSeq());
                entryBean.setActivate(ACT_WORKER);
                entryBean.setAuthCd(AUTH_DIVIDER);
                entryBean.setDeptCd(loginBean.getDeptCd());
                
                String dividerId = selectOne("_vocSupport.viewMgrIdFromEntry", entryBean);
                insert("_vocAction.insertEntry", new VocEntryBean(
                        vocBean.getVocSeq(), dividerId, AUTH_DIVIDER, ACT_ACTIVE));
                
                alimMap.addMgr((MgrBean)selectOne("_mgr.view", dividerId));
            }
            
            /*-------------------------
             * DIV 수정
             */
            
            /*--
            if (toReceiver) {
                // DIV 삭제
                // FIXME : 삭제하면 접수자가 재분배 할 수 없을 듯 함 ㅠㅠㅠㅠ
                
                VocDivBean divBean = new VocDivBean();
                divBean.setVocSeq(vocBean.getVocSeq());
                divBean.setOrderNo(myDivBean.getOrderNo());
                
                delete("_vocAction.deleteDiv", divBean);
            }
            else {
            } --*/
            
            // DIV 수정
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setOrderNo(myDivBean.getOrderNo());
            divBean.setMgrStatusCd(toReceiver ? MS_RECEIVE : MS_DIVIDE);
            divBean.setDivDt(toReceiver ? EMPTY : DateTimeUtil.toDigitString(myDivBean.getDivDt()));
            divBean.setSnbkReqDt(today);
            
            update("_vocAction.updateDivForSendBack", divBean);
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>반송</strong> : TO " + (toReceiver ? "접수자" : "분배자"));
            logContents.append("<br/>반송사유 : " + reason);
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 분배자 or 접수자
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            
            if (toReceiver) {
                // TO 접수자
                alimMap.addMgr((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getRcvId()));
            }
            else {
                // TO 분배자
            }
            
            //사유
            alimMap.setReason(reason);
            
            executeAlim(alimMap);
        }
    }
}
