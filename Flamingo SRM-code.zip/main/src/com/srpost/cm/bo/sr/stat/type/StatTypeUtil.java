package com.srpost.cm.bo.sr.stat.type;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jodd.util.ArraysUtil;

import com.srpost.cm.bo.base.code.CodeBean;
import com.srpost.cm.bo.base.code.CodeUtil;
import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

import static com.srpost.salmon.constant.StringPool.*;

/**
 * 내부단 VOC 통계(유형별) Util
 *
 * @author  finkle
 * @date    2014-12-29
 * @since   3.0
 */
public final class StatTypeUtil {

    /** 일간 검색주기 */
    public static final int TERM_DAY = 1;
    /** 주간 검색주기 */
    public static final int TERM_WEEK = 2;
    /** 월간 검색주기 */
    public static final int TERM_MONTH = 3;
    /** 연간 검색주기 */
    public static final int TERM_YEAR = 4;
    
    /** 유입경로 통계 */
    public static final String STAT_FROM = "VOC_FROM";
    /** 처리유형 통계 */
    public static final String STAT_KIND = "VOC_KIND";
    /** VOC유형 통계 */
    public static final String STAT_TYPE = "VOC_TYPE";
    /** 답변유형 통계 */
    public static final String STAT_END = "VOC_END";
    /** 만족도 통계 */
    public static final String STAT_SCORE = "VOC_SCORE";
    /** 평균 처리기간 통계 */
    public static final String STAT_DEAL_AVG = "STAT_DEAL_AVG";
    
    public static final String[] STAT_CDS = {
        STAT_FROM, STAT_KIND, STAT_TYPE, STAT_END, STAT_SCORE, STAT_DEAL_AVG};
    public static final String[] STAT_NMS = {
        "유입경로", "처리유형", "SR유형", "답변유형", "만족도", "평균 처리기간"};    

    public static final List<CodeBean> STATS_LIST = new ArrayList<CodeBean>();
    static { 
        for (int i=0 ; i < STAT_CDS.length ; i++) {
            CodeBean codeBean = new CodeBean();
            codeBean.setPrvCd(STAT_CDS[i]);
            codeBean.setPrvNm(STAT_NMS[i]);
            
            STATS_LIST.add(codeBean);
        }
    }
    
    public static String getStatNm(String statCd) {
        return StringUtil.replace(
                STAT_NMS[ArraysUtil.indexOf(STAT_CDS, statCd)], SPACE, UNDERSCORE);
    }

    public static List<CodeBean> getCodeList(StatTypeSearchBean bean) {

        if ( StringUtil.equals(bean.getStatCd(), STAT_DEAL_AVG) )
            return null;
        else
            return CodeUtil.getCodeList(bean.getStatCd());
    }
    
    public static Map<String, Object> getParameterMap(StatTypeSearchBean bean) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();

        // Set X column
        if ( StringUtil.equals(bean.getStatCd(), STAT_FROM) ) {
            parameterMap.put("X_COLUMN", "FROM_CD");
        }
        else if ( StringUtil.equals(bean.getStatCd(), STAT_KIND) ) {
            parameterMap.put("X_COLUMN", "KIND_CD");
        }
        else if ( StringUtil.equals(bean.getStatCd(), STAT_TYPE) ) {
            parameterMap.put("X_COLUMN", "TYPE_CD");
        }
        else if ( StringUtil.equals(bean.getStatCd(), STAT_END) ) {
            parameterMap.put("X_COLUMN", "END_CD");
        }
        
        // Set Y column
        if ( StringUtil.isEmpty(bean.getDeptCd()) ) {
            parameterMap.put("Y_COLUMN", "DEPT_CD");
        }
        else {
            parameterMap.put("Y_COLUMN", "MGR_ID");
        }

        // Set search condition
        if ( StringUtil.isNotEmpty(bean.getVocCd()) ) {
            parameterMap.put("vocCd", bean.getVocCd());
        }
        if ( StringUtil.isNotEmpty(bean.getSupportYn()) ) {
            parameterMap.put("supportYn", bean.getSupportYn());
        }
        if ( StringUtil.isNotEmpty(bean.getDeptCd()) ) {
            parameterMap.put("deptCd", bean.getDeptCd());
        }
        parameterMap.put("endMsCd", VocConstant.MS_END);
        
        setDefaultTerm(bean, parameterMap);
        
        return parameterMap;
    }
    
    
    public static void setDefaultTerm(StatTypeSearchBean bean, Map<String, Object> parameterMap) {
        
        if ( StringUtil.isEmpty(bean.getStartDd()) ) {

            if ( StringUtil.isEmpty(bean.getTermCd()) ) {
                bean.setTermCd(TERM_MONTH);
            }

            String termDts[] = null;

            switch ( bean.getTermCd() ) {
                case TERM_DAY:
                    termDts = getTermDay();
                break;

                case TERM_WEEK:
                    termDts = getTermWeek();
                break;

                case TERM_MONTH:
                    termDts = getTermMonth();
                break;

                case TERM_YEAR:
                    termDts = getTermYear();
                break;
            }

            if ( StringUtil.isNotEmpty(termDts) ) {
                bean.setStartDd(DateTimeUtil.appendDash(termDts[0]));
                bean.setEndDd(DateTimeUtil.appendDash(termDts[1]));
            }
        }

        if ( StringUtil.isNotEmpty(bean.getStartDd()) )
            parameterMap.put("startDt", DateTimeUtil.removeDash(bean.getStartDd()) + "000000");
        if ( StringUtil.isNotEmpty(bean.getEndDd()) )
            parameterMap.put("endDt", DateTimeUtil.removeDash(bean.getEndDd()) + "235959");
    }
    
    
    
    /**
     * 현재 날짜를 기준으로 일간 검색일 기간을 획득
     */
    public static String[] getTermDay() {

        String todayShort = DateTimeUtil.getTodayShort();
        
        return new String[] {todayShort, todayShort};
    }
    
    /**
     * 현재 날짜를 기준으로 주간 검색일 기간을 획득 (일요일 ~ 토요일)
     */
    public static String[] getTermWeek() {

        Calendar now = Calendar.getInstance();
        int currentDaw = now.get(Calendar.DAY_OF_WEEK);
        if ( currentDaw == Calendar.MONDAY ) {
            now.add(Calendar.DATE, -1);
        }
        else {
            now.add(Calendar.DATE, -(currentDaw-1));
        }
        
        String startDt = parseCalendar(
                now.get(Calendar.YEAR), 
                now.get(Calendar.MONTH) + 1, 
                now.get(Calendar.DATE));
        
        now.add(Calendar.DATE, 6);
        
        String endDt = parseCalendar(
                now.get(Calendar.YEAR), 
                now.get(Calendar.MONTH) + 1, 
                now.get(Calendar.DATE));
        
        return new String[] {startDt, endDt};  
    }
    
    /**
     * 현재 날짜를 기준으로 월간 검색일 기간을 획득
     */
    public static String[] getTermMonth() {

        Calendar now = Calendar.getInstance();
        int currentYear = now.get(Calendar.YEAR);
        int currentMonth = now.get(Calendar.MONTH) + 1;
        
        int lastDay = now.getActualMaximum(Calendar.DATE);
        
        String startDt = parseCalendar(currentYear, currentMonth, ONE);
        String endDt = startDt.substring(0, 6) + lastDay;
        
        return new String[] {startDt, endDt};
    }
    
    /**
     * 현재 날짜를 기준으로 연간 검색일 기간을 획득
     */
    public static String[] getTermYear() {

        Calendar now = Calendar.getInstance();
        int currentYear = now.get(Calendar.YEAR);
        
        String startDt = parseCalendar(currentYear, ONE, ONE);
        String endDt = parseCalendar(currentYear, 12, 31);
        
        return new String[] {startDt, endDt};
    }
    
    private static String parseCalendar(int year, int month, int day) {

        String yyyyMMdd = String.valueOf(year);
        
        if (month < 10)
            yyyyMMdd += String.valueOf(ZERO) + month;
        else
            yyyyMMdd += String.valueOf(month);
        
        if (day < 10)
            yyyyMMdd += String.valueOf(ZERO) + day;
        else
            yyyyMMdd += String.valueOf(day);
        
        return yyyyMMdd; 
    }
}
