package com.srpost.cm.bo.sr.stat.d3;

import java.util.List;

import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;
import com.srpost.salmon.bean.BasePagerBean;

/**
 * 내부단 VOC 통계(D3) 서비스 인터페이스
 *
 * @author  finkle
 * @date    206-07-20
 * @since   2.0
 */
public interface ID3StatService {
    
    List<D3StatResultBean> statList(StatTypeSearchBean bean);
    
    BasePagerBean list(D3StatParameterBean bean);
}
