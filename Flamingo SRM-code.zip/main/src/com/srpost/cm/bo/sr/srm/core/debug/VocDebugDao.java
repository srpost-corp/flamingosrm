package com.srpost.cm.bo.sr.srm.core.debug;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 디버그용 DAO
 *
 * @author  finkle
 * @date    2014-12-04
 * @since   3.0
 */
@Repository
public class VocDebugDao extends EgovAbstractMapper {

    public List<VocDivBean> listDiv(Integer vocSeq) {
        
        Map<String, Integer> parameterMap = new HashMap<String, Integer>();
        parameterMap.put("vocSeq", vocSeq);
        
        return selectList("_vocSupport.listDiv", parameterMap);
    }
    
    public List<VocSancBean> listSanc(Integer vocSeq) {

        return selectList("_vocSupport.listSanc", vocSeq);
    }
    
    public List<Map<String, Object>> listEntry(Integer vocSeq) {
        
        return selectList("_vocDebug.listEntry", vocSeq);        
    }
}
