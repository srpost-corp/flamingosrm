package com.srpost.cm.bo.sr.srm.action.impl;

import java.util.Map;

import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.salmon.lang.StringUtil;

import static com.srpost.salmon.constant.StringPool.MINUS_ONE;
import static com.srpost.salmon.constant.StringPool.ONE;

/**
 * USER_INSERT : 고객 VOC 삭제
 *
 * @author  finkle
 * @date    2015-02-06
 * @since   3.0
 */
public class UserDeleteAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 기본 변수 설정
         */
        VocBean vocBean = (VocBean)transientVars.get("vocBean");

        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        
        /*-------------------------
         * 유효성 체크
         * : FIXME
         */
        if (StringUtil.isEmpty(orgBean)) {
            return;
            // throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * VOC 삭제
         */
        int affected = delete("_vocTrash.delete", vocBean.getVocSeq());
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {

            /*-------------------------
             * 첨부파일 삭제
             */
            if (orgBean.getUserFileSeq() != MINUS_ONE)
                fileDao.deleteAction(orgBean.getUserFileSeq());
            if (orgBean.getMgrFileSeq() != MINUS_ONE)
                fileDao.deleteAction(orgBean.getMgrFileSeq());
        }
    }
}
