package com.srpost.cm.bo.sr.srm.action;

import java.util.Map;

/**
 * Action 클래스 저장소
 *
 * @author  finkle
 * @date    2014-11-27
 * @since   3.0
 */
public class ActionFactory {

    private Map<String, IAction> actionMap;
    
    public void setActionMap(Map<String, IAction> actionMap) {
        this.actionMap = actionMap;
    }
    
    public IAction get(String key) {
        return actionMap.get(key);
    }
}
