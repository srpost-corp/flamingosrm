package com.srpost.cm.bo.sr.svc.ctr;

import java.util.List;
import java.util.Map;

import com.srpost.salmon.bean.BasePagerBean;

/**
 * 계약 서비스 인터페이스
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
public interface ICtrService {
    
    BasePagerBean list(CtrBean bean);
    
    List<Map<String, Object>> listExcel(CtrBean bean);
    
    CtrBean view(CtrBean bean);
    
    int insertAction(CtrBean bean);
    
    int updateAction(CtrBean bean);
    
    int deleteAction(CtrBean bean);
    
    List<CtrBean> svcCtrListAll(CtrBean bean);
    
}