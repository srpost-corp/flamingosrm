package com.srpost.cm.bo.sr.srm.core;

import com.srpost.salmon.constant.Config;

/**
 * VOC 공용 프로퍼티
 * 
 * @author  finkle
 * @date    2014-11-26
 * @since   2.0
 */
public final class VocConstant {

    /*----------------------------------------------------------------------------
     * VOC : core-config.xml
     */
    public static final boolean IS_VOC_DEGUB_TAB = Config.getBoolean("voc.debugTab", false);
    public static final int VOC_MAX_UPLOAD_CNT = Config.getInt("voc.maxUploadCnt", 4);
    public static final boolean IS_VOC_USE_GRID = Config.getBoolean("voc.useGrid", false);
    
    
    /*----------------------------------------------------------------------------
     * 권한 코드 (CO_AUTH)
     */
    public static final int AUTH_SYSTEM = 1000;
    public static final int AUTH_REGISTER = 2000;
    public static final int AUTH_RECEIVER = 2001;
    public static final int AUTH_DIVIDER = 2002;
    public static final int AUTH_DEALER = 2003;
    public static final int AUTH_SANCER = 2004;
    
    /*----------------------------------------------------------------------------
     * 처리 유형 코드 (CO_CODE_PRV : VOC_KIND)
     */
    public static final String KND_SIMPLE = "1";
    public static final String KND_NORMAL = "2";
    public static final String KND_COMPLEX = "3";
    
    /*----------------------------------------------------------------------------
     * 처리 상태 코드 (외부단) (CO_CODE_PRV : VOC_USER_STATUS)
     */
    public static final String US_READY = "1";
    public static final String US_RECEIVE = "2";
    public static final String US_DEALING = "3";
    public static final String US_END = "4";
    
    /*----------------------------------------------------------------------------
     * 처리 상태 코드 (내부단) (CO_CODE_PRV : VOC_MGR_STATUS)
     */
    public static final String MS_READY = "1";
    public static final String MS_RECEIVE = "2";
    public static final String MS_DIVIDE = "3";
    public static final String MS_ASSIGN = "4";
    public static final String MS_SANC = "5";
    public static final String MS_END = "6";
    
    /*----------------------------------------------------------------------------
     * VOC OFF 등록 시 제외될 유입경로 코드 (CO_CODE_PRV : VOC_FROM)
     */
    public static final String EXCLUDE_FROM_CDS = "1, 2, 3, 4";
    
    /*----------------------------------------------------------------------------
     * VOC_FROM 하위코드 표시용 유입경로(채널) 코드 (CO_CODE_PRV : VOC_FROM_ONLINE_VOC) - 홈페이지
     */
    public static final String FROM_ONLINE_VOC_CD = "1";
    
    /*----------------------------------------------------------------------------
     * VOC_FROM 하위코드 표시용 유입경로 코드 (CO_CODE_PRV : VOC_FROM_OFF_VOC) - 등록 VOC
     */
    public static final String FROM_OFF_VOC_CD = "6";
    
    /*----------------------------------------------------------------------------
     * VOC_FROM_CHNL 하위코드 표시용 유입경로(채널) 코드 (CO_CODE_PRV : VOC_FROM_ORG) - 대외기관
     */
    public static final String FROM_CHNL_ORG_CD = "4";
    
    /*----------------------------------------------------------------------------
     * VOC_TYPE 하위코드 표시용 불만유형 코드 (CO_CODE_PRV : VOC_CMPKN) - 불만
     */
    public static final String TYPE_CMPLN_CD = "4";
    
    /*----------------------------------------------------------------------------
     * 기본 불만유형 코드 (CO_CODE_PRV : VOC_CMPKN) - 서비스
     */
    public static final String DEF_CMPLN_CD = "1";
    
    
    /*----------------------------------------------------------------------------
     * 액션 코드
     */
    public static final String ACTION_OFF_INSERT = "OFF_INSERT"; 
    public static final String ACTION_OFF_SIMPLE_INSERT = "OFF_SIMPLE_INSERT";
    public static final String ACTION_OFF_DIVIDE_INSERT = "OFF_DIVIDE_INSERT";
    public static final String ACTION_OFF_ASSIGN_INSERT = "OFF_ASSIGN_INSERT";

    public static final String ACTION_DIVIDE = "DIVIDE";
    public static final String ACTION_DIRECT_ASSIGN = "DIRECT_ASSIGN";
    public static final String ACTION_DIRECT_DEAL = "DIRECT_DEAL";
    public static final String ACTION_RECEIVE = "RECEIVE";
    public static final String ACTION_TRANSFER = "TRANSFER";
    public static final String ACTION_TRASH = "TRASH";
    public static final String ACTION_RECOVERY = "RECOVERY";
    public static final String ACTION_URGE = "URGE";
    public static final String ACTION_EXTENSION = "EXTENSION";
    public static final String ACTION_REDIVIDE = "REDIVIDE";
    public static final String ACTION_UPDATE_REPLY = "UPDATE_REPLY";
    
    public static final String ACTION_ASSIGN = "ASSIGN";
    public static final String ACTION_DEAL = "DEAL";
    public static final String ACTION_SEND_BACK = "SEND_BACK";
    public static final String ACTION_MOVE = "MOVE";
    public static final String ACTION_EXTENSION_REQ = "EXTENSION_REQ";

    public static final String ACTION_SANC_CANCEL = "SANC_CANCEL";
    public static final String ACTION_SANC_APPROVE = "SANC_APPROVE";
    public static final String ACTION_SANC_DENY = "SANC_DENY";
    
    public static final String ACTION_RESTORE = "RESTORE";
    public static final String ACTION_FORCE_DELETE = "FORCE_DELETE";
    
    public static final String ACTION_USER_INSERT = "USER_INSERT";
    public static final String ACTION_USER_UPDATE = "USER_UPDATE";
    public static final String ACTION_USER_DELETE = "USER_DELETE";
    public static final String ACTION_USER_SCORE = "USER_SCORE";
    public static final String ACTION_USER_SCORE_UPDATE = "USER_SCORE_UPDATE";
    
    public static final String __ACTION_SANC_NEXT__ = "__SANC_NEXT__";
    public static final String __ACTION_SUPPORT_RPL_FIN__ = "__SUPPORT_RPL_FIN__";
    public static final String __ACTION_SANC_APPR_FIN__ = "__SANC_APPR_FIN__";
    public static final String __ACTION_LOW_SCORE__ = "__LOW_SCORE__";
    
    public static final String __ACTION_DEADLINE__ = "__DEADLINE__";
    public static final String __ACTION_EXCEEDE__ = "__EXCEED__";
    
    /*----------------------------------------------------------------------------
     * FM_VOC_ENTRY 활성값 코드
     */
    public static final String ACT_INACTIVE = "0";
    public static final String ACT_ACTIVE = "1"; 
    public static final String ACT_WORKER = "2";
    public static final String ACT_REPORTER = "3";
    
    /*----------------------------------------------------------------------------
     * FM_VOC_SANC 결재 상태명
     */
    public static final String SANC_READY = "결재대기";
    public static final String SANC_APPROVE = "결재승인";
    public static final String SANC_DENY = "결재반려";
    
    
    /*----------------------------------------------------------------------------
     * VOC 목록 표시 검색조건 유형 값
     */
    public static final String LIST_TYPE_MY_ING = "1";
    public static final String LIST_TYPE_MY_ALL = "2";
    public static final String LIST_MNG_ALL = "3";
    public static final String LIST_MNG_ING = "4";
    public static final String LIST_MNG_END = "5";
    public static final String LIST_MNG_READY = "6";
    
    /*----------------------------------------------------------------------------
     * VOC 재분배 버튼 표시용 액션 ID (복합VOC일 경우)
     */
    public static final int WF_REDIVIDE_ACTION_ID = 100;
    
    /*------------------------------------ 
     * 만족도 점수
     *------------------------------------*/
    public static final String[] VOC_SCORE_LIST = { 
        "처리과정이 신속하게 진행되었습니까?", 
        "답변내용이 충실하게 회신되었습니까?"
    };

    public static final int[] VOC_SCORE_POINT = { 100, 75, 50, 25, 10 };
    
    public static final String[] VOC_SCORE_NM = new String[]{ 
        "매우 그렇다", "그렇다", "보통", "그렇지않다", "매우 그렇지않다" 
    };
    public static String getScoreNm(int score) {
        int length = VOC_SCORE_NM.length;
        for (int i=0 ; i < length ; i++) {
            if (score > 0 && score <= 20) return VOC_SCORE_NM[4];
            else if (score > 20 && score <= 40) return VOC_SCORE_NM[3];
            else if (score > 40 && score <= 60) return VOC_SCORE_NM[2];
            else if (score > 60 && score <= 80) return VOC_SCORE_NM[1];
            else if (score > 80 && score <= 100) return VOC_SCORE_NM[0];
        }
        return "N/A";
    }
}
