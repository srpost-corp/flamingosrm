package com.srpost.cm.bo.sr.srm.core.user;

import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.salmon.bean.BasePagerBean;

/**
 * 내부단 VOC 고객정보 인터페이스
 *
 * @author  finkle
 * @date    2015-09-03
 * @since   3.0
 */
public interface IVocUserService {

    BasePagerBean list(MgrBean bean);
}
