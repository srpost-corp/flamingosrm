package com.srpost.cm.bo.sr.srm.core.trash;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.salmon.constant.Message;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 내부단 VOC 휴지통 컨트롤러
 *
 * @author  finkle
 * @date    2014-12-12
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/srm/core/trash")
public class VocTrashController extends BaseController {
    
    @Resource
    IVocTrashService service;
    
    /**
     * VOC 휴지통 메인
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index(VocListBean bean, ModelMap model) {
        
        model.addAttribute("pagerBean", service.list(bean));
        model.addAttribute("confList", VocUtil.getConfList());
    }
    
    /**
     * VOC 휴지통 메인 : GRID용
     */
    @RequestMapping(value="indexGrid.do", method=RequestMethod.GET)
    public void indexGrid() {
    }
    
    /**
     * VOC 휴지통 목록
     */
    @RequestMapping(value="j_list.do", method=RequestMethod.GET)
    public ModelAndView list(VocListBean bean, ModelMap model) {

        return responseJson(model, service.list(bean));
    }
    
    /**
     * VOC 휴지통 상세정보
     */
    @RequestMapping(value={"view.do", "*_view.do"}, method={RequestMethod.GET, RequestMethod.POST})
    public void view(VocTrashBean bean, ModelMap model) {

        VocTrashBean dataBean = service.view(bean);
        
        model.addAttribute("dataBean", dataBean);
    }

    /**
     * VOC 휴지통 복원 액션
     */
    @RequestMapping(value="t_restoreAction.do", method=RequestMethod.POST)
    public ModelAndView restoreAction(VocBean bean, ModelMap model) {

        try {
            String result = service.restoreAction(bean);
            
            if ( !StringUtil.equals(result, Message.SUCCESS) ) {
                return responseText(model, result);
            }
        }
        catch (VocAlreadyExecuteException e) {
            return responseText(model, Message.fail("voc.already.execute.fail"));
        }
        catch (Exception e) {
            return responseText(model, Message.failMessage(e.toString()));
        }
        
        return responseText(model, Message.success("voc.trash.restore.success"));
    }
    
    /**
     * VOC 휴지통 영구삭제 액션
     */
    @RequestMapping(value="t_deleteAction.do", method=RequestMethod.POST)
    public ModelAndView deleteAction(VocBean bean, ModelMap model) {

        try {
            String result = service.deleteAction(bean);
            
            if ( !StringUtil.equals(result, Message.SUCCESS) ) {
                return responseText(model, result);
            }
        }
        catch (VocAlreadyExecuteException e) {
            return responseText(model, Message.fail("voc.already.execute.fail"));
        }
        catch (Exception e) {
            return responseText(model, Message.failMessage(e.toString()));
        }
        
        return responseText(model, Message.success(Message.COMMON_DELETE_SUCCESS_KEY));
    }
    
    /**
     * 엑셀 변환 팝업창
     */
    @RequestMapping(value="p_excelForm.do", method=RequestMethod.GET)
    public void excelForm() {
    }
    
    /**
     * 엑셀 변환 액션
     */
    @RequestMapping(value="x_excelAction.do", method=RequestMethod.POST)
    public ModelAndView excelAction(VocListBean bean, ModelMap model) {

    	List<Map<String, Object>> dataList = service.listExcel(bean);

        return responseExcel(model, dataList, bean);
    }
}
