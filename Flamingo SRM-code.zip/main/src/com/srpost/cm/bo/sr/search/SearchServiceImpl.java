package com.srpost.cm.bo.sr.search;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 검색 서비스 구현체
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   2.0
 */
@Service
public class SearchServiceImpl extends EgovAbstractServiceImpl implements ISearchService {

    @Resource
    SearchDao dao;

    @Override
    public List<String> keywordList(String keyword) {

        return dao.keywordList(keyword);
    }

    @Override
    public List<String> favoliteList() {

        return dao.favoliteList();
    }

    @Override
    public int insertAction(String keyword) {

        return dao.insertAction(keyword);
    }
}
