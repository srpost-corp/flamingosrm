package com.srpost.cm.bo.sr.prgn;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseFileBean;
import com.srpost.salmon.bean.BaseListBean;

/**
 * 내부단 모범답안 정보 Bean
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   2.0
 */
@Alias("prgnBean")
@SuppressWarnings("serial")
public class PrgnBean extends BaseListBean {

    List<BaseFileBean> fileList;

    private Integer fileCnt;
    
    /** 담당자 ID */
    private String mgrId;
    /** 담당자 이름 */
    private String mgrNm;
    /** 정렬순서 */
    private Integer orderNo;
    /** 제목 */
    private String title;
    /** 내용 */
    private String prgnContents;
    /** 공개여부 */
    private String openYn;
    /** 등록일 */
    private String regDt;
    /** 수정일 */
    private String modiDt;
    
    /** 정렬순서 배열 */
    private Integer[] orderNos;
    /** 첨부파일 배열 */
    private String[] fileIds;
    
    
    public List<BaseFileBean> getFileList() {
        return fileList;
    }
    public void setFileList(List<BaseFileBean> fileList) {
        this.fileList = fileList;
    }
    public Integer getFileCnt() {
        return fileCnt;
    }
    public void setFileCnt(Integer fileCnt) {
        this.fileCnt = fileCnt;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getMgrNm() {
        return mgrNm;
    }
    public void setMgrNm(String mgrNm) {
        this.mgrNm = mgrNm;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getPrgnContents() {
        return prgnContents;
    }
    public void setPrgnContents(String prgnContents) {
        this.prgnContents = prgnContents;
    }
    public String getOpenYn() {
        return openYn;
    }
    public void setOpenYn(String openYn) {
        this.openYn = openYn;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
    public String getModiDt() {
        return modiDt;
    }
    public void setModiDt(String modiDt) {
        this.modiDt = modiDt;
    }
    public Integer[] getOrderNos() {
        return orderNos;
    }
    public void setOrderNos(Integer[] orderNos) {
        this.orderNos = orderNos;
    }
    public String[] getFileIds() {
        return fileIds;
    }
    public void setFileIds(String[] fileIds) {
        this.fileIds = fileIds;
    }
    
    
    
}
