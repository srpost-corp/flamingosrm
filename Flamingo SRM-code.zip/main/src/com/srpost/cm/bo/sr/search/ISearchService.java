package com.srpost.cm.bo.sr.search;

import java.util.List;

/**
 * 검색 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   2.0
 */
public interface ISearchService {

    List<String> keywordList(String keyword);

    List<String> favoliteList();
    
    int insertAction(String keyword);
}
