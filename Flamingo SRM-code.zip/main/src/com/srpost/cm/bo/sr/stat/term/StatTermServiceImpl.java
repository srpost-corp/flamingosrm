package com.srpost.cm.bo.sr.stat.term;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 통계(기간별) 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-24
 * @since   2.0
 */
@Service
public class StatTermServiceImpl extends EgovAbstractServiceImpl implements IStatTermService {

    @Resource
    StatTermDao dao;

    @Override
    public StatTermBean year(Integer vocCd, Integer year) {

        return createStatTermBean(dao.year(vocCd, year));
    }

    @Override
    public StatTermBean month(Integer vocCd, String startDd, String endDd) {
        
        return createStatTermBean(dao.month(vocCd, startDd, endDd));
    }

    @Override
    public StatTermBean day(Integer vocCd, String startMonth) {

        return createStatTermBean(dao.day(vocCd, startMonth));
    }

    @Override
    public StatTermBean dow(Integer vocCd, String startDd, String endDd) {

        return createStatTermBean(dao.dow(vocCd, startDd, endDd));
    }
    
    
    private StatTermBean createStatTermBean(List<Map<String, Object>> dataList) {
        
        StatTermBean statTermBean = new StatTermBean();
        
        for (Map<String, Object> item : dataList) {
            statTermBean.setBean(
                    Integer.parseInt(item.get("VALUE").toString()), 
                    item.get("LABEL").toString());
            
            statTermBean.addElement(item);
        }
        
        List<Map<String, Object>> tempList = statTermBean.getItems();
        int size = tempList.size();
        for (int i=0 ; i < size ; i++) {
            Map<String, Object> item = (Map<String, Object>)statTermBean.get(i);
            
            float value = Float.parseFloat(item.get("VALUE").toString());
            
            /*-- int width = (int)((value/(float)statTermBean.getMax())*65); --*/
            int ratio = (int)((value/(float)statTermBean.getTotal())*100);
            int width = ratio;
            
            item.put("WIDTH", width);
            item.put("RATIO", ratio);

            statTermBean.addElement(i, item);
        }
        
        return statTermBean;
    }
}
