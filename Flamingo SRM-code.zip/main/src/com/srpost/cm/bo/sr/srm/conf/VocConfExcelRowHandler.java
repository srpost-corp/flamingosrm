package com.srpost.cm.bo.sr.srm.conf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 VOC설정 엑셀변환 row handler
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   3.0
 */
public class VocConfExcelRowHandler implements ResultHandler {

	private List<Map<String, Object>> list;

    public VocConfExcelRowHandler() {
    	
    	list = new ArrayList<Map<String, Object>>();
    }

    @Override
    public void handleResult(ResultContext context) {
        
    	VocConfBean dataBean = (VocConfBean)context.getResultObject();

    	Map<String, Object> dataMap = new HashMap<String, Object>();

    	dataMap.put( "vocCd", dataBean.getVocCd() );
    	dataMap.put( "vocNm", dataBean.getVocNm() );
        dataMap.put( "dealDayCnt", dataBean.getDealDayCnt() );
        dataMap.put( "timeYn", StringUtil.parseUseYn(dataBean.getTimeYn()) );
        dataMap.put( "wfName", dataBean.getWfName() );
        dataMap.put( "cmtYn", StringUtil.parseUseYn(dataBean.getCmtYn()) );
        dataMap.put( "inCmtYn", StringUtil.parseUseYn(dataBean.getInCmtYn()) );
        dataMap.put( "openYn", StringUtil.parseUseYn(dataBean.getOpenYn()) );
        dataMap.put( "privateYn", StringUtil.parseUseYn(dataBean.getPrivateYn()) );
        dataMap.put( "deadlineYn", StringUtil.parseUseYn(dataBean.getDeadlineYn()) );
        dataMap.put( "exceedYn", StringUtil.parseUseYn(dataBean.getExceedYn()) );
        dataMap.put( "deadlineCnt", dataBean.getDeadlineCnt() );
        dataMap.put( "exceedCnt", dataBean.getExceedCnt() );
        dataMap.put( "useYn", StringUtil.parseUseYn(dataBean.getUseYn()) );
        dataMap.put( "regDt", dataBean.getRegDt() );
        dataMap.put( "modiDt", dataBean.getModiDt() );

        list.add(dataMap);
    }
    
    public List<Map<String, Object>> getList() {
        
        return list;
    }
}