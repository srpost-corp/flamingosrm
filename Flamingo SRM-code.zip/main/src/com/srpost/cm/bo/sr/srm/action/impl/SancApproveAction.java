package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.cm.bo.sr.srm.supporter.EncCntCalculator;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;

/**
 * SANC_APPROVE : 결재승인 - 결재자
 *
 * @author  finkle
 * @date    2014-12-09
 * @since   3.0
 */
public class SancApproveAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        String today = (String)transientVars.get("today");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());
        VocDivBean myDivBean = VocUtil.getMyVocDivBean(divList, ONE);
        List<VocSancBean> sancList = selectList("_vocSupport.listSanc", vocBean.getVocSeq());
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || divList.size() == 0 || StringUtil.isEmpty(sancList) || 
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                !(StringUtil.equals(orgBean.getMgrStatusCd(), MS_SANC)) ||
                !VocUtil.isSancer(sancList, loginBean.getMgrId()) ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * 최종 결재여부 판단
         */
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("vocSeq", vocBean.getVocSeq());
        paramMap.put("mgrId", loginBean.getMgrId());
        
        int lastSancOrderNo = selectOne("_vocAction.viewLastOrderNoForSanc", paramMap);
        int mySancOrderNo = selectOne("_vocAction.viewMyOrderNoForSanc", paramMap);
    
        boolean isLastSanction = lastSancOrderNo == mySancOrderNo;
        
        /*-------------------------
         * 워크플로우 실행
         */
        transientVars.put("isLastSanction", isLastSanction);
        
        executeWorkflow(transientVars, myDivBean.getWfId());

        /*-------------------------
         * VOC 수정
         */
        int affected = ONE;
        
        if (isLastSanction) {
            // 최종 결재일 경우에만 VOC 수정
            EncCntCalculator encCntCalculator = new EncCntCalculator();
            
            vocBean.setUserStatusCd(US_END);
            vocBean.setMgrStatusCd(MS_END);
            vocBean.setEndDt(today);
            vocBean.setEndCnt(encCntCalculator.calculateEndCnt(orgBean.getDivDt(), today));

            affected = update("_vocAction.updateVocForLastSanc", vocBean);
        }
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 수정
             */
            
            // 행위자 ENTRY 비활성화 수정
            update("_vocAction.updateEntryForce", new VocEntryBean(
                vocBean.getVocSeq(), loginBean.getMgrId(), AUTH_SANCER, ACT_INACTIVE));
            
            MgrBean nextMgrBean = null;
            
            // 최종 결재승인 시
            if (isLastSanction) {
                if (isLastSanction) {
                    // 기한요청 정보 존재 대비 용 접수자 ENTRY 초기화
                    update("_vocAction.updateEntryForReceiver", new VocEntryBean(
                            vocBean.getVocSeq(), null, AUTH_RECEIVER, ACT_WORKER));
                }
            }
            else {                
                // 다음 결재자 ENTRY 활성화 수정
                paramMap.put("orderNo", (mySancOrderNo + ONE));
                nextMgrBean = selectOne("_vocSupport.viewSancerByOrderNo", paramMap);
                
                update("_vocAction.updateEntryForce", new VocEntryBean(
                    vocBean.getVocSeq(), nextMgrBean.getMgrId(), AUTH_SANCER, ACT_ACTIVE));
            }
            
            /*-------------------------
             * DIV 수정
             */
            
            // 최종 결재승인 시
            if (isLastSanction) {
                VocDivBean divBean = new VocDivBean();
                divBean.setVocSeq(vocBean.getVocSeq());
                divBean.setOrderNo(myDivBean.getOrderNo());
                divBean.setMgrStatusCd(vocBean.getMgrStatusCd());
                /*--------------------------------
                 * endCnt는 결재 상신 시 저장됨
                 *--------------------------------
                divBean.setEndCnt(vocBean.getEndCnt());
                */
                divBean.setEndDt(today);
                divBean.setSnbkReqDt("-1");
                
                update("_vocAction.updateDiv", divBean);
                
                if (StringUtil.isNotEmpty(myDivBean.getExtReqDt())) {
                    update("_vocAction.updateVocDivForExtension", divBean);
                }
                
                // 기한연장 요청정보 삭제
                delete("_vocAction.deleteVocExtDt", vocBean.getVocSeq());
            }

            /*-------------------------
             * SANC 수정
             */
            VocSancBean sancBean = new VocSancBean();
            sancBean.setVocSeq(vocBean.getVocSeq());
            sancBean.setOrderNo(mySancOrderNo);
            sancBean.setStatusNm(SANC_APPROVE);
            sancBean.setSancDt(today);
            
            update("_vocAction.updateSanc", sancBean);
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>결재승인</strong>");
            if (isLastSanction) {
                logContents.append(" : 최종결재");
            }
            else {
                logContents.append(" : 중간결재 (다음 결재자 : " + nextMgrBean.getMgrNm() + ")");
            }
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            if (isLastSanction)
                logBean.setActionCd(__ACTION_SANC_APPR_FIN__);
            else
                logBean.setActionCd(ACTION_SANC_APPROVE);
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 다음 결재자 or 고객
             */
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            
            if (isLastSanction) {
                // 고객
                alimMap.setActionCd(ACTION_DEAL);
                alimMap.setMgrBean((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getWriterId()));
            }
            else {
                // 다음 결재자
                alimMap.setActionCd(__ACTION_SANC_NEXT__);
                alimMap.addMgr((MgrBean)selectOne("_mgr.view", nextMgrBean.getMgrId()));
            }
            
            executeAlim(alimMap);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 상신자
             */
            alimMap.setMgrBean(null);
            alimMap.getMgrList().clear();
            alimMap.addMgr((MgrBean)selectOne("_mgr.view", orgBean.getReporterId()));
            
            if (isLastSanction) {
                alimMap.setActionCd(__ACTION_SANC_APPR_FIN__);
            }
            else {
                alimMap.setActionCd(ACTION_SANC_APPROVE);
            }
            executeAlim(alimMap);
        }
    }
}
