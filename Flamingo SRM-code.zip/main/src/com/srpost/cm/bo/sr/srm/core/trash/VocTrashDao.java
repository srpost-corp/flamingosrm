package com.srpost.cm.bo.sr.srm.core.trash;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.base.file.FileDao;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocExcelRowHandler;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.salmon.bean.BasePagerBean;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.crypto.SalmonCrypto;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 휴지통 DAO
 *
 * @author  finkle
 * @date    2014-12-12
 * @since   2.0
 */
@Repository
public class VocTrashDao extends EgovAbstractMapper {

    @Resource
    SalmonCrypto salmonCtypto;
    @Resource
    FileDao fileDao;

    public BasePagerBean list(VocListBean bean) {
        
        Map<String, Object> parameterMap = VocTrashUtil.getParameterMap(bean);

        List<VocBean> dataList = selectList("_vocTrash.list", parameterMap);
        int totalCount = (Integer)selectOne("_vocTrash.listCount", parameterMap);

        return new BasePagerBean(dataList, totalCount, bean);
    }
    
    public List<Map<String, Object>> listExcel(VocListBean bean) {
        
        Map<String, Object> parameterMap = VocTrashUtil.getParameterMap(bean);
        
        VocExcelRowHandler rowHandler = new VocExcelRowHandler(salmonCtypto);
        
        if ( StringUtil.equals(bean.getXlsScope(), VocBean.SCOPE_TOTAL)) {
            getSqlSession().select("_vocExcel.listTrashAll", parameterMap, rowHandler);
        }
        else {
            getSqlSession().select("_vocExcel.listTrash", parameterMap, rowHandler);
        }
        
        return rowHandler.getList();
    }
    
    public VocTrashBean view(VocTrashBean bean) {
        
        VocTrashBean dataBean = selectOne("_vocTrash.view", bean.getVocSeq());
        
        if (dataBean != null) {
            dataBean.setUserFileList( fileDao.list(dataBean.getUserFileSeq()) );
            /*--
            dataBean.setMgrFileList( fileDao.list(dataBean.getMgrFileSeq()) );
            --*/
            
            // 회신유형
            dataBean.setAlertNm(VocUtil.getAlertNms(dataBean.getAlertCds()));
        }
        return dataBean;
    }
}
