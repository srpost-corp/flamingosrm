package com.srpost.cm.bo.sr.srm.conf;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.Map;

import com.srpost.salmon.lang.StringUtil;

/**
 * 내부단 VOC설정 정보 Util
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   3.0
 */
public final class VocConfUtil {

    public static Map<String, Object> getParameterMap(VocConfBean bean) {
        
        Map<String, Object> parameterMap = bean.createPagerMap();
        /*
        if ( StringUtil.isNotEmpty(bean.getUseYn()) )
            parameterMap.put("useYn", bean.getUseYn());
        */
        return parameterMap;
    }
    
    public static void setNotNullValue(VocConfBean bean) {
        
        if ( StringUtil.isEmpty(bean.getUseYn()) )
            bean.setUseYn(Y);
    }
}
