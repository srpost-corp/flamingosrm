package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.Map;

import jodd.util.StringUtil;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocConstant;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;

/**
 * RECEIVE : 접수 - 접수자
 *
 * @author  finkle
 * @date    2014-12-02
 * @since   3.0
 */
public class ReceiveAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        String today = (String)transientVars.get("today");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.view(vocBean.getVocSeq());
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || 
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                (!StringUtil.equals(VocConstant.MS_READY, orgBean.getMgrStatusCd())) ||
                orgBean.getVocCd() != vocBean.getVocCd() ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * VOC 수정
         */        
        VocUtil.setNotNullValue(vocBean);
        
        vocBean.setRcvNo(rcvNoGenerator.create(vocBean.getVocSeq()));
        vocBean.setRcvId(loginBean.getMgrId());
        vocBean.setRcvDt(today);
        vocBean.setUserStatusCd(US_RECEIVE);
        vocBean.setMgrStatusCd(MS_RECEIVE);
        if (!StringUtil.equals(vocBean.getTypeCd(), TYPE_CMPLN_CD)) {
            vocBean.setCmplnCd(EMPTY);
        }
        
        int affected = update("_vocAction.updateVocForReceive", vocBean);
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 수정
             */
            // 행위자 제외한 잔여 ENTRY 비활성화 수정
            update("_vocAction.updateEntryExceptMe", 
                new VocEntryBean(vocBean.getVocSeq(), loginBean.getMgrId(), AUTH_RECEIVER, ACT_INACTIVE));
            
            /*-------------------------
             * DIV 등록
             */
            
            // 주무부서 DIV 수정
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setOrderNo(ONE);
            divBean.setMgrStatusCd(MS_RECEIVE);
            divBean.setSnbkReqDt("-1");
            divBean.setEndCnt(-1L);
            
            update("_vocAction.updateDiv", divBean);
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>접수</strong>");
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 고객
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            alimMap.setMgrBean((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getWriterId()));
            
            executeAlim(alimMap);
        }
    }
}
