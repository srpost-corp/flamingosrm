package com.srpost.cm.bo.sr.srm.conf;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC설정 서비스 구현체
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
@Service
public class VocConfServiceImpl extends EgovAbstractServiceImpl implements IVocConfService {

    @Resource
    VocConfDao dao;

    @Override
    public BasePagerBean list(VocConfBean bean) {
        
        return dao.list(bean);
    }
    
    @Override
    public List<Map<String, Object>> listExcel(VocConfBean bean) {
        
        return dao.listExcel(bean);
    }

    @Override
    public VocConfBean view(VocConfBean bean) {
        
        return dao.view(bean);
    }

    @Override
    public int insertAction(VocConfBean bean, String[] mgrDatas) {
        
        return dao.insertAction(bean, mgrDatas);
    }

    @Override
    public int updateAction(VocConfBean bean, String[] mgrDatas) {
        
        return dao.updateAction(bean, mgrDatas);
    }

    @Override
    public int deleteAction(VocConfBean bean) {
        
        return dao.deleteAction(bean);
    }
    
    @Override
    public List<VocConfBean> listCache() {
     
        return dao.listCache();
    }
}
