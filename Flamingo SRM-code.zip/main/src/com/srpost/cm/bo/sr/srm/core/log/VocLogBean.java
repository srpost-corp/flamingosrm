package com.srpost.cm.bo.sr.srm.core.log;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 내부단 VOC 로그 정보 Bean
 *
 * @author  finkle
 * @date    2014-12-01
 * @since   2.0
 */
@Alias("vocLogBean")
@SuppressWarnings("serial")
public class VocLogBean extends BaseBean {

    /** VOC_일련번호 */
    private Integer vocSeq;
    /** 정렬_순서 */
    private Integer orderNo;
    /** 액션_코드 */
    private String actionCd;
    /** 직원_ID */
    private String mgrId;
    /** 직원_이름 */
    private String mgrNm;
    /** 대리인_아이디 */
    private String agencyId;
    /** 대리인_명 */
    private String agencyNm;
    /** 로그_내용 */
    private String logContents;
    /** 등록_일시 */
    private String regDt;
    
    
    public Integer getVocSeq() {
        return vocSeq;
    }
    public void setVocSeq(Integer vocSeq) {
        this.vocSeq = vocSeq;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getMgrNm() {
        return mgrNm;
    }
    public void setMgrNm(String mgrNm) {
        this.mgrNm = mgrNm;
    }
    public String getLogContents() {
        return logContents;
    }
    public void setLogContents(String logContents) {
        this.logContents = logContents;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
    public String getAgencyId() {
        return agencyId;
    }
    public void setAgencyId(String agencyId) {
        this.agencyId = agencyId;
    }
    public String getAgencyNm() {
        return agencyNm;
    }
    public void setAgencyNm(String agencyNm) {
        this.agencyNm = agencyNm;
    }
    public String getActionCd() {
        return actionCd;
    }
    public void setActionCd(String actionCd) {
        this.actionCd = actionCd;
    }
}
