package com.srpost.cm.bo.sr.srm.core;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;
import com.srpost.salmon.bean.BaseFileBean;

/**
 * 내부단 VOC 분배 정보 Bean
 *
 * @author  finkle
 * @date    2014-12-01
 * @since   2.0
 */
@Alias("vocDivBean")
@SuppressWarnings("serial")
public class VocDivBean extends BaseBean {

    /** 첨부파일 목록 */
    private List<BaseFileBean> fileList;
    
    /** VOC_일련번호 */
    private Integer vocSeq;
    /** DIV_정렬순서 */
    private Integer orderNo;
    /** 워크플로우_ID */
    private Long wfId;
    /** 처리상태_코드 */
    private String mgrStatusCd;
    /** 처리상태_이름 */
    private String mgrStatusNm;
    /** 주무부서_여부 */
    private String masterYn;
    /** 부서_코드 */
    private String deptCd;
    /** 부서_이름 */
    private String deptNm;
    /** 직원_ID */
    private String mgrId;
    /** 직원_이름 */
    private String mgrNm;
    /** 답변 */
    private String reply;
    /** 첨부파일_일련번호 */
    private Integer fileSeq = -1;
    /** 분배_일시 */
    private String divDt;
    /** 지정_일시 */
    private String asnDt;
    /** 답변_일시 */
    private String rplDt;
    /** 종료_일시 */
    private String endDt;
    /** 답변_소요기간 */
    private Long endCnt;
    /** 반송_일시 */
    private String snbkReqDt;
    /** 기한연장 요청_일시 */
    private String extReqDt;
    
    
    public List<BaseFileBean> getFileList() {
        return fileList;
    }
    public void setFileList(List<BaseFileBean> fileList) {
        this.fileList = fileList;
    }
    public Integer getVocSeq() {
        return vocSeq;
    }
    public void setVocSeq(Integer vocSeq) {
        this.vocSeq = vocSeq;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public String getMasterYn() {
        return masterYn;
    }
    public void setMasterYn(String masterYn) {
        this.masterYn = masterYn;
    }
    public String getDeptCd() {
        return deptCd;
    }
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }
    public String getDeptNm() {
        return deptNm;
    }
    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getMgrNm() {
        return mgrNm;
    }
    public void setMgrNm(String mgrNm) {
        this.mgrNm = mgrNm;
    }
    public String getReply() {
        return reply;
    }
    public void setReply(String reply) {
        this.reply = reply;
    }
    public Integer getFileSeq() {
        return fileSeq;
    }
    public void setFileSeq(Integer fileSeq) {
        this.fileSeq = fileSeq;
    }
    public String getDivDt() {
        return divDt;
    }
    public void setDivDt(String divDt) {
        this.divDt = divDt;
    }
    public String getAsnDt() {
        return asnDt;
    }
    public void setAsnDt(String asnDt) {
        this.asnDt = asnDt;
    }
    public String getRplDt() {
        return rplDt;
    }
    public void setRplDt(String rplDt) {
        this.rplDt = rplDt;
    }
    public String getEndDt() {
        return endDt;
    }
    public void setEndDt(String endDt) {
        this.endDt = endDt;
    }
    public Long getEndCnt() {
        return endCnt;
    }
    public void setEndCnt(Long endCnt) {
        this.endCnt = endCnt;
    }
    public String getMgrStatusCd() {
        return mgrStatusCd;
    }
    public void setMgrStatusCd(String mgrStatusCd) {
        this.mgrStatusCd = mgrStatusCd;
    }
    public String getMgrStatusNm() {
        return mgrStatusNm;
    }
    public void setMgrStatusNm(String mgrStatusNm) {
        this.mgrStatusNm = mgrStatusNm;
    }
    public Long getWfId() {
        return wfId;
    }
    public void setWfId(Long wfId) {
        this.wfId = wfId;
    }
    public String getSnbkReqDt() {
        return snbkReqDt;
    }
    public void setSnbkReqDt(String snbkReqDt) {
        this.snbkReqDt = snbkReqDt;
    }
    public String getExtReqDt() {
        return extReqDt;
    }
    public void setExtReqDt(String extReqDt) {
        this.extReqDt = extReqDt;
    }
}
