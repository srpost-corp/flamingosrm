package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;

/**
 * SANC_CANCEL : 결재취소 - 분배자/처리자
 *
 * @author  finkle
 * @date    2014-12-09
 * @since   3.0
 */
public class SancCancelAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();

        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());
        VocDivBean myDivBean = VocUtil.getMyVocDivBean(divList, ONE);
        List<VocSancBean> sancList = selectList("_vocSupport.listSanc", vocBean.getVocSeq());
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || divList.size() == 0 || StringUtil.isEmpty(sancList) || 
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                !(StringUtil.equals(orgBean.getMgrStatusCd(), MS_SANC)) ||
                VocUtil.isApproveOnceInSanc(sancList) ) {
            throw new VocAlreadyExecuteException();
        }

        /*-------------------------
         * 상신자 획득 (분배자 or 처리자)
         * 처리자 획득 선 시도 후 없으면 분배자에서 획득
         */
        VocEntryBean entryBean = new VocEntryBean();
        entryBean.setVocSeq(vocBean.getVocSeq());
        entryBean.setActivate(ACT_REPORTER);
        entryBean.setAuthCd(AUTH_DEALER);
        
        String reporterId = selectOne("_vocSupport.viewMgrIdFromEntry", entryBean);
        boolean iAmDivider = StringUtil.isEmpty(reporterId);
        
        if (iAmDivider) {
            entryBean.setAuthCd(AUTH_DIVIDER);
            reporterId = selectOne("_vocSupport.viewMgrIdFromEntry", entryBean);
        }
        
        /*-------------------------
         * 워크플로우 실행
         */
        transientVars.put("isDivider", iAmDivider);
        
        executeWorkflow(transientVars, myDivBean.getWfId());

        /*-------------------------
         * VOC 수정
         */
        vocBean.setMgrStatusCd(iAmDivider ? MS_DIVIDE : MS_ASSIGN);
        vocBean.setSancYn(N);
        
        int affected = update("_vocAction.updateVocForSancCancel", vocBean);
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 수정
             */
            
            // 결재자 ENTRY 삭제
            entryBean = new VocEntryBean();
            entryBean.setVocSeq(vocBean.getVocSeq());
            entryBean.setAuthCd(AUTH_SANCER);
            
            delete("_vocAction.deleteEntry", entryBean);
            
            // 결재취소 행위자 ENTRY 활성화 수정
            update("_vocAction.updateEntryForce", new VocEntryBean(
                    vocBean.getVocSeq(), loginBean.getMgrId(), (iAmDivider ? AUTH_DIVIDER : AUTH_DEALER), ACT_ACTIVE));            
            
            /*-------------------------
             * DIV 수정
             */
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setOrderNo(myDivBean.getOrderNo());
            divBean.setMgrStatusCd(vocBean.getMgrStatusCd());
            divBean.setSnbkReqDt("-1");
            
            update("_vocAction.updateDiv", divBean);
            
            /*-------------------------
             * SANC 삭제
             */
            delete("_vocAction.deleteAllSanc", vocBean.getVocSeq());
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder(); 
            logContents.append("<strong>결재취소</strong>");
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 결재자
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            
            for (VocSancBean item : sancList) {
                // 결재대기 결재자에게 알림 발송
                if ( StringUtil.equals(item.getStatusNm(), SANC_READY) )
                    alimMap.addMgr((MgrBean)selectOne("_mgr.view", item.getMgrId()));
            }
            
            executeAlim(alimMap);
        }
    }
}
