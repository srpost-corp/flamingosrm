package com.srpost.cm.bo.sr.srm.core.alim;

import java.util.List;

/**
 * 내부단 VOC 알림 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-12-16
 * @since   2.0
 */
public interface IVocAlimService {

    List<VocAlimBean> list(VocAlimBean bean);

    VocAlimBean view(VocAlimBean bean);
    
    int insertAction(VocAlimBean bean);
}
