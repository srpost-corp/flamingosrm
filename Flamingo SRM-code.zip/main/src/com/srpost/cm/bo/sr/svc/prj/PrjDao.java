package com.srpost.cm.bo.sr.svc.prj;

import static com.srpost.salmon.constant.StringPool.ONE;
import static com.srpost.salmon.constant.StringPool.ZERO;

import java.lang.reflect.Array;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.bean.BasePagerBean;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.egov.ISalmonSeqGenerator;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 프로젝트 DAO
 *
 * @author  Bella
 * @date    2017-04-18
 * @since   3.0
 */
@Repository
public class PrjDao extends EgovAbstractMapper {
    
    @Resource(name = "prjSeqGenerator")
    ISalmonSeqGenerator seqGenerator;
    
    public BasePagerBean list(PrjBean bean) {
        
        Map<String, Object> parameterMap = PrjUtil.getParameterMap(bean);
        
        List<PrjBean> dataList = selectList("_prj.list", parameterMap);
        int totalCount = (Integer)selectOne("_prj.listCount", parameterMap);
        
        return new BasePagerBean(dataList, totalCount, bean);
    }
    
    public List<Map<String, Object>> listExcel(PrjBean bean) {
        
        Map<String, Object> parameterMap = PrjUtil.getParameterMap(bean);
        
        PrjExcelRowHandler rowHandler = new PrjExcelRowHandler();
        
        if ( StringUtil.equals(bean.getXlsScope(), PrjBean.SCOPE_TOTAL) ) {
            getSqlSession().select("_prj.listExcel", parameterMap, rowHandler);
        }
        else {
            getSqlSession().select("_prj.list", parameterMap, rowHandler);
        }
        
        List<Map<String, Object>> dataList = rowHandler.getList();
        
        return dataList;
    }
    
    public PrjBean view(PrjBean bean) {
        
        return selectOne("_prj.view", bean);
    }
    
    public synchronized int insertAction(PrjBean bean) {
        
        PrjUtil.setNotNullValue(bean);
        bean.setPrjSeq(seqGenerator.getNextInteger());
        
        return insert("_prj.insert", bean);
    }
    
    public int updateAction(PrjBean bean) {
        
        PrjUtil.setNotNullValue(bean);
        
        return update("_prj.update", bean);
    }
    
    public int deleteAction(PrjBean bean) {
        
        if ( StringUtil.isNotEmpty(bean.getPrjSeqs()) ) {
            
            int affected = delete("_prj.delete", bean);
            if ( affected == Array.getLength(bean.getPrjSeqs()) ) {
                return ONE;
            }
        }
        return ZERO;
    }

}
