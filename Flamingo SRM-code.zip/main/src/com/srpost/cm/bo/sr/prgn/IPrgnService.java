package com.srpost.cm.bo.sr.prgn;

import java.util.List;
import java.util.Map;

import com.srpost.salmon.bean.BasePagerBean;

/**
 * 내부단 모범답안 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-11-21
 * @since   2.0
 */
public interface IPrgnService {

    BasePagerBean list(PrgnBean bean);
    
    List<Map<String, Object>> listExcel(PrgnBean bean);
    
    PrgnBean view(PrgnBean bean);
    
    int insertAction(PrgnBean bean);
    
    int updateAction(PrgnBean bean);
    
    int deleteAction(PrgnBean bean);
    
    List<PrgnBean> listAll(PrgnBean bean);
    
    String viewOne(PrgnBean bean);
}
