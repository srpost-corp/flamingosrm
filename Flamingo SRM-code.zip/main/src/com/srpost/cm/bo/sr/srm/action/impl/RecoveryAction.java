package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.conf.VocConfBean;
import com.srpost.cm.bo.sr.srm.conf.VocReceiverBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;

/**
 * RECOVERY : 회수 - 접수자
 *
 * @author  finkle
 * @date    2014-12-09
 * @since   3.0
 */
public class RecoveryAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();
        String reason = (String)parameterMap.get("reason");
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();        
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());
        VocDivBean myDivBean = VocUtil.getMyVocDivBean(divList, ONE);
        boolean isComplex = StringUtil.equals(orgBean.getKindCd(), KND_COMPLEX);
                
        /*-------------------------
         * 유효성 체크
         * 일반 VOC : 분배 or 처리자지정
         * 복합 VOC : 접수
         */
        if ( orgBean == null || divList.size() == 0 ||
                StringUtil.equals(Y, orgBean.getDelYn()) ||
                !(!isComplex && (StringUtil.equals(orgBean.getMgrStatusCd(), MS_DIVIDE) || StringUtil.equals(orgBean.getMgrStatusCd(), MS_ASSIGN)) ||
                        isComplex && StringUtil.equals(myDivBean.getMgrStatusCd(), MS_RECEIVE)) ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * 워크플로우 실행
         */
        executeWorkflow(transientVars, myDivBean.getWfId());
        
        /*-------------------------
         * VOC 수정
         */
        
        // 고객단 처리상태는 변경하지 않음
        vocBean.setMgrStatusCd(MS_RECEIVE);
        
        int affected = update("_vocAction.updateVocForRecovery", vocBean);
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * 활성화 ENTRY 담당자 정보 조회 (알림발송대상)
             */
            VocEntryBean entryBean = new VocEntryBean();
            entryBean.setVocSeq(vocBean.getVocSeq());
            entryBean.setActivate(ACT_ACTIVE);
            
            List<String> activateMgrIds = selectList("_vocSupport.viewMgrIdFromEntry", entryBean);
            
            if ( StringUtil.isNotEmpty(activateMgrIds) ) {
                
                for ( String mgrId : activateMgrIds ) {
                    
                    if ( !StringUtil.equals(mgrId, loginBean.getMgrId()) ) {
                        alimMap.addMgr((MgrBean)selectOne("_mgr.view", mgrId));
                    }
                }
            }
            
            /*-------------------------
             * ENTRY 삭제
             */
            delete("_vocAction.deleteAllEntry", vocBean.getVocSeq());
            
            /*-------------------------
             * ENTRY 등록
             */
            
            // 접수자 ENTRY 비활성화 등록
            VocConfBean confBean = VocUtil.getConfBean(vocBean.getVocCd());

            List<VocReceiverBean> receiverList = confBean.getReceiverList();
            for (VocReceiverBean receiverBean : receiverList) {
                
                insert("_vocAction.insertEntry", new VocEntryBean(
                    vocBean.getVocSeq(), receiverBean.getMgrId(), AUTH_RECEIVER, ACT_INACTIVE));
            }

            // 행위자 ENTRY 활성화 수정
            update("_vocAction.updateEntryForce", new VocEntryBean(
                vocBean.getVocSeq(), loginBean.getMgrId(), AUTH_RECEIVER, ACT_ACTIVE));
            
            /*-------------------------
             * DIV 수정, 삭제
             */
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setOrderNo(ONE);
            divBean.setMgrStatusCd(vocBean.getMgrStatusCd());
            
            insert("_vocAction.updateDivForRecovery", divBean);
            
            // 협조부서 정보 삭제
            delete("_vocAction.deleteDivForRecovery", divBean);

            // 결재정보 삭제
            delete("_vocAction.deleteAllSanc", vocBean.getVocSeq());
            
            // 기한연장 요청정보 삭제
            delete("_vocAction.deleteVocExtDt", vocBean.getVocSeq());
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder(); 
            logContents.append("<strong>회수</strong>");
            logContents.append("<br/>회수사유 : " + reason);
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 분배자 OR 접수자
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            
            //사유
            alimMap.setReason(reason);
            
            executeAlim(alimMap);
        }
    }
}
