package com.srpost.cm.bo.sr.srm.core.incomment;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.base.file.FileDao;
import com.srpost.salmon.lang.StringUtil;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 내부의견글 DAO
 *
 * @author  finkle
 * @date    2015-01-16
 * @since   2.0
 */
@Repository
public class VocInCmtDao extends EgovAbstractMapper {

    @Resource
    FileDao fileDao;
    
    
    public List<VocInCmtBean> list(VocInCmtBean bean) {

        List<VocInCmtBean> dataList = selectList("_vocInCmt.list", bean);
        for (VocInCmtBean item : dataList) {
            if (item.getFileSeq() != null && item.getFileSeq() != -1) {
                item.setFileList( fileDao.list(item.getFileSeq()) );
            }
        }
        return dataList;
    }
    
    public VocInCmtBean view(VocInCmtBean bean) {

        VocInCmtBean dataBean = selectOne("_vocInCmt.view", bean);
        
        if (dataBean != null) {
            dataBean.setFileList( fileDao.list(dataBean.getFileSeq()) );
        }
        
        return dataBean;
    }
    
    public int insertAction(VocInCmtBean bean) {

        VocInCmtUtil.setNotNullValue(bean);

        bean.setRefSeq((Integer)selectOne("_vocInCmt.viewMinRefSeq", bean));
        bean.setDepth(ZERO);
        bean.setOrderNo(ZERO);
        bean.setFileSeq( fileDao.insertAction(bean.getFileList()) );
        
        return insert("_vocInCmt.insert", bean);
    }

    public int updateAction(VocInCmtBean bean) {

        VocInCmtUtil.setNotNullValue(bean);

        if ( StringUtil.isNotEmpty(bean.getFileIds()) ) {
            fileDao.deleteAction(bean.getFileSeq(), bean.getFileIds());
        }
        
        bean.setFileSeq( fileDao.insertAction(bean.getFileList(), bean.getFileSeq()) );
        
        return update("_vocInCmt.update", bean);
    }
    
    public int replyAction(VocInCmtBean bean) {

        VocInCmtUtil.setNotNullValue(bean);

        bean.setFileSeq( fileDao.insertAction(bean.getFileList()) );
        
        // 상위 자료의 계층정보 설정
        VocInCmtBean parentBean = (VocInCmtBean)selectOne("_vocInCmt.viewParent", bean);
        bean.setRefSeq(parentBean.getRefSeq());
        bean.setDepth(parentBean.getDepth() + ONE);
        bean.setOrderNo(parentBean.getOrderNo() + ONE);
        
        // 반 업데이트를 위한 대상 자료 추출
        List<VocInCmtBean> relativeList = selectList("_vocInCmt.relativeList", bean);
        for (VocInCmtBean item : relativeList) {
            if ( bean.getDepth() > item.getDepth() )
                break;
            else
                bean.setOrderNo(item.getOrderNo() + ONE);
        }
        
        // 반 업데이트
        update("_vocInCmt.updateRelativeList", bean);
        
        return insert("_vocInCmt.insert", bean);
    }

    public int deleteAction(VocInCmtBean bean) {

        VocInCmtBean dataBean = view(bean);
        dataBean.setOrderNo(dataBean.getOrderNo() + ONE);
        dataBean.setDepth(dataBean.getDepth() + ONE);
        
        Integer childCount = selectOne("_vocInCmt.childCount", dataBean);
        int affected = ZERO;
        
        if (childCount > ZERO) {
            affected = delete("_vocInCmt.updateForDelete", bean);
        }
        else {
            affected = delete("_vocInCmt.delete", bean);
        }
        
        if (affected > ZERO) {
            fileDao.deleteAction(dataBean.getFileSeq());
        }
        
        return affected;
    }
}