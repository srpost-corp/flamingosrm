package com.srpost.cm.bo.sr.srm.tag.ui;

import static com.srpost.salmon.constant.StringPool.*;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class EndCntTag extends SimpleTagSupport {

	private long endCnt = -1L;

	public void doTag() throws JspException, IOException {
		
		JspWriter writer = getJspContext().getOut();
		
		if (endCnt == -1L) {
			writer.write(EMPTY); return;
		}
		
		StringBuilder html = new StringBuilder();
		
		long diff = endCnt * ONE_MINUTE;
		
		long elapsedDays = diff / ONE_DAY;
		
		diff = diff % ONE_DAY;
		long elapsedHours = diff / ONE_HOUR;
		
		diff = diff % ONE_HOUR;
		long elapsedMinutes = diff / ONE_MINUTE;

		if (elapsedDays > ZERO) {
			html.append("<strong>" + elapsedDays + "</strong>일 ");
		}
		if (elapsedHours > ZERO) {
			html.append("<strong>" + elapsedHours + "</strong>시간 ");
		}
		if (elapsedMinutes > ZERO) {
			html.append("<strong>" + elapsedMinutes + "</strong>분");
		}
		/*--
		if (elapsedSeconds > 0) {
			html.append("<b>" + elapsedSeconds + "</b>초 ");
		}
		
		if (html.length() == ZERO) {	        
		    diff = diff % ONE_MINUTE;
	        long elapsedSeconds = diff / ONE_SECOND;	        
            html.append("<strong>" + elapsedSeconds + "</strong>초 ");
		} --*/

		if (html.length() == ZERO) {
			html.append("<strong>즉시</strong>");
		}
		
        writer.write(html.toString());
	}
	
	public long getEndCnt() {
    	return endCnt;
    }
	public void setEndCnt(long endCnt) {
    	this.endCnt = endCnt;
    }
}
