package com.srpost.cm.bo.sr.srm.core.alim;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;

import static com.srpost.salmon.constant.StringPool.*;
import jodd.util.StringUtil;

/**
 * VOC 알림 메시지 Util
 *
 * @author  finkle
 * @date    2015-01-29
 * @since   3.0
 */
public class VocAlimUtil {

    public static String getTitle(String action) {
        return getTitle(action, false);
    }
    
    public static String getTitle(String action, boolean isUser) {
        
        if (StringUtil.equals(action, ACTION_OFF_INSERT)) {
            
            if (isUser) 
                return "신청하신 VOC가 가접수 되었습니다.";
            else 
                return "신규 VOC가 등록 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_OFF_SIMPLE_INSERT)) {
            
            if (isUser) 
                return "신청하신 VOC가 처리완료 되었습니다.";
            else 
                return EMPTY;
        }
        else if (StringUtil.equals(action, ACTION_OFF_DIVIDE_INSERT) ||
                StringUtil.equals(action, ACTION_DIVIDE)) {
            
            if (isUser) 
                return "신청하신 VOC가 부서로 배분 되었습니다.";
            else
                return "VOC 처리부서로 배분 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_OFF_ASSIGN_INSERT) ||
                StringUtil.equals(action, ACTION_DIRECT_ASSIGN) || 
                StringUtil.equals(action, ACTION_ASSIGN)) {
            
            if (isUser) 
                return EMPTY;
            else
                return "VOC 처리 담당자로 지정 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_DIRECT_DEAL)) {
            
            if (isUser) 
                return "신청하신 VOC가 처리완료 되었습니다.";
            else 
                return EMPTY;
        }
        else if (StringUtil.equals(action, ACTION_RECEIVE)) {
            
            if (isUser) 
                return "신청하신 VOC가 접수 되었습니다.";
            else 
                return EMPTY;
        }
        else if (StringUtil.equals(action, ACTION_TRANSFER)) {
            
            if (isUser) 
                return "신청하신 VOC가 이첩 처리 되었습니다.";
            else 
                return "신규 VOC가 이첩 수신 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_TRASH)) {
            
            if (isUser) 
                return "신청하신 VOC가 삭제 처리 되었습니다.";
            else 
                return EMPTY;
        }
        else if (StringUtil.equals(action, ACTION_URGE)) {
            
            if (isUser) 
                return EMPTY;
            else 
                return "VOC 처리 독촉 요청이 수신 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_EXTENSION)) {
            
            if (isUser) 
                return "VOC 처리기한이 연장 되었습니다.";
            else 
                return "VOC 처리기한이 연장요청이 승인되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_REDIVIDE)) {
            
            if (isUser) 
                return "VOC 처리부서가 변경되었습니다.";
            else 
                return "VOC 처리부서로 배분 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_UPDATE_REPLY)) {
            
            if (isUser) 
                return "VOC 처리(답변) 내용이 변경되었습니다.";
            else 
                return "VOC 처리(답변) 내용이 변경되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_DEAL)) {
            
            // TODO : 복합VOC, 결재 여부 체크
        }
        else if (StringUtil.equals(action, ACTION_SEND_BACK)) {
            
            if (isUser) 
                return EMPTY;
            else 
                return "VOC가 반송 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_MOVE)) {

        }
        else if (StringUtil.equals(action, ACTION_EXTENSION_REQ)) {
            
            if (isUser) 
                return EMPTY;
            else 
                return "VOC 처리기한 연장요청이 수신 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_SANC_CANCEL)) {
            
            if (isUser) 
                return EMPTY;
            else 
                return "VOC 결재가 상신자에 의해 취소 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_SANC_APPROVE)) {
            
            // TODO : 중간결재, 최종결재 여부 체크
            
            if (isUser) 
                return EMPTY;
            else 
                return "VOC 결재가 승인 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_SANC_DENY)) {

            if (isUser) 
                return EMPTY;
            else 
                return "VOC 결재가 반려 되었습니다.";
        }
        else if (StringUtil.equals(action, ACTION_RECOVERY) ||
                StringUtil.equals(action, ACTION_RESTORE) || 
                StringUtil.equals(action, ACTION_FORCE_DELETE)) {

            return EMPTY;
        }
        
        return EMPTY;
    }
}
