package com.srpost.cm.bo.sr.srm.core.tags;

import java.util.List;

/**
 * 내부단 VOC TAG 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-12-19
 * @since   2.0
 */
public interface IVocTagsService {

    List<String> list(Integer vocSeq);
    
    int insertAction(Integer vocSeq, String[] tags);
    
    List<String> listSearch(String tag);
}
