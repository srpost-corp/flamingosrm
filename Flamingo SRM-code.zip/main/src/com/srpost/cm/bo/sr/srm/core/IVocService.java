package com.srpost.cm.bo.sr.srm.core;

import java.util.List;
import java.util.Map;

import com.srpost.salmon.bean.BasePagerBean;

/**
 * 내부단 VOC 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
public interface IVocService {

    BasePagerBean list(VocListBean bean);
    
    List<Map<String, Object>> listExcel(VocListBean bean);
    
    VocBean view(VocBean bean, boolean needUpdateReadCnt);  
    
    VocBean viewSimple(Integer vocSeq);
    
    String executeAction(VocBean bean) throws Exception; 
    
    Map<String, Integer> countMyEntryMap(VocEntryBean bean);
}
