package com.srpost.cm.bo.sr.srm.ctg;

import java.util.List;
import java.util.Map;

/**
 * 내부단 VOC분류 관리 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-11-20
 * @since   2.0
 */
public interface IVocCtgService {

    List<VocCtgBean> list(VocCtgBean bean);
    
    VocCtgBean view(VocCtgBean bean);

    Object insertAction(VocCtgBean bean);

    int updateAction(VocCtgBean bean);

    int deleteAction(VocCtgBean bean);
    
    List<VocCtgBean> listAll();
    
    Map<String, List<Object>> listByDepth();
}
