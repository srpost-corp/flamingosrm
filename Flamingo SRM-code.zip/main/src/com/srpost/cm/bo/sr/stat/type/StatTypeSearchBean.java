package com.srpost.cm.bo.sr.stat.type;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseListBean;

/**
 * 내부단 VOC 통계(유형별) 검색 Bean
 *
 * @author  finkle
 * @date    2014-12-29
 * @since   2.0
 */
@Alias("statTypeSearchBean")
@SuppressWarnings("serial")
public class StatTypeSearchBean extends BaseListBean {
    
    /** 엑셀변환 통계 데이터 */
    private List<String> xlsList;

    /** 통계 검색주기 코드 */
    private Integer termCd = StatTypeUtil.TERM_MONTH;
    /** 통계 구분 */
    private String statCd = StatTypeUtil.STAT_FROM;
    /** VOC_코드 */
    private Integer vocCd;
    /** 검색 시작일자 */
    private String startDd;
    /** 검색 종료일자 */
    private String endDd;
    /** 부서 코드 */
    private String deptCd;
    /** 협조부서 포함_여부 */
    private String supportYn = N;
    
    
    public Integer getVocCd() {
        return vocCd;
    }
    public void setVocCd(Integer vocCd) {
        this.vocCd = vocCd;
    }
    public String getStartDd() {
        return startDd;
    }
    public void setStartDd(String startDd) {
        this.startDd = startDd;
    }
    public String getEndDd() {
        return endDd;
    }
    public void setEndDd(String endDd) {
        this.endDd = endDd;
    }
    public String getDeptCd() {
        return deptCd;
    }
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }
    public String getSupportYn() {
        return supportYn;
    }
    public void setSupportYn(String supportYn) {
        this.supportYn = supportYn;
    }
    public Integer getTermCd() {
        return termCd;
    }
    public void setTermCd(Integer termCd) {
        this.termCd = termCd;
    }
    public String getStatCd() {
        return statCd;
    }
    public void setStatCd(String statCd) {
        this.statCd = statCd;
    }
    public List<String> getXlsList() {
        return xlsList;
    }
    public void setXlsList(List<String> xlsList) {
        this.xlsList = xlsList;
    }
}
