package com.srpost.cm.bo.sr.srm.core;

import com.srpost.salmon.bean.BaseListBean;

/**
 * 내부단 VOC 목록 표시용 Bean
 *
 * @author  finkle
 * @date    2014-12-03
 * @since   3.0
 */
@SuppressWarnings("serial")
public class VocListBean extends BaseListBean {

    /** 목록 구분 */
    private String type;
    /** 권한_코드 */
    private Integer authCd;
    /** VOC_코드 */
    private Integer vocCd;
    /** 처리상태_코드(내부) */
    private String mgrStatusCd;
    /** 처리상태_코드(외부) */
    private String userStatusCd;
    /** 종류_코드 */
    private String kindCd;
    /** 집단상담_여부 */
    private String manyYn;
    /** 반복상담_여부 */
    private String rptYn;
    /** 유형_코드 */
    private String typeCd;
    /** 유입경로_코드 */
    private String fromCd;
    /** 유입경로(채널)_코드 */
    private String fromChnlCd;
    /** 유입경로(대외기관)_코드 */
    private String fromOrgCd;
    /** 카테고리_코드1 */
    private String ctgCd1;
    /** 카테고리_코드2 */
    private String ctgCd2;
    /** 카테고리_코드3 */
    private String ctgCd3;
    /** 완료_코드 */
    private String endCd;
    /** 삭제_코드 */
    private String delCd;
    /** 부서_코드 */
    private String deptCd;
    /** 공개_여부 */
    private String openYn;
    /** 삭제_여부 */
    private String delYn;
    /** 스크랩_직원_ID */
    private String scrapId;
    
    
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public Integer getVocCd() {
        return vocCd;
    }
    public void setVocCd(Integer vocCd) {
        this.vocCd = vocCd;
    }
    public String getKindCd() {
        return kindCd;
    }
    public void setKindCd(String kindCd) {
        this.kindCd = kindCd;
    }
    public String getManyYn() {
        return manyYn;
    }
    public void setManyYn(String manyYn) {
        this.manyYn = manyYn;
    }
    public String getRptYn() {
        return rptYn;
    }
    public void setRptYn(String rptYn) {
        this.rptYn = rptYn;
    }
    public String getTypeCd() {
        return typeCd;
    }
    public void setTypeCd(String typeCd) {
        this.typeCd = typeCd;
    }
    public String getFromCd() {
        return fromCd;
    }
    public void setFromCd(String fromCd) {
        this.fromCd = fromCd;
    }
    public String getEndCd() {
        return endCd;
    }
    public void setEndCd(String endCd) {
        this.endCd = endCd;
    }
    public String getDelCd() {
        return delCd;
    }
    public void setDelCd(String delCd) {
        this.delCd = delCd;
    }
    public String getDeptCd() {
        return deptCd;
    }
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }
    public String getOpenYn() {
        return openYn;
    }
    public void setOpenYn(String openYn) {
        this.openYn = openYn;
    }
    public String getDelYn() {
        return delYn;
    }
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }
    public String getScrapId() {
        return scrapId;
    }
    public void setScrapId(String scrapId) {
        this.scrapId = scrapId;
    }
    public String getMgrStatusCd() {
        return mgrStatusCd;
    }
    public void setMgrStatusCd(String mgrStatusCd) {
        this.mgrStatusCd = mgrStatusCd;
    }
    public String getUserStatusCd() {
        return userStatusCd;
    }
    public void setUserStatusCd(String userStatusCd) {
        this.userStatusCd = userStatusCd;
    }
    public Integer getAuthCd() {
        return authCd;
    }
    public void setAuthCd(Integer authCd) {
        this.authCd = authCd;
    }
    public String getFromChnlCd() {
        return fromChnlCd;
    }
    public void setFromChnlCd(String fromChnlCd) {
        this.fromChnlCd = fromChnlCd;
    }
    public String getFromOrgCd() {
        return fromOrgCd;
    }
    public void setFromOrgCd(String fromOrgCd) {
        this.fromOrgCd = fromOrgCd;
    }
    public String getCtgCd1() {
        return ctgCd1;
    }
    public void setCtgCd1(String ctgCd1) {
        this.ctgCd1 = ctgCd1;
    }
    public String getCtgCd2() {
        return ctgCd2;
    }
    public void setCtgCd2(String ctgCd2) {
        this.ctgCd2 = ctgCd2;
    }
    public String getCtgCd3() {
        return ctgCd3;
    }
    public void setCtgCd3(String ctgCd3) {
        this.ctgCd3 = ctgCd3;
    }

}
