package com.srpost.cm.bo.sr.srm.core.tags;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC TAG 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-19
 * @since   2.0
 */
@Service
public class VocTagsServiceImpl extends EgovAbstractServiceImpl implements IVocTagsService {

    @Resource
    VocTagsDao dao;

    @Override
    public List<String> list(Integer vocSeq) {
        
        return dao.list(vocSeq);
    }

    @Override
    public int insertAction(Integer vocSeq, String[] tags) {
        
        return dao.insertAction(vocSeq, tags);
    }
    
    @Override
    public List<String> listSearch(String tag) {
        
        return dao.listSearch(tag);
    }
}
