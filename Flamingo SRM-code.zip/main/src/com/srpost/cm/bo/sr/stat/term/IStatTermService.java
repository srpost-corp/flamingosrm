package com.srpost.cm.bo.sr.stat.term;


/**
 * 내부단 VOC 통계(기간별) 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-12-24
 * @since   2.0
 */
public interface IStatTermService {

    StatTermBean year(Integer vocCd, Integer year);
    
    StatTermBean month(Integer vocCd, String startDd, String endDd);
    
    StatTermBean day(Integer vocCd, String startMonth);
    
    StatTermBean dow(Integer vocCd, String startDd, String endDd);
}
