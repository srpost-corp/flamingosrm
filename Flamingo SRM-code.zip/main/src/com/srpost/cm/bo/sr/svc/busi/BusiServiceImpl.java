package com.srpost.cm.bo.sr.svc.busi;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 사업자 서비스 구현체
 *
 * @author  Bella
 * @date    2017-04-18
 * @since   3.0
 */
@Service
public class BusiServiceImpl extends EgovAbstractServiceImpl implements IBusiService {

    @Resource
    BusiDao dao;
    
    @Override
    public BasePagerBean list(BusiBean bean) {
        
        return dao.list(bean);
    }

    @Override
    public List<Map<String, Object>> listExcel(BusiBean bean) {
        
        return dao.listExcel(bean);
    }

    @Override
    public BusiBean view(BusiBean bean) {
        
        return dao.view(bean);
    }

    @Override
    public int insertAction(BusiBean bean) {
        
        return dao.insertAction(bean);
    }

    @Override
    public int updateAction(BusiBean bean) {
        
        return dao.updateAction(bean);
    }

    @Override
    public int deleteAction(BusiBean bean) {
        
        return dao.deleteAction(bean);
    }

    @Override
    public List<BusiBean> listAll() {
        
        return dao.listAll();
    }

}
