package com.srpost.cm.bo.sr.srm.core.scrap;

import java.util.Map;

import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;

/**
 * 내부단 VOC 스크랩 Util
 *
 * @author  finkle
 * @date    2014-12-15
 * @since   3.0
 */
public class VocScrapUtil {

    public static Map<String, Object> getParameterMap(VocListBean bean) {
        
        Map<String, Object> parameterMap = bean.createPagerMap();
        
        VocUtil.setCommonParameterMap(bean, parameterMap);

        parameterMap.put("scrapId", bean.getScrapId());
 
        return parameterMap;
    }
}
