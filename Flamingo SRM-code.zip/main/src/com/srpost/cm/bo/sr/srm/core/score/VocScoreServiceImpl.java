package com.srpost.cm.bo.sr.srm.core.score;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.sr.srm.core.VocBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service
public class VocScoreServiceImpl extends EgovAbstractServiceImpl implements IVocScoreService {

    @Resource
    VocScoreDao dao;
    
    public List<VocScoreBean> list(VocBean vocBean) {
        
        return dao.list(vocBean);
    } 

}
