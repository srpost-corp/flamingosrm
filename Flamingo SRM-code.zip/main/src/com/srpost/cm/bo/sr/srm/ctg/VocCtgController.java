package com.srpost.cm.bo.sr.srm.ctg;

import static com.srpost.salmon.constant.StringPool.*;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.salmon.constant.Constant;
import com.srpost.salmon.constant.Message;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 내부단 VOC분류 관리 컨트롤러
 *
 * @author  finkle
 * @date    2014-11-20
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/srm/ctg")
public class VocCtgController extends BaseController {

    @Resource
    IVocCtgService service;

    /**
     * VOC분류 메인
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index() {
    }
    
    /**
     * VOC분류 TREE 목록
     */
    @RequestMapping(value="j_list.do", method=RequestMethod.GET)
    public ModelAndView list(VocCtgBean bean, ModelMap model) {

        return responseJson(model, service.list(bean));
    }

    /**
     * VOC분류 상세정보
     */
    @RequestMapping(value="a_view.do", method=RequestMethod.POST)
    public void view(VocCtgBean bean, ModelMap model) {

        model.addAttribute("dataBean", service.view(bean));
    }
    
    /**
     * VOC분류 등록 액션
     */
    @RequestMapping(value="t_insertAction.do", method=RequestMethod.POST)
    public ModelAndView insertAction(VocCtgBean bean, ModelMap model) {

        String message = null;
        
        Object newPrimaryKey = service.insertAction(bean);

        if (newPrimaryKey != null) {
            message = Message.success(Message.COMMON_INSERT_SUCCESS_KEY);
        }
        else {
            message = Message.fail(Message.COMMON_CRUD_FAIL_KEY);
        }
        return responseText(model, message + Message.DELIMETER + newPrimaryKey);
    }

    /**
     * VOC분류 수정 액션
     */
    @RequestMapping(value="t_updateAction.do", method=RequestMethod.POST)
    public ModelAndView updateAction(VocCtgBean bean, ModelMap model) {

        int affected = service.updateAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_UPDATE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }

    /**
     * VOC분류 삭제 액션
     */
    @RequestMapping(value="t_deleteAction.do", method=RequestMethod.POST)
    public ModelAndView deleteAction(VocCtgBean bean, ModelMap model) {

        // TODO : 분류코드가 응용 VOC 테이블에 맵핑되어 있다면 삭제 거부해야 함.
        
        int affected = service.deleteAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_DELETE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
    
    
    /**
     * VOC분류 목록 (For selectbox)
     */
    @RequestMapping(value="a_list.do", method=RequestMethod.POST)
    public void listForSelect(VocCtgBean bean, ModelMap model) {

        if (StringUtil.isEmpty(bean.getHighVocCtgCd()))
            bean.setHighVocCtgCd(Constant.TOP_CTG_CD);
        
        model.addAttribute("dataList", service.list(bean));
    }
}
