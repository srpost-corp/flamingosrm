package com.srpost.cm.bo.sr.svc.ctr.ctrModal;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 계약 담당자 정보 Bean
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Alias("ctrMgrBean")
@SuppressWarnings("serial")
public class CtrMgrBean extends BaseBean {
    
    /** 계약_일련번호 */
    private Integer ctrSeq;
    /** 정렬_순서 */
    private Integer orderNo;
    /** 담당자_ID */
    private String mgrId;
    /** 담당자_명 */
    private String mgrNm;
    /** 부서_이름 */
    private String deptNm;
    
    /** 계약_일련번호_배열 */
    private Integer[] ctrSeqs;
    
    public Integer getCtrSeq() {
        return ctrSeq;
    }
    public void setCtrSeq(Integer ctrSeq) {
        this.ctrSeq = ctrSeq;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getMgrNm() {
        return mgrNm;
    }
    public void setMgrNm(String mgrNm) {
        this.mgrNm = mgrNm;
    }
    public String getDeptNm() {
        return deptNm;
    }
    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }
    public Integer[] getCtrSeqs() {
        return ctrSeqs;
    }
    public void setCtrSeqs(Integer[] ctrSeqs) {
        this.ctrSeqs = ctrSeqs;
    }
    
}
