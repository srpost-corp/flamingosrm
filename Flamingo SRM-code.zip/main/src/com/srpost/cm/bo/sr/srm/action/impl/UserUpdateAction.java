package com.srpost.cm.bo.sr.srm.action.impl;

import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.lang.StringUtil;

import static com.srpost.salmon.constant.StringPool.ONE;

/**
 * USER_INSERT : 고객 VOC 수정
 *
 * @author  finkle
 * @date    2015-02-06
 * @since   3.0
 */
public class UserUpdateAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");

        /*-------------------------
         * VOC 수정
         */
        
        // TODO : SR 태그 정보 수정
        
        VocUtil.setNotNullValue(vocBean);

        if ( StringUtil.isNotEmpty(vocBean.getFileIds()) ) {
            fileDao.deleteAction(vocBean.getUserFileSeq(), vocBean.getFileIds());
        }
        
        vocBean.setUserFileSeq( 
            fileDao.insertAction(vocBean.getUserFileList(), vocBean.getUserFileSeq()) );

        int affected = update("_vocAction.updateVocForUserUpdate", vocBean);
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {

            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>신청정보 수정</strong>");
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
        }
    }
}
