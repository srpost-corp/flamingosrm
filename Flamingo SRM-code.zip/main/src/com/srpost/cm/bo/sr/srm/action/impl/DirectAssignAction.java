package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.conf.VocConfBean;
import com.srpost.cm.bo.sr.srm.conf.VocReceiverBean;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.cm.bo.sr.srm.supporter.LmtDtCalculator;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

/**
 * DIRECT_ASSIGN : 처리자 직접지정 - 접수자
 *
 * @author  finkle
 * @date    2014-12-04
 * @since   3.0
 */
public class DirectAssignAction extends OffInsertAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();
        String assignId = (String)parameterMap.get("assignId");
        String assignNm = (String)parameterMap.get("assignNm");
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        String today = (String)transientVars.get("today");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());
        VocDivBean myDivBean = VocUtil.getMyVocDivBean(divList, ONE);
        LmtDtCalculator lmtDtCalculator = new LmtDtCalculator(vocBean);
        
        int affected = ONE;
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || divList.size() == 0 || 
                StringUtil.equals(orgBean.getDelYn(), Y) ||
                !(StringUtil.equals(orgBean.getMgrStatusCd(), MS_READY) || StringUtil.equals(orgBean.getMgrStatusCd(), MS_RECEIVE)) ||
                orgBean.getVocCd() != vocBean.getVocCd() ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * 워크플로우 실행
         */
        executeWorkflow(transientVars, myDivBean.getWfId());

        /*-------------------------
         * VOC 수정
         */
        VocUtil.setNotNullValue(vocBean);
        
        if (StringUtil.isEmpty(orgBean.getRcvDt()))
            vocBean.setRcvDt(today);
        
        if (StringUtil.isEmpty(orgBean.getRcvId()))
            vocBean.setRcvId(loginBean.getMgrId());
        
        if (StringUtil.isEmpty(orgBean.getRcvNo()))
            vocBean.setRcvNo(rcvNoGenerator.create(vocBean.getVocSeq()));

        vocBean.setUserStatusCd(US_DEALING);
        vocBean.setMgrStatusCd(MS_ASSIGN);
        vocBean.setKindCd(KND_NORMAL);
        if (!StringUtil.equals(vocBean.getTypeCd(), TYPE_CMPLN_CD)) {
            vocBean.setCmplnCd(EMPTY);
        }
        
        vocBean.setDivDt(today);
        vocBean.setAsnDt(today);
        vocBean.setLmtDt(lmtDtCalculator.getLmtDt());

        affected = update("_vocAction.updateVocForDirectAssign", vocBean);
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 등록
             */
            
            // 접수자 ENTRY 비활성화 수정
            VocConfBean confBean = VocUtil.getConfBean(vocBean.getVocCd());

            List<VocReceiverBean> receiverList = confBean.getReceiverList();
            for (VocReceiverBean receiverBean : receiverList) {
                update("_vocAction.updateEntry", new VocEntryBean(
                    vocBean.getVocSeq(), receiverBean.getMgrId(), AUTH_RECEIVER, ACT_INACTIVE));
            }
            
            // 행위자 ENTRY 연관화 수정
            update("_vocAction.updateEntryForce", new VocEntryBean(
                vocBean.getVocSeq(), loginBean.getMgrId(), AUTH_RECEIVER, ACT_WORKER));
            
            // 분배자 ENTRY 비활성화 등록
            MgrBean paramMgrBean = new MgrBean();
            paramMgrBean.setConnId(assignId);
            paramMgrBean.setAuthCd(AUTH_DIVIDER);
            
            List<MgrBean> dividerList = selectList("_vocSupport.listMgr", paramMgrBean);
            int index = ONE;
            
            for (MgrBean dividerBean : dividerList) {
                // 첫번째 분배자 ENTRY 연관화 등록
                // 접수자에 의한 직접 처리자 지정이므로 반송에 대비해 최소 분배자 1명은 연관화 해야함
                if (index == ONE)
                    insert("_vocAction.insertEntry", new VocEntryBean(
                        vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_WORKER));
                // 잔여 분배자 ENTRY 비활성화 등록
                else
                    insert("_vocAction.insertEntry", new VocEntryBean(
                        vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_INACTIVE));
                index++;
            }
            
            // 처리자 ENTRY 활성화 등록
            insert("_vocAction.insertEntry", new VocEntryBean(
                vocBean.getVocSeq(), assignId, AUTH_DEALER, ACT_ACTIVE));
            
            /*-------------------------
             * DIV 수정
             */
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setOrderNo(myDivBean.getOrderNo());
            divBean.setDeptCd((String)selectOne("_vocSupport.viewDeptCdByMgrId", assignId));
            divBean.setMgrId(assignId);
            divBean.setMgrStatusCd(vocBean.getMgrStatusCd());
            divBean.setDivDt(today);
            divBean.setAsnDt(today);
            divBean.setSnbkReqDt("-1");
            
            update("_vocAction.updateDiv", divBean);
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>처리자 직접 지정</strong> : TO " + assignNm);
            logContents.append("<br/>처리기한 : <span title='" + lmtDtCalculator.getLmtDtLog() + "'>");
            logContents.append(DateTimeUtil.toDateFull(vocBean.getLmtDt()) + "</span>");
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());

            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 지정 처리자, 고객
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            alimMap.addMgr((MgrBean)selectOne("_mgr.view", assignId));
            alimMap.setMgrBean((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getWriterId()));
            
            executeAlim(alimMap);
        }
    }
}
