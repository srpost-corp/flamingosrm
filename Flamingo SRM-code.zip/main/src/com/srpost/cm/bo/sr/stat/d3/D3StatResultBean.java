package com.srpost.cm.bo.sr.stat.d3;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 내부단 VOC 통계(D3) 결과 Bean
 *
 * @author  finkle
 * @date    2016-07-20
 * @since   2.0
 */
@Alias("d3StatResultBean")
@SuppressWarnings("serial")
public class D3StatResultBean extends BaseBean {

    private Integer year;
    private String day;
    private String time;
    private Integer dow;
    private String fromNm;
    private String typeNm;
    private String kindNm;
    private String endNm;
    private Long endCnt;
    private Integer scoreAvg;
    
    
    public Integer getYear() {
        return year;
    }
    public String getDay() {
        return day;
    }
    public String getTime() {
        return time;
    }
    public Integer getDow() {
        return dow;
    }
    public String getFromNm() {
        return fromNm;
    }
    public String getTypeNm() {
        return typeNm;
    }
    public String getKindNm() {
        return kindNm;
    }
    public String getEndNm() {
        return endNm;
    }
    public Long getEndCnt() {
        return endCnt;
    }
    public Integer getScoreAvg() {
        return scoreAvg;
    }
    public void setYear(Integer year) {
        this.year = year;
    }
    public void setDay(String day) {
        this.day = day;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public void setDow(Integer dow) {
        this.dow = dow;
    }
    public void setFromNm(String fromNm) {
        this.fromNm = fromNm;
    }
    public void setTypeNm(String typeNm) {
        this.typeNm = typeNm;
    }
    public void setKindNm(String kindNm) {
        this.kindNm = kindNm;
    }
    public void setEndNm(String endNm) {
        this.endNm = endNm;
    }
    public void setEndCnt(Long endCnt) {
        this.endCnt = endCnt;
    }
    public void setScoreAvg(Integer scoreAvg) {
        this.scoreAvg = scoreAvg;
    }
}