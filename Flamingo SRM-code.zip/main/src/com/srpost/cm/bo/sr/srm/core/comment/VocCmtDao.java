package com.srpost.cm.bo.sr.srm.core.comment;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.base.file.FileDao;
import com.srpost.salmon.lang.StringUtil;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 외부의견글 DAO
 *
 * @author  finkle
 * @date    2015-01-23
 * @since   2.0
 */
@Repository
public class VocCmtDao extends EgovAbstractMapper {

    @Resource
    FileDao fileDao;
    
    
    public List<VocCmtBean> list(VocCmtBean bean) {

        List<VocCmtBean> dataList = selectList("_vocCmt.list", bean);
        for (VocCmtBean item : dataList) {
            if (item.getFileSeq() != null && item.getFileSeq() != -1) {
                item.setFileList( fileDao.list(item.getFileSeq()) );
            }
        }
        return dataList;
    }
    
    public VocCmtBean view(VocCmtBean bean) {

        VocCmtBean dataBean = selectOne("_vocCmt.view", bean);
        
        if (dataBean != null) {
            dataBean.setFileList( fileDao.list(dataBean.getFileSeq()) );
        }
        
        return dataBean;
    }
    
    public int insertAction(VocCmtBean bean) {

        VocCmtUtil.setNotNullValue(bean);

        bean.setRefSeq((Integer)selectOne("_vocCmt.viewMinRefSeq", bean));
        bean.setDepth(ZERO);
        bean.setOrderNo(ZERO);
        bean.setFileSeq( fileDao.insertAction(bean.getFileList()) );
        
        return insert("_vocCmt.insert", bean);
    }

    public int updateAction(VocCmtBean bean) {

        VocCmtUtil.setNotNullValue(bean);

        if ( StringUtil.isNotEmpty(bean.getFileIds()) ) {
            fileDao.deleteAction(bean.getFileSeq(), bean.getFileIds());
        }
        
        bean.setFileSeq( fileDao.insertAction(bean.getFileList(), bean.getFileSeq()) );
        
        return update("_vocCmt.update", bean);
    }
    
    public int replyAction(VocCmtBean bean) {

        VocCmtUtil.setNotNullValue(bean);

        bean.setFileSeq( fileDao.insertAction(bean.getFileList()) );
        
        // 상위 자료의 계층정보 설정
        VocCmtBean parentBean = (VocCmtBean)selectOne("_vocCmt.viewParent", bean);
        bean.setRefSeq(parentBean.getRefSeq());
        bean.setDepth(parentBean.getDepth() + ONE);
        bean.setOrderNo(parentBean.getOrderNo() + ONE);
        
        // 반 업데이트를 위한 대상 자료 추출
        List<VocCmtBean> relativeList = selectList("_vocCmt.relativeList", bean);
        for (VocCmtBean item : relativeList) {
            if ( bean.getDepth() > item.getDepth() )
                break;
            else
                bean.setOrderNo(item.getOrderNo() + ONE);
        }
        
        // 반 업데이트
        update("_vocCmt.updateRelativeList", bean);
        
        return insert("_vocCmt.insert", bean);
    }

    public int deleteAction(VocCmtBean bean) {

        VocCmtBean dataBean = view(bean);
        dataBean.setOrderNo(dataBean.getOrderNo() + ONE);
        dataBean.setDepth(dataBean.getDepth() + ONE);
        
        Integer childCount = selectOne("_vocCmt.childCount", dataBean);
        int affected = ZERO;
        
        if (childCount > ZERO) {
            affected = delete("_vocCmt.updateForDelete", bean);
        }
        else {
            affected = delete("_vocCmt.delete", bean);
        }
        
        if (affected > ZERO) {
            fileDao.deleteAction(dataBean.getFileSeq());
        }
        
        return affected;
    }
}