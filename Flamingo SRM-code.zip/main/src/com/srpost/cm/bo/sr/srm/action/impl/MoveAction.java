package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;

/**
 * MOVE : 전달 - 분배자/처리자
 *
 * @author  finkle
 * @date    2014-12-05
 * @since   3.0
 */
public class MoveAction extends OffInsertAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {

        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();

        String authCd = (String)parameterMap.get("authCd");
        if (StringUtil.isEmpty(authCd)) authCd = String.valueOf(AUTH_DEALER);
        Integer iAuthCd = Integer.valueOf(authCd);
        
        String target = (String)parameterMap.get("target"); // divider|dealer
        String masterDeptCd = (String)parameterMap.get("masterDeptCd");
        String masterDeptNm = (String)parameterMap.get("masterDeptNm");
        String assignId = (String)parameterMap.get("assignId");
        String assignNm = (String)parameterMap.get("assignNm");
        boolean toDivider = StringUtil.equals(target, "divider");
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        String today = (String)transientVars.get("today");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();
        
        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());
        VocDivBean myDivBean = VocUtil.getMyVocDivBean(divList, loginBean);
        
        int affected = ONE;

        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || divList.size() == 0 || StringUtil.isEmpty(myDivBean) || 
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                !(StringUtil.equals(myDivBean.getMgrStatusCd(), MS_DIVIDE) || StringUtil.equals(myDivBean.getMgrStatusCd(), MS_ASSIGN)) ||
                (StringUtil.isNotEmpty(myDivBean.getDeptCd()) && !StringUtil.equals(myDivBean.getDeptCd(), loginBean.getDeptCd())) ||
                (StringUtil.isNotEmpty(myDivBean.getMgrId()) && !StringUtil.equals(myDivBean.getMgrId(), loginBean.getMgrId())) ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * 워크플로우 실행
         */
        transientVars.put("mgrStatusCd", toDivider ? MS_DIVIDE : MS_ASSIGN);
        executeWorkflow(transientVars, myDivBean.getWfId());
        
        /*-------------------------
         * VOC 수정
         */
        // 주무부서의 처리상태를 따름
        if ( StringUtil.equals(myDivBean.getMasterYn(), Y) ) {
            
            vocBean.setMgrStatusCd(toDivider ? MS_DIVIDE : MS_ASSIGN);
            vocBean.setDivDt(today);
            
            if ( !toDivider ) 
                vocBean.setAsnDt(today);
            
            affected = update("_vocAction.updateVocForMove", vocBean);
        }
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 수정
             */
            
            // 부서로 전달 시
            if (toDivider) {
                
                // 이전 부서 분배자 ENTRY 삭제
                VocEntryBean entryBean = new VocEntryBean();
                entryBean.setVocSeq(vocBean.getVocSeq());
                entryBean.setDeptCd(loginBean.getDeptCd());
                entryBean.setAuthCd(AUTH_DIVIDER);
                delete("_vocAction.deleteEntry", entryBean);
                
                // 행위자 ENTRY 삭제
                entryBean = new VocEntryBean();
                entryBean.setVocSeq(vocBean.getVocSeq());
                entryBean.setMgrId(loginBean.getMgrId());
                entryBean.setAuthCd(iAuthCd);
                delete("_vocAction.deleteEntry", entryBean);

                // 새 부서 분배자 ENTRY 등록
                MgrBean paramMgrBean = new MgrBean();
                paramMgrBean.setDeptCd(masterDeptCd);
                paramMgrBean.setAuthCd(AUTH_DIVIDER);
                
                List<MgrBean> dividerList = selectList("_vocSupport.listMgr", paramMgrBean);
                for (MgrBean dividerBean : dividerList) {
                    insert("_vocAction.insertEntry", new VocEntryBean(
                        vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_ACTIVE));
                }
                
                alimMap.addAllMgr(dividerList);
            }
            // 처리자에게 전달 시
            else {
                
                String assignDeptCd = (String)selectOne("_vocSupport.viewDeptCdByMgrId", assignId);
                
                // 동일 부서내 처리자 전달일 경우
                if (StringUtil.equals(loginBean.getDeptCd(), assignDeptCd)) {
                    
                    // 기존 처리자 ENTRY 삭제
                    VocEntryBean entryBean = new VocEntryBean();
                    entryBean.setVocSeq(vocBean.getVocSeq());
                    entryBean.setMgrId(loginBean.getMgrId());
                    entryBean.setAuthCd(AUTH_DEALER);
                    
                    delete("_vocAction.deleteEntry", entryBean);
                    
                    // 전달대상 분배자 ENTRY 비활성화 수정
                    MgrBean paramMgrBean = new MgrBean();
                    paramMgrBean.setConnId(assignId);
                    paramMgrBean.setAuthCd(AUTH_DIVIDER);
                    
                    List<MgrBean> dividerList = selectList("_vocSupport.listMgr", paramMgrBean);
                    for (MgrBean dividerBean : dividerList) {
                        if (StringUtil.equals(dividerBean.getMgrId(), loginBean.getMgrId())) {
                            update("_vocAction.updateEntry", new VocEntryBean(
                                vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_WORKER));
                        }
                        else {
                            update("_vocAction.updateEntry", new VocEntryBean(
                                vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_INACTIVE));
                        }
                    }
                    
                    // 전달대상 처리자 ENTRY 등록
                    insert("_vocAction.insertEntry", new VocEntryBean(
                            vocBean.getVocSeq(), assignId, AUTH_DEALER, ACT_ACTIVE));
                }
                // 타부서 처리자 전달일 경우 이전 부서에 속한 분배, 처리자 ENTRY 모두 삭제
                else {
                    VocEntryBean entryBean = new VocEntryBean();
                    entryBean.setVocSeq(vocBean.getVocSeq());
                    entryBean.setDeptCd(loginBean.getDeptCd());
                    entryBean.setAuthCd(AUTH_DIVIDER);                    
                    delete("_vocAction.deleteEntry", entryBean);
                    
                    entryBean.setAuthCd(AUTH_DEALER);                    
                    delete("_vocAction.deleteEntry", entryBean);
                    
                    // 새 부서 분배자 ENTRY 등록
                    MgrBean paramMgrBean = new MgrBean();
                    paramMgrBean.setDeptCd(assignDeptCd);
                    paramMgrBean.setAuthCd(AUTH_DIVIDER);
                    
                    List<MgrBean> dividerList = selectList("_vocSupport.listMgr", paramMgrBean);
                    int index = ONE;
                    
                    for (MgrBean dividerBean : dividerList) {
                        // 첫번째 분배자 ENTRY 연관화 등록
                        // 처리자에게 전달이므로 반송에 대비해 최소 분배자 1명은 연관화 해야함
                        if (index == ONE)
                            insert("_vocAction.insertEntry", new VocEntryBean(
                                vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_WORKER));
                        // 잔여 분배자 ENTRY 비활성화 등록
                        else
                            insert("_vocAction.insertEntry", new VocEntryBean(
                                vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_INACTIVE));
                        index++;
                    }
                    
                    // 전달대상 부서 처리자 ENTRY 등록
                    insert("_vocAction.insertEntry", new VocEntryBean(
                            vocBean.getVocSeq(), assignId, AUTH_DEALER, ACT_ACTIVE));
                }
            }
            
            /*-------------------------
             * DIV 수정
             */
            VocDivBean myVocDivBean = VocUtil.getMyVocDivBean(divList, loginBean);
            
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setOrderNo(myVocDivBean.getOrderNo());
            divBean.setMgrStatusCd(toDivider ? MS_DIVIDE : MS_ASSIGN);
            divBean.setDivDt(today);
            
            if (toDivider) {
                divBean.setDeptCd(masterDeptCd);
                divBean.setMgrId(EMPTY);
                divBean.setAsnDt(EMPTY);
            }
            else {
                divBean.setDeptCd((String)selectOne("_vocSupport.viewDeptCdByMgrId", assignId));
                divBean.setMgrId(assignId);
                divBean.setAsnDt(today);
            }
            
            update("_vocAction.updateDivForMove", divBean);
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>전달</strong> : TO " + (toDivider ? "부서" : "처리자"));
            logContents.append("<br/>전달대상 : ");
            if (toDivider)
                logContents.append(loginBean.getDeptNm() + " &rarr; <span class='emphasis'>" + masterDeptNm + "</span>");
            else
                logContents.append(loginBean.getMgrNm() + " &rarr; <span class='emphasis'>" + assignNm + "</span>");
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            logBean.setActionCd(vocBean.getAction());
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());
            
            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 부서 분배자 or 지정 처리자
             */
            alimMap.setActionCd(vocBean.getAction());
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());

            if (toDivider) {
                // 분배자
            }
            else {
                // 처리자
                alimMap.addMgr((MgrBean)selectOne("_mgr.view", assignId));
            }
            
            executeAlim(alimMap);
        }
    }
}
