package com.srpost.cm.bo.sr.srm.core.scrap;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocExcelRowHandler;
import com.srpost.cm.bo.sr.srm.core.VocListBean;
import com.srpost.salmon.bean.BasePagerBean;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.crypto.SalmonCrypto;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 스크랩 DAO
 *
 * @author  finkle
 * @date    2014-12-12
 * @since   2.0
 */
@Repository
public class VocScrapDao extends EgovAbstractMapper {

    @Resource
    SalmonCrypto salmonCtypto;
    
    public BasePagerBean list(VocListBean bean) {
        
        Map<String, Object> parameterMap = VocScrapUtil.getParameterMap(bean);

        List<VocBean> dataList = selectList("_vocScrap.list", parameterMap);
        int totalCount = (Integer)selectOne("_vocScrap.listCount", parameterMap);

        return new BasePagerBean(dataList, totalCount, bean);
    }
    
    public List<Map<String, Object>> listExcel(VocListBean bean) {
        
        Map<String, Object> parameterMap = VocScrapUtil.getParameterMap(bean);
        
        VocExcelRowHandler rowHandler = new VocExcelRowHandler(salmonCtypto);
        
        if ( StringUtil.equals(bean.getXlsScope(), VocBean.SCOPE_TOTAL)) {
            getSqlSession().select("_vocExcel.listScrapAll", parameterMap, rowHandler);
        }
        else {
            getSqlSession().select("_vocExcel.listScrap", parameterMap, rowHandler);
        }
        
        return rowHandler.getList();
    }
    
    public int insertScrapAction(Integer vocSeq, String mgrId) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("vocSeq", vocSeq);
        parameterMap.put("mgrId", mgrId);
        
        if (selectOne("_vocScrap.view", parameterMap) != null) {
            return MINUS_ONE;
        }
        
        return insert("_vocScrap.insert", parameterMap);
    }

    public int deleteScrapAction(Integer vocSeq, String mgrId) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("vocSeq", vocSeq);
        parameterMap.put("mgrId", mgrId);
        
        return delete("_vocScrap.delete", parameterMap);
    }
    
    public List<VocBean> listForDashboard(VocListBean bean) {
        
        Map<String, Object> parameterMap = VocScrapUtil.getParameterMap(bean);

        return selectList("_vocScrap.list", parameterMap);
    }
}
