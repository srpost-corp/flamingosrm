package com.srpost.cm.bo.sr.srm.action.condition.step;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.opensymphony.module.propertyset.PropertySet;
import com.opensymphony.workflow.Condition;

/**
 * 결재반려/취소 : 워크플로우 실행 시 상신자가 분배자인지 처리자인지 여부 판단 Condition
 *
 * @author  finkle
 * @date    2014-12-10
 * @since   3.0
 */
@SuppressWarnings("rawtypes")
@Component(value="STEP_sancCancelDenyCondition")
public class SancCancelDenyCondition implements Condition {

    public boolean passesCondition(Map transientVars, Map args, PropertySet ps) {

        return (Boolean)transientVars.get("isDivider");
    }
}
