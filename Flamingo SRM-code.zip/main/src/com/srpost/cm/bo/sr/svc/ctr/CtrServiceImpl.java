package com.srpost.cm.bo.sr.svc.ctr;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.salmon.bean.BasePagerBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 계약 서비스 구현체
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Service
public class CtrServiceImpl extends EgovAbstractServiceImpl implements ICtrService {

    @Resource
    CtrDao dao;
    
    @Override
    public BasePagerBean list(CtrBean bean) {
        
        return dao.list(bean);
    }

    @Override
    public List<Map<String, Object>> listExcel(CtrBean bean) {
        
        return dao.listExcel(bean);
    }

    @Override
    public CtrBean view(CtrBean bean) {
        
        return dao.view(bean);
    }

    @Override
    public int insertAction(CtrBean bean) {
        
        return dao.insertAction(bean);
    }

    @Override
    public int updateAction(CtrBean bean) {
        
        return dao.updateAction(bean);
    }

    @Override
    public int deleteAction(CtrBean bean) {
        
        return dao.deleteAction(bean);
    }

    @Override
    public List<CtrBean> svcCtrListAll(CtrBean bean) {
        
        return dao.svcCtrListAll(bean);
    }

}
