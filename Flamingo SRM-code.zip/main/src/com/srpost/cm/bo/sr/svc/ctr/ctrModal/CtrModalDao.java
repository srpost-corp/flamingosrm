package com.srpost.cm.bo.sr.svc.ctr.ctrModal;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.svc.ctr.CtrBean;
import com.srpost.salmon.lang.StringUtil;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 서비스 모달 DAO
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Repository
public class CtrModalDao extends EgovAbstractMapper {
    
    public void insertCtrModalAction(CtrBean bean) {
        
        delete("_ctrModal.prjDelete", bean);
        delete("_ctrModal.objDelete", bean);
        delete("_ctrModal.busiDelete", bean);
        
        /** 담당자 */
        if ( StringUtil.isNotEmpty(bean.getMgrDatas()) ) {
            
            delete("_ctrModal.mgrDelete", bean);
            
            for ( String mgrData : bean.getMgrDatas() ) {
                
                bean.setMgrId(mgrData);
                insert("_ctrModal.mgrInsert", bean);
            }
        }
        
        /** 프로젝트 */
        if ( StringUtil.isNotEmpty(bean.getPrjDatas()) ) {
            
            for ( int seq : bean.getPrjDatas() ) {
                
                bean.setPrjSeq(seq);
                insert("_ctrModal.prjInsert", bean);
            }
        }
        
        /** 제품 */
        if ( StringUtil.isNotEmpty(bean.getObjDatas()) ) {
            
            for ( int seq : bean.getObjDatas() ) {
                
                bean.setObjSeq(seq);
                insert("_ctrModal.objInsert", bean);
            }
        }
        
        /** 사업자 */
        if ( StringUtil.isNotEmpty(bean.getBusiDatas()) ) {
            
            for ( int seq : bean.getBusiDatas() ) {
                
                bean.setBusiSeq(seq);
                insert("_ctrModal.busiInsert", bean);
            }
        }
    }

}
