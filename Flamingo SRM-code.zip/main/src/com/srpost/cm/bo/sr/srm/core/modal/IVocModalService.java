package com.srpost.cm.bo.sr.srm.core.modal;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.dept.DeptBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;

/**
 * 내부단 VOC 모달창 서비스 인터페이스
 *
 * @author  finkle
 * @date    2014-11-26
 * @since   3.0
 */
public interface IVocModalService {

    List<DeptBean> listDept(String highDeptCd, Integer authCd, 
            String masterDeptCd);

    List<DeptBean> listDeptCheck(String highDeptCd, Integer authCd,
            String masterDeptCd, String supportDeptCds);
    
    String listDeptAllJSON(Integer authCd);
    
    List<MgrBean> listDealer(MgrBean bean);
    
    List<VocDivBean> listDiv(Map<String, Object> parameterMap);
    
    List<VocSancBean> listSanc(Map<String, Object> parameterMap);
    
    List<String> listMySancStore(String mgrId);
    
    int deleteSancLineAction(String mgrId, String sancLine);
    
    VocLogBean viewExtReqLog(Integer vocSeq);
}
