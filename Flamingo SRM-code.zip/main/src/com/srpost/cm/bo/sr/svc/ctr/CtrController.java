package com.srpost.cm.bo.sr.svc.ctr;

import static com.srpost.salmon.constant.StringPool.ONE;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srpost.salmon.constant.Message;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 계약 컨트롤러
 *
 * @author  Bella
 * @date    2017-04-25
 * @since   3.0
 */
@Controller
@RequestMapping(value="/bo/sr/svc/ctr")
public class CtrController extends BaseController {
    
    @Resource
    ICtrService service;
    
    /**
     * 계약 메인
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index(ModelMap model) {
        
    }
    
    /**
     * 계약 목록
     */
    @RequestMapping(value="j_list.do", method=RequestMethod.GET)
    public ModelAndView list(CtrBean bean, ModelMap model) {
        
        return responseJson(model, service.list(bean));
    }
    
    /**
     * 계약 상세정보
     */
    @RequestMapping(value="a_view.do", method=RequestMethod.POST)
    public void view(CtrBean bean, ModelMap model) {
        
        model.addAttribute("dataBean", service.view(bean));
    }
    
    /**
     * 계약 등록/수정 폼
     */
    @RequestMapping(value="a_form.do", method=RequestMethod.POST)
    public void form(CtrBean bean, ModelMap model) {
        
        if ( StringUtil.isEmpty(bean.getCtrSeq()) ) {
            model.addAttribute("dataBean", bean);
        }
        else {
            CtrBean dataBean = service.view(bean);
            dataBean.setReCtrYn(bean.getReCtrYn());
            model.addAttribute("dataBean", dataBean == null ? bean : dataBean);
        }
    }
    
    /**
     * 계약 등록 액션
     */
    @RequestMapping(value="t_insertAction.do", method=RequestMethod.POST)
    public ModelAndView insertAction(CtrBean bean, ModelMap model) {
        
        int affected = service.insertAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_INSERT_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
    
    /**
     * 계약 수정 액션
     */
    @RequestMapping(value="t_updateAction.do", method=RequestMethod.POST)
    public ModelAndView updateAction(CtrBean bean, ModelMap model) {
        
        int affected = service.updateAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_UPDATE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
    
    /**
     * 계약 삭제 액션
     */
    @RequestMapping(value="t_deleteAction.do", method=RequestMethod.POST)
    public ModelAndView deleteAction(CtrBean bean, ModelMap model) {
        
        int affected = service.deleteAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_DELETE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
    
    /**
     * 엑셀 변환 팝업창
     */
    @RequestMapping(value="p_excelForm.do", method=RequestMethod.GET)
    public void excelForm() {
    }
    
    /**
     * 엑셀 변환 액션
     */
    @RequestMapping(value="x_excelAction.do", method=RequestMethod.POST)
    public ModelAndView excelAction(CtrBean bean, ModelMap model) {
        
        List<Map<String, Object>> dataList = service.listExcel(bean);
        
        return responseExcel(model, dataList, bean);
    }
    
    /**
     * 계약 상세정보의 계약 목록
     */
    @RequestMapping(value="a_ctrList.do", method=RequestMethod.POST)
    public void ctrList(CtrBean bean, ModelMap model) {
        
    }
    
    /**
     * 계약 상세정보의 계약 목록
     */
    @RequestMapping(value="j_svcCtrListAll.do", method=RequestMethod.GET)
    public ModelAndView svcCtrListAll(CtrBean bean, ModelMap model) {
        
        return responseJson(model, service.svcCtrListAll(bean));
    }
    
    /**
     * SR등록의 관련 계약 상세정보
     */
    @RequestMapping(value="j_view.do", method=RequestMethod.GET)
    public ModelAndView jsonView(CtrBean bean, ModelMap model) {
        
        return responseJson(model, service.view(bean));
    }

}
