package com.srpost.cm.bo.sr.srm.core.comment;

import java.util.List;

/**
 * 내부단 VOC 외부의견글 서비스 인터페이스
 *
 * @author  finkle
 * @date    2015-01-23
 * @since   2.0
 */
public interface IVocCmtService {

    List<VocCmtBean> list(VocCmtBean bean);
    
    VocCmtBean view(VocCmtBean bean);

    int insertAction(VocCmtBean bean);

    int updateAction(VocCmtBean bean);

    int replyAction(VocCmtBean bean);

    int deleteAction(VocCmtBean bean);
}
