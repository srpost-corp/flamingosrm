package com.srpost.cm.bo.sr.srm.core.alim;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

/**
 * 내부단 VOC 알림 정보 Bean
 *
 * @author  finkle
 * @date    2014-12-16
 * @since   2.0
 */
@Alias("vocAlimBean")
@SuppressWarnings("serial")
public class VocAlimBean extends BaseBean {

    /** VOC_일련번호 */
    private Integer vocSeq;
    /** 정렬_순서 */
    private Integer orderNo;
    /** 알림_코드 */
    private String alertCd;
    /** 수신자_이름 */
    private String rcvNm;
    /** 직원_ID */
    private String mgrId;
    /** 암호화_이메일_주소 */
    private String encEmail;
    /** 암호화_휴대폰_번호 */
    private String encMobile;
    /** 제목 */
    private String title;
    /** 내용 */
    private String contents;
    /** 파일_순번 */
    private Integer fileSeq;
    /** 알림_결과 */
    private String result;
    /** 등록_일시 */
    private String regDt;
    
    
    public Integer getVocSeq() {
        return vocSeq;
    }
    public void setVocSeq(Integer vocSeq) {
        this.vocSeq = vocSeq;
    }
    public Integer getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
    public String getAlertCd() {
        return alertCd;
    }
    public void setAlertCd(String alertCd) {
        this.alertCd = alertCd;
    }
    public String getRcvNm() {
        return rcvNm;
    }
    public void setRcvNm(String rcvNm) {
        this.rcvNm = rcvNm;
    }
    public String getMgrId() {
        return mgrId;
    }
    public void setMgrId(String mgrId) {
        this.mgrId = mgrId;
    }
    public String getEncEmail() {
        return encEmail;
    }
    public void setEncEmail(String encEmail) {
        this.encEmail = encEmail;
    }
    public String getEncMobile() {
        return encMobile;
    }
    public void setEncMobile(String encMobile) {
        this.encMobile = encMobile;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getContents() {
        return contents;
    }
    public void setContents(String contents) {
        this.contents = contents;
    }
    public Integer getFileSeq() {
        return fileSeq;
    }
    public void setFileSeq(Integer fileSeq) {
        this.fileSeq = fileSeq;
    }
    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }
    public String getRegDt() {
        return regDt;
    }
    public void setRegDt(String regDt) {
        this.regDt = regDt;
    }
}
