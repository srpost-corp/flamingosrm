package com.srpost.cm.bo.sr.srm.action.impl;

import static com.srpost.cm.bo.sr.srm.core.VocConstant.*;
import static com.srpost.salmon.constant.StringPool.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.base.login.LoginBean;
import com.srpost.cm.bo.base.mgr.MgrBean;
import com.srpost.cm.bo.base.mgr.MgrUtil;
import com.srpost.cm.bo.sr.srm.action.AbstractAction;
import com.srpost.cm.bo.sr.srm.core.VocBean;
import com.srpost.cm.bo.sr.srm.core.VocDivBean;
import com.srpost.cm.bo.sr.srm.core.VocEntryBean;
import com.srpost.cm.bo.sr.srm.core.VocSancBean;
import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.srm.core.alim.VocAlimMap;
import com.srpost.cm.bo.sr.srm.core.log.VocLogBean;
import com.srpost.cm.bo.sr.srm.supporter.EncCntCalculator;
import com.srpost.salmon.exception.VocAlreadyExecuteException;
import com.srpost.salmon.lang.StringUtil;

/**
 * DEAL : 처리 - 분배자/처리자
 *
 * @author  finkle
 * @date    2014-12-09
 * @since   3.0
 */
public class DealAction extends AbstractAction {

    @Override
    protected void executeInternal(Map<String, Object> transientVars) throws Exception {
        
        /*-------------------------
         * 추가 요청인자 설정
         */
        Map<String, Object> parameterMap = getParameterMap();
        
        String authCd = (String)parameterMap.get("authCd");
        if (StringUtil.isEmpty(authCd)) authCd = String.valueOf(AUTH_DEALER);
        Integer iAuthCd = Integer.valueOf(authCd);
        
        String sancerIds = (String)parameterMap.get("sancerIds");
        String sancerNms = (String)parameterMap.get("sancerNms");
        String sancerLine = (String)parameterMap.get("sancerLine");
        String[] sancers = StringUtil.split(sancerIds, COMMA);
        boolean isSanction = StringUtil.isNotEmpty(sancerIds);
        
        /*-------------------------
         * 기본 변수 설정
         */
        LoginBean loginBean = (LoginBean)transientVars.get("loginBean");
        VocBean vocBean = (VocBean)transientVars.get("vocBean");
        String today = (String)transientVars.get("today");
        
        /*-------------------------
         * 알림 변수 설정
         */
        VocAlimMap alimMap = new VocAlimMap();

        /*-------------------------
         * 추가 공용 변수 설정
         */
        VocBean orgBean = vocDao.viewSimple(vocBean.getVocSeq());
        List<VocDivBean> divList = getDivList(vocBean.getVocSeq());
        VocDivBean myDivBean = VocUtil.getMyVocDivBean(divList, loginBean);
        boolean isComplex = StringUtil.equals(orgBean.getKindCd(), KND_COMPLEX);
        EncCntCalculator encCntCalculator = new EncCntCalculator();
        MgrBean firstSancerBean = null; // 1번 결재자
        
        int fileSeq = (isComplex) ? myDivBean.getFileSeq() : orgBean.getMgrFileSeq();
        if ( fileSeq != MINUS_ONE && StringUtil.isNotEmpty(vocBean.getFileIds()) )
            fileDao.deleteAction(fileSeq, vocBean.getFileIds());
        fileSeq = fileDao.insertAction(vocBean.getMgrFileList(), fileSeq);
        
        int affected = ONE;
        
        boolean iAmBelongToMasterDept = true;

        if (isComplex) {
            // 복합 VOC : 주무부서일 경우메만 VOC 수정
            iAmBelongToMasterDept = VocUtil.isBelongToMasterDept(divList, loginBean);
        }
        
        /*-------------------------
         * 유효성 체크
         */
        if ( orgBean == null || divList.size() == 0 || StringUtil.isEmpty(myDivBean) || 
                StringUtil.equals(Y, orgBean.getDelYn()) || 
                !(StringUtil.equals(myDivBean.getMgrStatusCd(), MS_DIVIDE) || StringUtil.equals(myDivBean.getMgrStatusCd(), MS_ASSIGN)) ||
                (StringUtil.isNotEmpty(myDivBean.getDeptCd()) && !StringUtil.equals(myDivBean.getDeptCd(), loginBean.getDeptCd())) ||
                (StringUtil.isNotEmpty(myDivBean.getMgrId()) && !StringUtil.equals(myDivBean.getMgrId(), loginBean.getMgrId())) ) {
            throw new VocAlreadyExecuteException();
        }
        
        /*-------------------------
         * 워크플로우 실행
         */
        transientVars.put("isSanction", isSanction);
        executeWorkflow(transientVars, myDivBean.getWfId());

        /*-------------------------
         * VOC 수정
         */
        if (iAmBelongToMasterDept) {
            VocUtil.setNotNullValue(vocBean);
            
            vocBean.setMgrFileSeq(fileSeq);
            vocBean.setUserStatusCd(isSanction ? US_DEALING : US_END);
            vocBean.setMgrStatusCd(isSanction ? MS_SANC : MS_END);
            if (!StringUtil.equals(vocBean.getTypeCd(), TYPE_CMPLN_CD)) {
                vocBean.setCmplnCd(EMPTY);
            }
            vocBean.setSancYn(isSanction ? Y : N);
            if (isSanction)
                vocBean.setReporterId(loginBean.getMgrId());
            
            if (StringUtil.isEmpty(orgBean.getAsnDt())) {
                vocBean.setAsnDt(today);
            }
            
            vocBean.setEndDt(isSanction ? "" : today);
            vocBean.setEndCnt(isSanction ? -1L : 
                encCntCalculator.calculateEndCnt(orgBean.getDivDt(), today));

            affected = update("_vocAction.updateVocForDeal", vocBean);
        }
        
        /*-------------------------
         * VOC 하위 정보 처리
         */
        if (affected == ONE) {
            
            /*-------------------------
             * ENTRY 수정
             */
            
            // 분배자 ENTRY 비활성화 수정
            MgrBean paramMgrBean = new MgrBean();
            paramMgrBean.setDeptCd(loginBean.getDeptCd());
            paramMgrBean.setAuthCd(AUTH_DIVIDER);
            
            List<MgrBean> dividerList = selectList("_vocSupport.listMgr", paramMgrBean);
            for (MgrBean dividerBean : dividerList) {
                update("_vocAction.updateEntry", new VocEntryBean(
                    vocBean.getVocSeq(), dividerBean.getMgrId(), AUTH_DIVIDER, ACT_INACTIVE));
            }

            // 행위자 ENTRY 연관화 수정
            update("_vocAction.updateEntryForce", new VocEntryBean(
                vocBean.getVocSeq(), loginBean.getMgrId(), iAuthCd, ACT_WORKER));
            
            if (iAmBelongToMasterDept && !isSanction) {
                // 기한요청 정보 존재 대비 용 접수자 ENTRY 초기화
                update("_vocAction.updateEntryForReceiver", new VocEntryBean(
                        vocBean.getVocSeq(), null, AUTH_RECEIVER, ACT_WORKER));
            }
            
            if (iAmBelongToMasterDept && isSanction) {
                
                // 결재자 ENTRY 활성화 등록
                if (StringUtil.isNotEmpty(sancers)) {
                    int index = ONE;
                    for (String sancerId : sancers) {
                        
                        if (StringUtil.isEmpty(sancerId)) continue;
                        
                        // 1번 결재자 ENTRY 활성화 등록
                        if (index == ONE) {
                            firstSancerBean = selectOne("_mgr.view", sancerId);
                        
                            insert("_vocAction.insertEntry", new VocEntryBean(
                                vocBean.getVocSeq(), sancerId, AUTH_SANCER, ACT_ACTIVE));
                        }
                        // 잔여 결재자 ENTRY 비활성화 등록
                        else {
                            insert("_vocAction.insertEntry", new VocEntryBean(
                                vocBean.getVocSeq(), sancerId, AUTH_SANCER, ACT_INACTIVE));
                        }
                        index++;
                    }
                }
                
                // 행위자 ENTRY 상신자로 수정
                update("_vocAction.updateEntryForce", new VocEntryBean(
                        vocBean.getVocSeq(), loginBean.getMgrId(), iAuthCd, ACT_REPORTER));
            }
            
            /*-------------------------
             * DIV 수정
             */
            VocDivBean divBean = new VocDivBean();
            divBean.setVocSeq(vocBean.getVocSeq());
            divBean.setOrderNo(myDivBean.getOrderNo());
            if (StringUtil.isEmpty(myDivBean.getAsnDt())) {
                divBean.setMgrId(loginBean.getMgrId());
                divBean.setAsnDt(today);
            }
            divBean.setRplDt(today);
            if (!isSanction) {
                divBean.setEndDt(today);
            }
            divBean.setEndCnt(encCntCalculator.calculateEndCnt(myDivBean.getDivDt(), today));            
            divBean.setMgrStatusCd(iAmBelongToMasterDept ? vocBean.getMgrStatusCd() : MS_END);
            divBean.setReply(vocBean.getReply());
            divBean.setFileSeq(fileSeq);
            divBean.setSnbkReqDt("-1");

            update("_vocAction.updateDiv", divBean);
            
            if (StringUtil.isNotEmpty(myDivBean.getExtReqDt())) {
                update("_vocAction.updateVocDivForExtension", divBean);
            }
            
            if (iAmBelongToMasterDept && isSanction) {
                /*-------------------------
                 * SANC 등록
                 */
                for (String sancerId : sancers) {
                    
                    if (StringUtil.isEmpty(sancerId)) continue;
                    
                    VocSancBean sancBean = new VocSancBean();
                    sancBean.setVocSeq(vocBean.getVocSeq());
                    sancBean.setMgrId(sancerId);
                    sancBean.setStatusNm(SANC_READY);
                    
                    insert("_vocAction.insertSanc", sancBean);
                }
                
                /*-------------------------
                 * SANC_STORE 등록
                 */
                Map<String, String> paramMap = new HashMap<String, String>();
                paramMap.put("mgrId", loginBean.getMgrId());
                paramMap.put("sancLine", sancerLine);
                
                Integer sancStoreCount = selectOne("_vocAction.countSancStore", paramMap);
                if (sancStoreCount == ZERO) {
                    insert("_vocAction.insertSancStore", paramMap);
                }
            }

            if (iAmBelongToMasterDept && !isSanction) {
                // 기한연장 요청정보 삭제
                delete("_vocAction.deleteVocExtDt", vocBean.getVocSeq());
            }
            
            /*-------------------------
             * 로그 등록
             */
            StringBuilder logContents = new StringBuilder();
            logContents.append("<strong>처리</strong>");
            if (iAmBelongToMasterDept) {
                if (isSanction)
                    logContents.append(" : 결재상신<br/>결재선 : " + sancerNms);
                else
                    logContents.append(" : 전결");
            }
            else {
                logContents.append(" : 협조부서");
            }
            
            VocLogBean logBean = new VocLogBean();
            logBean.setVocSeq(vocBean.getVocSeq());
            if (iAmBelongToMasterDept) {
                if (isSanction) logBean.setActionCd(__ACTION_SANC_NEXT__);
                else logBean.setActionCd(ACTION_DEAL);
            }
            else {
                // TODO : 
            }
            logBean.setMgrId(loginBean.getMgrId());
            if (MgrUtil.isAgency(loginBean))
                logBean.setAgencyId(loginBean.getMgrAbsenceBean().getAgencyId());
            logBean.setLogContents(logContents.toString());

            vocLogDao.insertAction(logBean);
            
            /*-------------------------
             * 알림 메시지 전송
             * : TO 고객 or 결재자 or 주무부서
             */
            alimMap.setVocBean(vocDao, vocBean.getVocSeq());
            
            if (iAmBelongToMasterDept) {

                if (isSanction) {
                    // 1번 결재자 알림
                    alimMap.setActionCd(__ACTION_SANC_NEXT__);
                    alimMap.addMgr(firstSancerBean);
                }
                else {
                    // 고객에게 처리완료 알림
                    alimMap.setActionCd(ACTION_DEAL);
                    alimMap.setMgrBean((MgrBean)selectOne("_mgr.view", alimMap.getVocBean().getWriterId()));
                }
            }
            else {
                boolean isFinishSupportDeptReply = VocUtil.isFinishSupportDeptReply(alimMap.getVocBean().getDivList());
                if (isFinishSupportDeptReply) {
                    // 주무부서 분배자 or 처리자에게 협조부서 답변 완료 알림
                    alimMap.setActionCd(__ACTION_SUPPORT_RPL_FIN__);
                    
                    VocDivBean masterDivBean = alimMap.getDivBean();
                    if (StringUtil.isNotEmpty(masterDivBean.getMgrId())) {
                        alimMap.addMgr((MgrBean)selectOne("_mgr.view", masterDivBean.getMgrId()));
                    }
                    else {
                        paramMgrBean.setDeptCd(masterDivBean.getDeptCd());
                        
                        List<MgrBean> masterDividerList = selectList("_vocSupport.listMgr", paramMgrBean);
                        alimMap.addAllMgr(masterDividerList);
                    }
                }
            }
            executeAlim(alimMap);
        }
    }
}
