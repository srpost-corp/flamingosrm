package com.srpost.cm.bo.sr.srm.conf;

import static com.srpost.salmon.constant.StringPool.*;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.opensymphony.workflow.FactoryException;
import com.srpost.salmon.constant.Message;
import com.srpost.salmon.lang.StringUtil;
import com.srpost.salmon.spi.osworkflow.SalmonWorkflow;
import com.srpost.salmon.web.mvc.controller.BaseController;

/**
 * 내부단 VOC설정 컨트롤러
 *
 * @author  finkle
 * @date    2014-11-25
 * @since   2.0
 */
@Controller
@RequestMapping(value="/bo/sr/srm/conf")
public class VocConfController extends BaseController {

    @Resource
    IVocConfService service;
    @Resource
    SalmonWorkflow workflow;
    
    /**
     * VOC설정 메인
     */
    @RequestMapping(value="index.do", method=RequestMethod.GET)
    public void index() {
    }
    
    /**
     * VOC설정 목록
     */
    @RequestMapping(value="j_list.do", method=RequestMethod.GET)
    public ModelAndView list(VocConfBean bean, ModelMap model) {
        
        return responseJson(model, service.list(bean));
    }

    /**
     * VOC설정 상세정보
     */
    @RequestMapping(value="a_view.do", method=RequestMethod.POST)
    public void view(VocConfBean bean, ModelMap model) {

        model.addAttribute("dataBean", service.view(bean));
    }
    
    /**
     * VOC설정 등록/수정 폼
     */
    @RequestMapping(value="a_form.do", method=RequestMethod.POST)
    public void form(VocConfBean bean, ModelMap model) throws FactoryException {

        model.addAttribute("workflowNameList", 
                workflow.getConfiguration().getWorkflowNames());
        
        if (StringUtil.isEmpty(bean.getVocCd()))
            model.addAttribute("dataBean", bean);
        else {
            VocConfBean dataBean = service.view(bean);            
            model.addAttribute("dataBean", dataBean == null ? bean : dataBean);
        }
    }
    
    /**
     * VOC설정 등록 액션
     */
    @RequestMapping(value="t_insertAction.do", method=RequestMethod.POST)
    public ModelAndView insertAction(VocConfBean bean,
            @RequestParam(required=false, value="mgrDatas") String[] mgrDatas,
            ModelMap model) {

        int affected = service.insertAction(bean, mgrDatas);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_INSERT_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }

    /**
     * VOC설정 수정 액션
     */
    @RequestMapping(value="t_updateAction.do", method=RequestMethod.POST)
    public ModelAndView updateAction(VocConfBean bean,
            @RequestParam(required=false, value="mgrDatas") String[] mgrDatas,
            ModelMap model) {

        int affected = service.updateAction(bean, mgrDatas);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_UPDATE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }

    /**
     * VOC설정 삭제 액션
     */
    @RequestMapping(value="t_deleteAction.do", method=RequestMethod.POST)
    public ModelAndView deleteAction(VocConfBean bean, ModelMap model) {

        int affected = service.deleteAction(bean);
        if (affected == ONE) {
            return responseText(model, Message.success(Message.COMMON_DELETE_SUCCESS_KEY));
        }
        return responseText(model, Message.fail(Message.COMMON_CRUD_FAIL_KEY));
    }
    
    /**
     * 엑셀 변환 팝업창
     */
    @RequestMapping(value="p_excelForm.do", method=RequestMethod.GET)
    public void excelForm() {
    }
    
    /**
     * 엑셀 변환 액션
     */
    @RequestMapping(value="x_excelAction.do", method=RequestMethod.POST)
    public ModelAndView excelAction(VocConfBean bean, ModelMap model) {

    	List<Map<String, Object>> dataList = service.listExcel(bean);

        return responseExcel(model, dataList, bean);
    }
    
    /**
     * VOC설정 접수자지정 팝업창
     */
    @RequestMapping(value="p_vocMgrForm.do", method=RequestMethod.GET)
    public void vocMgrForm() {
    }
}
