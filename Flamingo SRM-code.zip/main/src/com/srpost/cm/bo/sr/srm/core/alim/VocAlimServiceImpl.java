package com.srpost.cm.bo.sr.srm.core.alim;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 알림 서비스 구현체
 *
 * @author  finkle
 * @date    2014-12-16
 * @since   2.0
 */
@Service
public class VocAlimServiceImpl extends EgovAbstractServiceImpl implements IVocAlimService {

    @Resource
    VocAlimDao dao;

    @Override
    public List<VocAlimBean> list(VocAlimBean bean) {
        
        return dao.list(bean);
    }

    @Override
    public VocAlimBean view(VocAlimBean bean) {
        
        return dao.view(bean);
    }

    @Override
    public int insertAction(VocAlimBean bean) {
        
        return dao.insertAction(bean);
    }
}
