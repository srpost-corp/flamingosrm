package com.srpost.cm.bo.fm.stat2.deal;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 시각화통계(금일 처리현황) DAO
 *
 * @author  bella
 * @date    2015-05-04
 * @since   3.0
 */
@Repository
public class Stat2DealDao extends EgovAbstractMapper {
    
    public Map<String, Map<String, Object>> stat2DealAll(String statYear) {
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("grpCd", "VOC_MGR_STATUS");
        if ( StringUtil.isNotEmpty(statYear))
            parameterMap.put("statYear", statYear);
        return selectMap("_stat2Deal.stat2DealMap", parameterMap, "LABEL");
    }
    
    public Map<String, Map<String, Object>> stat2DealToday() {
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("grpCd", "VOC_MGR_STATUS");
        parameterMap.put("regDt", DateTimeUtil.getToday());
        return selectMap("_stat2Deal.stat2DealMap", parameterMap, "LABEL");
    }

}
