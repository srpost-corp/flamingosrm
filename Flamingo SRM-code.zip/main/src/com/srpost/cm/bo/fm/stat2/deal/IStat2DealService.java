package com.srpost.cm.bo.fm.stat2.deal;

import java.util.Map;

/**
 * 내부단 VOC 시각화통계(금일 처리현황) 서비스 인터페이스
 *
 * @author  bella
 * @date    2015-05-04
 * @since   3.0
 */
public interface IStat2DealService {
    
    Map<String, Map<String, Object>> stat2DealAll(String statYear);
    
    Map<String, Map<String, Object>> stat2DealToday();

}
