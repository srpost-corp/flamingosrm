package com.srpost.cm.bo.fm.stat2.term;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 시각화통계(만족도, 평균처리기간) 서비스 구현체
 *
 * @author  bella
 * @date    2015-04-30
 * @since   3.0
 */
@Service
public class Stat2TermServiceImpl extends EgovAbstractServiceImpl implements IStat2TermService {
    
    @Resource
    Stat2TermDao dao;
    
    @Override
    public Map<String, Map<String, Object>> statScoreMap(StatTypeSearchBean bean) {

        return dao.statScoreMap(bean);
    }

    @Override
    public List<Stat2EndCntBean> statEndCntList(StatTypeSearchBean bean) {
        
        return dao.statEndCntList(bean);
    }

}
