package com.srpost.cm.bo.fm.stat2.term;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 시각화통계(만족도, 평균처리기간) DAO
 *
 * @author  bella
 * @date    2015-04-30
 * @since   3.0
 */
@Repository
public class Stat2TermDao extends EgovAbstractMapper {
    
    public Map<String, Map<String, Object>> statScoreMap(StatTypeSearchBean bean) {
        
        Map<String, Object> parameterMap = Stat2TermUtil.getParameterMap(bean);
        
        return selectMap("_stat2Term.statScoreMap", parameterMap, "LABEL");
    }
    
    public List<Stat2EndCntBean> statEndCntList(StatTypeSearchBean bean) {
        
        Map<String, Object> parameterMap = Stat2TermUtil.getParameterMap(bean);
        
        return selectList("_stat2Term.statEndCntList", parameterMap);
    }

}
