package com.srpost.cm.bo.fm.stat2.week;

import java.util.Map;

import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;

/**
 * 내부단 VOC 시각화통계(요일별) 서비스 인터페이스
 *
 * @author  bella
 * @date    2015-05-12
 * @since   3.0
 */
public interface IStat2WeekService {
    
    Map<String, Map<String, Object>> statWeekMap(StatTypeSearchBean bean);

}
