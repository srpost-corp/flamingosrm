package com.srpost.cm.bo.fm.stat2.week;

import java.util.Map;

import org.springframework.stereotype.Repository;

import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 시각화통계(요일별) DAO
 *
 * @author  bella
 * @date    2015-05-12
 * @since   3.0
 */
@Repository
public class Stat2WeekDao extends EgovAbstractMapper {
    
    public Map<String, Map<String, Object>> statWeekMap(StatTypeSearchBean bean) {
        
        Map<String, Object> parameterMap = Stat2WeekUtil.getParameterMap(bean);
        
        return selectMap("_stat2Week.statWeekMap", parameterMap, "LABEL");
    }

}
