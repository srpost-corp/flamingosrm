package com.srpost.cm.bo.fm.stat2.vocType;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 시각화통계(VOC유형별) DAO
 *
 * @author  bella
 * @date    2015-04-29
 * @since   3.0
 */
@Repository
public class Stat2VocTypeDao extends EgovAbstractMapper {
    
    public List<Stat2VocTypeBean> statVocTypeMap(String selectDt) {
        
        Map<String, Object> parameterMap = Stat2VocTypeUtil.getParameterMap(selectDt);
        
        return selectList("_stat2VocType.statVocTypeList", parameterMap);
    }

}
