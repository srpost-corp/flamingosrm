package com.srpost.cm.bo.fm.stat2.type;

import java.util.Map;

/**
 * 내부단 VOC 시각화통계(처리결과) 서비스 인터페이스
 *
 * @author  bella
 * @date    2015-04-27
 * @since   3.0
 */
public interface IStat2TypeService {
    
    Map<String, Map<String, Object>> statVocMap(Stat2TypeSearchBean bean);
    
    Map<String, Map<String, Object>> statScoreMap(Stat2TypeSearchBean bean);
    
    Map<String, Map<String, Object>> statDealAvgMap(Stat2TypeSearchBean bean);

}
