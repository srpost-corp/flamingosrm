package com.srpost.cm.bo.fm.stat2.vocType;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 시각화통계(VOC유형별) 서비스 구현체
 *
 * @author  bella
 * @date    2015-04-29
 * @since   3.0
 */
@Service
public class Stat2VocTypeServiceImpl extends EgovAbstractServiceImpl implements IStat2VocTypeService {

    @Resource
    Stat2VocTypeDao dao;
    
    @Override
    public List<Stat2VocTypeBean> statVocTypeList(String selectDt) {
        
        return dao.statVocTypeMap(selectDt);
    }
    
}
