package com.srpost.cm.bo.fm.stat2.vocType;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

@Alias("stat2VocTypeBean")
@SuppressWarnings("serial")
public class Stat2VocTypeBean extends BaseBean {
    
    /** 유형_코드 */
    private String typeCd; 
    /** 유형_이름 */
    private String typeNm;
    /** 어제 */
    private Integer yesterday;
    /** 오늘 */
    private Integer today;
    /** 누적(년) */
    private Integer sumYear;
    /** 월평균 */
    private Integer avgMonth;
    
    public String getTypeCd() {
        return typeCd;
    }
    public void setTypeCd(String typeCd) {
        this.typeCd = typeCd;
    }
    public String getTypeNm() {
        return typeNm;
    }
    public void setTypeNm(String typeNm) {
        this.typeNm = typeNm;
    }
    public Integer getYesterday() {
        return yesterday;
    }
    public void setYesterday(Integer yesterday) {
        this.yesterday = yesterday;
    }
    public Integer getToday() {
        return today;
    }
    public void setToday(Integer today) {
        this.today = today;
    }
    public Integer getSumYear() {
        return sumYear;
    }
    public void setSumYear(Integer sumYear) {
        this.sumYear = sumYear;
    }
    public Integer getAvgMonth() {
        return avgMonth;
    }
    public void setAvgMonth(Integer avgMonth) {
        this.avgMonth = avgMonth;
    }
    
}
