package com.srpost.cm.bo.fm.stat2.type;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

@Alias("stat2TypeSearchBean")
@SuppressWarnings("serial")
public class Stat2TypeSearchBean extends BaseBean {
    
    /** 통계 검색 년도 */
    private String statYear;
    /** 통계 검색 월 */
    private String statMonth;
    
    
    public String getStatYear() {
        return statYear;
    }
    public void setStatYear(String statYear) {
        this.statYear = statYear;
    }
    public String getStatMonth() {
        return statMonth;
    }
    public void setStatMonth(String statMonth) {
        this.statMonth = statMonth;
    }

}
