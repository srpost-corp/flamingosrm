package com.srpost.cm.bo.fm.stat2.type;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import jodd.util.StringUtil;

/**
 * 내부단 VOC 시각화통계(처리결과) Util
 *
 * @author  bella
 * @date    2015-04-27
 * @since   3.0
 */
public class Stat2TypeUtil {
    
    public static Map<String, Object> getParameterMap(Stat2TypeSearchBean bean) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        
        // Set X column
        parameterMap.put("YEAR", bean.getStatYear());

        if ( StringUtil.isNotEmpty(bean.getStatMonth()) ) {
            parameterMap.put("MONTH", bean.getStatMonth());
            parameterMap.put("LAST_DAY", getLastDay(bean));
        }
        
        return parameterMap;
    }
    
    // 마지막 날짜 구하기
    public static int getLastDay (Stat2TypeSearchBean bean) {
        
        Calendar cal = Calendar.getInstance();
        cal.set( Integer.parseInt(bean.getStatYear()), Integer.parseInt(bean.getStatMonth())-1, 01);
        int lastDay = cal.getActualMaximum(Calendar.DATE);
        
        return lastDay;
    }

}
