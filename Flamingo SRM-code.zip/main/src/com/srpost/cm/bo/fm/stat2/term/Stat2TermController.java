package com.srpost.cm.bo.fm.stat2.term;

import java.io.ByteArrayOutputStream;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.srpost.cm.bo.sr.srm.core.VocUtil;
import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.web.mvc.controller.BaseController;
import com.srpost.salmon.web.mvc.view.ExcelView;

import static com.srpost.salmon.constant.Constant.ENCODING;
import static com.srpost.salmon.constant.StringPool.EMPTY;
import static com.srpost.salmon.constant.StringPool.UNDERSCORE;

/**
 * 내부단 VOC 시각화통계(만족도, 평균처리기간) 컨트롤러
 *
 * @author  bella
 * @date    2015-04-30
 * @since   3.0
 */
@Controller
@RequestMapping(value="/bo/fm/voc/stat2/term")
public class Stat2TermController extends BaseController {
    
    @Resource
    IStat2TermService service;
    @Resource
    ExcelView excelView;
    
    /**
     * 통계 메인
     */
    @RequestMapping(value="NR_index.do", method=RequestMethod.GET)
    public void index(ModelMap model) {
        
        model.addAttribute("vocList", VocUtil.getConfList());
    }
    
    /**
     * 통계 검색
     */
    @RequestMapping(value="AR_termStat.do", method=RequestMethod.POST)
    public void termStat(StatTypeSearchBean bean, ModelMap model) {
        
        model.addAttribute("vocList", VocUtil.getConfList());
        model.addAttribute("dataScoreMap", service.statScoreMap(bean));
        model.addAttribute("dataEndCntList", service.statEndCntList(bean));
        
    }
    
    /**
     * 통계 엑셀 변환
     */
    @RequestMapping(value="XR_excel.do", method=RequestMethod.POST)
    public void excel(
            @RequestParam(value="xlsStatCd") String xlsStatCd,
            @RequestParam(value="xlsData") String xlsData, 
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        
        String encodedFileName = 
            excelView.getEncodedFileName(request,
                    xlsStatCd +
                    UNDERSCORE + DateTimeUtil.totDateShort(new Date()) + ExcelView.EXTENSION);
        
        String contentType = excelView.getContentType();
        
        try {
            StringBuilder builder = new StringBuilder()
            .append("<html>\n<head>\n")
            .append("<meta http-equiv='Content-Type' ")
            .append("content='application/vnd.ms-excel;charset=" + ENCODING +"' />\n")
            .append("</head>\n<body>\n")
            .append(xlsData)
            .append("\n</body>\n</html>\n");

            byte[] xlsBytes = builder.toString().getBytes(ENCODING);

            out.write(xlsBytes);
            
            response.setContentType(contentType);
            response.setHeader("Content-Disposition","attachment;filename=" + encodedFileName + ";");
            response.setContentLength(out.size());
            
            response.getOutputStream().write(out.toByteArray());
            response.getOutputStream().flush();
        } 
        catch (Exception e) {
            logger.error(EMPTY, e);
        }
        finally {
            IOUtils.closeQuietly(out);
        }
    }

}
