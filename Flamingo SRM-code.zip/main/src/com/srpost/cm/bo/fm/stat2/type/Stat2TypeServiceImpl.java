package com.srpost.cm.bo.fm.stat2.type;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 시각화통계(처리결과) 서비스 구현체
 *
 * @author  bella
 * @date    2015-04-27
 * @since   3.0
 */
@Service
public class Stat2TypeServiceImpl extends EgovAbstractServiceImpl implements IStat2TypeService {

    @Resource
    Stat2TypeDao dao;
    
    @Override
    public Map<String, Map<String, Object>> statVocMap(Stat2TypeSearchBean bean) {
        
        return dao.statVocMap(bean);
    }

    @Override
    public Map<String, Map<String, Object>> statScoreMap(Stat2TypeSearchBean bean) {
        
        return dao.statScoreMap(bean);
    }

    @Override
    public Map<String, Map<String, Object>> statDealAvgMap(Stat2TypeSearchBean bean) {
        
        return dao.statDealAvgMap(bean);
    }

}
