package com.srpost.cm.bo.fm.stat2.term;

import java.util.List;
import java.util.Map;

import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;

/**
 * 내부단 VOC 시각화통계(만족도, 통계) 서비스 인터페이스
 *
 * @author  bella
 * @date    2015-04-30
 * @since   3.0
 */
public interface IStat2TermService {
    
    Map<String, Map<String, Object>> statScoreMap(StatTypeSearchBean bean);
    
    List<Stat2EndCntBean> statEndCntList(StatTypeSearchBean bean);

}
