package com.srpost.cm.bo.fm.stat2.vocType;

import static com.srpost.salmon.constant.StringPool.ZERO;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.srpost.salmon.lang.DateTimeUtil;

import jodd.util.StringUtil;

/**
 * 내부단 VOC 시각화통계(VOC유형별) Util
 *
 * @author  bella
 * @date    2015-04-29
 * @since   3.0
 */
public class Stat2VocTypeUtil {
    
    public static Map<String, Object> getParameterMap(String selectDt) {
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        
        Calendar today = Calendar.getInstance();
        int year = Integer.parseInt(selectDt.substring(0,4));
        int month = Integer.parseInt(selectDt.substring(4,6));
        int day = Integer.parseInt(selectDt.substring(6));
        today.set(year, month, day);
        
        parameterMap.put("today", selectDt);
        parameterMap.put("yesterday", parseCalendar(year, month, day-1));
        parameterMap.put("year", year);
        
        return parameterMap;
    }
    
    private static String parseCalendar(int year, int month, int day) {

        String yyyyMMdd = String.valueOf(year);
        
        if (month < 10)
            yyyyMMdd += String.valueOf(ZERO) + month;
        else
            yyyyMMdd += String.valueOf(month);
        
        if (day < 10)
            yyyyMMdd += String.valueOf(ZERO) + day;
        else
            yyyyMMdd += String.valueOf(day);
        
        return yyyyMMdd; 
    }
    
    
    /** 선택일(초기값은 오늘날짜)을 YYYYMMDD 형태 반환  */
    public static String setSelectDt(String selectDt) {
        if ( StringUtil.isEmpty(selectDt) )
            return DateTimeUtil.getTodayShort();
        else
            return DateTimeUtil.removeDash(selectDt);
    }

}
