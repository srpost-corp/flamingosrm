package com.srpost.cm.bo.fm.stat2.term;

import org.apache.ibatis.type.Alias;

import com.srpost.salmon.bean.BaseBean;

@Alias("stat2EndCntBean")
@SuppressWarnings("serial")
public class Stat2EndCntBean extends BaseBean {
    
    /** VOC 코드 */
    private Integer vocCd;
    /** VOC 이름 */
    private String vocNm;
    /** 12시간 이내 */
    private Integer statHalf;
    /** 24시간 이내 */
    private Integer statOne;
    /** 1일~2일 */
    private Integer statTwo;
    /** 2일~3일 */
    private Integer statThree;
    /** 3일이상 */
    private Integer statMore;
    
    public Integer getVocCd() {
        return vocCd;
    }
    public void setVocCd(Integer vocCd) {
        this.vocCd = vocCd;
    }
    public String getVocNm() {
        return vocNm;
    }
    public void setVocNm(String vocNm) {
        this.vocNm = vocNm;
    }
    public Integer getStatHalf() {
        return statHalf;
    }
    public void setStatHalf(Integer statHalf) {
        this.statHalf = statHalf;
    }
    public Integer getStatOne() {
        return statOne;
    }
    public void setStatOne(Integer statOne) {
        this.statOne = statOne;
    }
    public Integer getStatTwo() {
        return statTwo;
    }
    public void setStatTwo(Integer statTwo) {
        this.statTwo = statTwo;
    }
    public Integer getStatThree() {
        return statThree;
    }
    public void setStatThree(Integer statThree) {
        this.statThree = statThree;
    }
    public Integer getStatMore() {
        return statMore;
    }
    public void setStatMore(Integer statMore) {
        this.statMore = statMore;
    }
    
}
