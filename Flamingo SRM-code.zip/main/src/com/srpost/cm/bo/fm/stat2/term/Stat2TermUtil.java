package com.srpost.cm.bo.fm.stat2.term;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;
import com.srpost.salmon.lang.DateTimeUtil;
import com.srpost.salmon.lang.StringUtil;

import static com.srpost.salmon.constant.StringPool.ONE;
import static com.srpost.salmon.constant.StringPool.ZERO;

/**
 * 내부단 VOC 시각화통계(만족도, 평균처리기간) Util
 *
 * @author  bella
 * @date    2015-04-30
 * @since   3.0
 */
public final class Stat2TermUtil {
    
    /** 일간 검색주기 */
    public static final int TERM_DAY = 1;
    /** 주간 검색주기 */
    public static final int TERM_WEEK = 2;
    /** 월간 검색주기 */
    public static final int TERM_MONTH = 3;
    /** 연간 검색주기 */
    public static final int TERM_YEAR = 4;
    
    public static final String[] STAT_END = {
        "12시간이내", "24시간이내", "1일~2일", "2일~3일", "3일이상"};    
    
    public static Map<String, Object> getParameterMap(StatTypeSearchBean bean) {
        
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        
        // Set search condition
        if ( StringUtil.isNotEmpty(bean.getVocCd()) ) {
            parameterMap.put("vocCd", bean.getVocCd());
        }
        
        setDefaultTerm(bean, parameterMap);
        
        return parameterMap;
    }
    
    
    public static void setDefaultTerm(StatTypeSearchBean bean, Map<String, Object> parameterMap) {
        
        if ( StringUtil.isEmpty(bean.getStartDd()) ) {

            if ( StringUtil.isEmpty(bean.getTermCd()) ) {
                bean.setTermCd(TERM_MONTH);
            }

            String termDts[] = null;

            switch ( bean.getTermCd() ) {
                case TERM_DAY:
                    termDts = getTermDay();
                break;

                case TERM_WEEK:
                    termDts = getTermWeek();
                break;

                case TERM_MONTH:
                    termDts = getTermMonth();
                break;

                case TERM_YEAR:
                    termDts = getTermYear();
                break;
            }

            if ( StringUtil.isNotEmpty(termDts) ) {
                bean.setStartDd(DateTimeUtil.appendDash(termDts[0]));
                bean.setEndDd(DateTimeUtil.appendDash(termDts[1]));
            }
        }

        if ( StringUtil.isNotEmpty(bean.getStartDd()) )
            parameterMap.put("startDt", DateTimeUtil.removeDash(bean.getStartDd()) + "000000");
        if ( StringUtil.isNotEmpty(bean.getEndDd()) )
            parameterMap.put("endDt", DateTimeUtil.removeDash(bean.getEndDd()) + "235959");
    }
    
    
    
    /**
     * 현재 날짜를 기준으로 일간 검색일 기간을 획득
     */
    public static String[] getTermDay() {

        String todayShort = DateTimeUtil.getTodayShort();
        
        return new String[] {todayShort, todayShort};
    }
    
    /**
     * 현재 날짜를 기준으로 주간 검색일 기간을 획득 (일요일 ~ 토요일)
     */
    public static String[] getTermWeek() {

        Calendar now = Calendar.getInstance();
        int currentDaw = now.get(Calendar.DAY_OF_WEEK);
        if ( currentDaw == Calendar.MONDAY ) {
            now.add(Calendar.DATE, -1);
        }
        else {
            now.add(Calendar.DATE, -(currentDaw-1));
        }
        
        String startDt = parseCalendar(
                now.get(Calendar.YEAR), 
                now.get(Calendar.MONTH) + 1, 
                now.get(Calendar.DATE));
        
        now.add(Calendar.DATE, 6);
        
        String endDt = parseCalendar(
                now.get(Calendar.YEAR), 
                now.get(Calendar.MONTH) + 1, 
                now.get(Calendar.DATE));
        
        return new String[] {startDt, endDt};  
    }
    
    /**
     * 현재 날짜를 기준으로 월간 검색일 기간을 획득
     */
    public static String[] getTermMonth() {

        Calendar now = Calendar.getInstance();
        int currentYear = now.get(Calendar.YEAR);
        int currentMonth = now.get(Calendar.MONTH) + 1;
        
        int lastDay = now.getActualMaximum(Calendar.DATE);
        
        String startDt = parseCalendar(currentYear, currentMonth, ONE);
        String endDt = startDt.substring(0, 6) + lastDay;
        
        return new String[] {startDt, endDt};
    }
    
    /**
     * 현재 날짜를 기준으로 연간 검색일 기간을 획득
     */
    public static String[] getTermYear() {

        Calendar now = Calendar.getInstance();
        int currentYear = now.get(Calendar.YEAR);
        
        String startDt = parseCalendar(currentYear, ONE, ONE);
        String endDt = parseCalendar(currentYear, 12, 31);
        
        return new String[] {startDt, endDt};
    }
    
    private static String parseCalendar(int year, int month, int day) {

        String yyyyMMdd = String.valueOf(year);
        
        if (month < 10)
            yyyyMMdd += String.valueOf(ZERO) + month;
        else
            yyyyMMdd += String.valueOf(month);
        
        if (day < 10)
            yyyyMMdd += String.valueOf(ZERO) + day;
        else
            yyyyMMdd += String.valueOf(day);
        
        return yyyyMMdd; 
    }

}
