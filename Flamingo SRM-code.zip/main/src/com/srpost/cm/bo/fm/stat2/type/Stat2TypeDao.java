package com.srpost.cm.bo.fm.stat2.type;

import java.util.Map;

import jodd.util.StringUtil;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 내부단 VOC 시각화통계(처리결과) DAO
 *
 * @author  bella
 * @date    2015-04-27
 * @since   3.0
 */
@Repository
public class Stat2TypeDao extends EgovAbstractMapper {
    
    public Map<String, Map<String, Object>> statVocMap(Stat2TypeSearchBean bean) {
        
        Map<String, Object> parameterMap = Stat2TypeUtil.getParameterMap(bean);
        
        if ( StringUtil.isEmpty(bean.getStatMonth()) ) 
            return selectMap("_stat2Type.statVocYearMap", parameterMap, "LABEL");
        else 
            return selectMap("_stat2Type.statVocMonthMap", parameterMap, "LABEL");
    }
    
    public Map<String, Map<String, Object>> statScoreMap(Stat2TypeSearchBean bean) {
        
        Map<String, Object> parameterMap = Stat2TypeUtil.getParameterMap(bean);
        
        if ( StringUtil.isEmpty(bean.getStatMonth()) )
            return selectMap("_stat2Type.statScoreYearMap", parameterMap, "LABEL");
        else
            return selectMap("_stat2Type.statScoreMonthMap", parameterMap, "LABEL");
    }


    public Map<String, Map<String, Object>> statDealAvgMap(Stat2TypeSearchBean bean) {
        
        Map<String, Object> parameterMap = Stat2TypeUtil.getParameterMap(bean);
        
        if ( StringUtil.isEmpty(bean.getStatMonth()) )
            return selectMap("_stat2Type.statDealAvgYearMap", parameterMap, "LABEL");
        else
            return selectMap("_stat2Type.statDealAvgMonthMap", parameterMap, "LABEL");
    }

}
