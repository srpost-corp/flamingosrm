package com.srpost.cm.bo.fm.stat2.week;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.srpost.cm.bo.sr.stat.type.StatTypeSearchBean;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 내부단 VOC 시각화통계(요일별) 서비스 구현체
 *
 * @author  bella
 * @date    2015-05-12
 * @since   3.0
 */
@Service
public class Stat2WeekServiceImpl extends EgovAbstractServiceImpl implements IStat2WeekService {
    
    @Resource
    Stat2WeekDao dao;
    
    @Override
    public Map<String, Map<String, Object>> statWeekMap(StatTypeSearchBean bean) {
        
        return dao.statWeekMap(bean);
    }

}
